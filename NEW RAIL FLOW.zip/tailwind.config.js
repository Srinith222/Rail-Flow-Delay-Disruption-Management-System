/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["IBM Plex Sans", "ui-sans-serif", "system-ui", "sans-serif"],
        display: ["Space Grotesk", "IBM Plex Sans", "system-ui", "sans-serif"],
        condensed: ["Space Grotesk", "Arial Narrow", "sans-serif"],
        mono: ["JetBrains Mono", "ui-monospace", "SFMono-Regular", "monospace"],
      },
      colors: {
        canvas: "#08090b",
        surface: "#0e1013",
        panel: "#12151a",
        line: "rgba(244,237,226,0.10)",
        cream: "#f4ede2",
        muted: "#8b8d92",
        wine: "#7c1f2b",
        wineDeep: "#4a0f18",
        accent: "#ff6a2c",
        accentDim: "#c94f1d",
        blueprint: "#070b14",
        signal: "#7fe3b4",
        amber: "#f0be7a",
        ember: "#ff9a83",
        ice: "#9dc0ff",
      },
      borderRadius: {
        DEFAULT: "4px",
        md: "6px",
        lg: "8px",
        xl: "10px",
        "2xl": "12px",
      },
    },
  },
  plugins: [],
};
