import type { RecoveryPlan, Snapshot } from "@/types";
import { useCallback, useEffect, useRef, useState } from "react";

export function fmtClock(min: number | null | undefined): string {
  if (min === null || min === undefined || Number.isNaN(min)) return "--:--";
  const total = Math.round(min);
  const h = Math.floor((((total % 1440) + 1440) % 1440) / 60);
  const m = Math.floor(((total % 60) + 60) % 60);
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

export function fmtDelay(min: number): string {
  if (min <= 0) return "On time";
  return `+${Math.round(min)} min`;
}

export function classColor(cls: string): string {
  switch (cls) {
    case "express":
      return "text-cream";
    case "suburban":
      return "text-ice";
    case "passenger":
      return "text-amber";
    default:
      return "text-muted";
  }
}

export function statusTone(status: string): string {
  switch (status) {
    case "held":
      return "text-ice border-ice/40 bg-ice/10";
    case "delayed":
      return "text-ember border-ember/40 bg-ember/10";
    case "arrived":
      return "text-muted border-line bg-white/5";
    case "upcoming":
      return "text-cream/70 border-line bg-white/5";
    default:
      return "text-signal border-signal/40 bg-signal/10";
  }
}

interface ApiError {
  error?: string;
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    headers: { "content-type": "application/json" },
    ...init,
  });
  const data = (await res.json().catch(() => ({}))) as T & ApiError;
  if (!res.ok) throw new Error(data?.error || `Request failed (${res.status})`);
  return data;
}

export async function apiGet<T>(path: string): Promise<T> {
  return request<T>(path);
}

export function useRailflow() {
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [lastSync, setLastSync] = useState<number | null>(null);
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  const refresh = useCallback(async () => {
    try {
      const data = await request<Snapshot>("/api/state");
      if (mounted.current) {
        setSnap(data);
        setError(null);
        setLastSync(Date.now());
      }
    } catch (err) {
      if (mounted.current) setError(err instanceof Error ? err.message : "Control feed unavailable");
    }
  }, []);

  useEffect(() => {
    void refresh();
    const id = window.setInterval(() => void refresh(), 5000);
    return () => window.clearInterval(id);
  }, [refresh]);

  const post = useCallback(
    async <T,>(path: string, body?: unknown): Promise<T | null> => {
      setBusy(true);
      try {
        const data = await request<T & { state?: Snapshot }>(path, {
          method: "POST",
          body: body === undefined ? undefined : JSON.stringify(body),
        });
        if (data?.state && mounted.current) setSnap(data.state);
        setError(null);
        return data;
      } catch (err) {
        if (mounted.current) setError(err instanceof Error ? err.message : "Action failed");
        return null;
      } finally {
        if (mounted.current) setBusy(false);
      }
    },
    [],
  );

  const fetchPlan = useCallback(async (disruptionId: string): Promise<RecoveryPlan | null> => {
    try {
      const data = await request<{ plan: RecoveryPlan }>(`/api/replan/${disruptionId}`);
      return data.plan;
    } catch (err) {
      setError(err instanceof Error ? err.message : "Plan unavailable");
      return null;
    }
  }, []);

  return { snap, error, busy, lastSync, refresh, post, fetchPlan };
}
