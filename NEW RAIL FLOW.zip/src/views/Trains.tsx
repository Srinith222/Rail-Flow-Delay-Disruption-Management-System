import { ArrowUpRight, Clock, Search, TrainFront } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import {
  Button,
  Card,
  Drawer,
  EmptyState,
  Eyebrow,
  SectionHead,
  Segmented,
  StatusBadge,
  cn,
} from "@/components/ui";
import { classColor, fmtClock } from "@/lib/api";
import type { Snapshot, Train } from "@/types";

type Filter = "all" | "delayed" | "held" | "upcoming";

export function TrainsView({
  snap,
  post,
  busy,
  initialTrain,
  onClearInitial,
}: {
  snap: Snapshot;
  post: <T,>(path: string, body?: unknown) => Promise<T | null>;
  busy: boolean;
  initialTrain: string | null;
  onClearInitial: () => void;
}) {
  const [filter, setFilter] = useState<Filter>("all");
  const [query, setQuery] = useState("");
  const [openNo, setOpenNo] = useState<string | null>(initialTrain);

  useEffect(() => {
    if (initialTrain) setOpenNo(initialTrain);
  }, [initialTrain]);

  const rows = useMemo(() => {
    const term = query.trim().toLowerCase();
    return snap.trains
      .filter((t) => t.status !== "arrived")
      .filter((t) => {
        if (filter === "delayed") return t.delay >= 6 || t.status === "delayed";
        if (filter === "held") return t.status === "held";
        if (filter === "upcoming") return t.status === "upcoming";
        return true;
      })
      .filter((t) => !term || `${t.no} ${t.name} ${t.originName} ${t.destinationName}`.toLowerCase().includes(term))
      .sort((a, b) => a.eta - b.eta);
  }, [snap.trains, filter, query]);

  const selected = openNo ? snap.trains.find((t) => t.no === openNo) ?? null : null;

  return (
    <div className="space-y-5">
      <Card>
        <SectionHead
          label="Running board"
          title="Trains in section"
          right={
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative">
                <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
                <input
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder="Train number or name"
                  className="w-[210px] rounded border border-line bg-black/30 py-2 pl-8 pr-3 text-[12px] text-cream outline-none transition-colors placeholder:text-muted/60 focus:border-cream/40"
                />
              </div>
              <Segmented<Filter>
                size="sm"
                value={filter}
                onChange={setFilter}
                options={[
                  { id: "all", label: "All" },
                  { id: "delayed", label: "Delayed" },
                  { id: "held", label: "Held" },
                  { id: "upcoming", label: "Ahead" },
                ]}
              />
            </div>
          }
        />

        {rows.length === 0 ? (
          <EmptyState title="No trains match this filter" body="Clear the filter or search for a different number." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[860px] border-collapse text-left">
              <thead>
                <tr className="text-[10px] font-medium uppercase tracking-[0.04em] text-muted">
                  <th className="pb-3 font-normal">Train</th>
                  <th className="pb-3 font-normal">Class</th>
                  <th className="pb-3 font-normal">Direction</th>
                  <th className="pb-3 font-normal">Route</th>
                  <th className="pb-3 font-normal">Next halt</th>
                  <th className="pb-3 font-normal">ETA</th>
                  <th className="pb-3 font-normal">Platform</th>
                  <th className="pb-3 font-normal">Delay</th>
                  <th className="pb-3 font-normal text-right">Status</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((train) => (
                  <tr
                    key={train.no}
                    onClick={() => setOpenNo(train.no)}
                    className="rail-row cursor-pointer border-t border-line"
                  >
                    <td className="py-3.5 pr-4">
                      <p className="num text-[12.5px] text-cream">{train.no}</p>
                      <p className="text-[11px] text-muted">{train.name}</p>
                    </td>
                    <td className={cn("pr-4 text-[11px]", classColor(train.cls))}>
                      {train.cls}
                    </td>
                    <td className="pr-4 text-[11px] text-muted">{train.dir}</td>
                    <td className="pr-4 text-[11.5px] text-muted">
                      {train.originName} → {train.destinationName}
                    </td>
                    <td className="pr-4 text-[11.5px] text-cream/80">{train.nextName}</td>
                    <td className="num pr-4 text-[12.5px] text-cream">{fmtClock(train.eta)}</td>
                    <td className="num pr-4 text-[12px] text-muted">{train.platform}</td>
                    <td className={cn("num pr-4 text-[12.5px]", train.delay > 5 ? "text-ember" : "text-signal")}>
                      {train.delay > 0 ? `+${train.delay}` : "0"}
                    </td>
                    <td className="text-right">
                      <StatusBadge status={train.status} label={train.statusLabel} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Drawer
        open={Boolean(selected)}
        onClose={() => {
          setOpenNo(null);
          onClearInitial();
        }}
        eyebrow={selected ? `${selected.cls} · ${selected.dir}` : "Train"}
        title={selected ? `${selected.no} ${selected.name}` : ""}
      >
        {selected ? <TrainDetail train={selected} post={post} busy={busy} /> : null}
      </Drawer>
    </div>
  );
}

function TrainDetail({
  train,
  post,
  busy,
}: {
  train: Train;
  post: <T,>(path: string, body?: unknown) => Promise<T | null>;
  busy: boolean;
}) {
  const [minutes, setMinutes] = useState(10);
  const [reason, setReason] = useState("");

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-2">
        <StatusBadge status={train.status} label={train.statusLabel} />
        <span className={cn("rounded-[3px] border border-line px-2 py-0.5 text-[11px] tracking-[0.04em]", classColor(train.cls))}>
          {train.cls}
        </span>
        <span className="rounded-[3px] border border-line px-2 py-0.5 text-[11px] text-muted">
          priority {train.weight}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="rounded border border-line px-4 py-3">
          <Eyebrow>Delay carried</Eyebrow>
          <p className={cn("num mt-1 text-[24px] font-normal", train.delay > 5 ? "text-ember" : "text-signal")}>
            +{train.delay} <span className="text-[11px] text-muted">min</span>
          </p>
        </div>
        <div className="rounded border border-line px-4 py-3">
          <Eyebrow>Next halt</Eyebrow>
          <p className="mt-1 text-[15px] text-cream">{train.nextName}</p>
          <p className="num text-[11px] text-muted">{fmtClock(train.eta)} · platform {train.platform}</p>
        </div>
      </div>

      {train.reasons.length > 0 ? (
        <div className="rounded-xl border border-ember/25 bg-ember/[0.05] px-4 py-3">
          <Eyebrow>Delay attributed to</Eyebrow>
          <ul className="mt-2 space-y-1.5">
            {train.reasons.map((reasonText) => (
              <li key={reasonText} className="text-[11.5px] leading-relaxed text-cream/80">
                · {reasonText}
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      <div>
        <div className="mb-3 flex items-center justify-between">
          <Eyebrow>Working timetable</Eyebrow>
          <span className="text-[10px] text-muted">sched / actual</span>
        </div>
        <ol className="relative space-y-0 border-l border-line pl-5">
          {train.stops.map((stop) => {
            const late = stop.shift > 0;
            return (
              <li key={stop.code} className="relative py-2.5">
                <span
                  className={cn(
                    "absolute -left-[25px] top-[15px] h-[7px] w-[7px] rounded-full border",
                    stop.passed ? "border-cream/70 bg-cream/70" : "border-muted bg-canvas",
                  )}
                />
                <div className="flex items-baseline justify-between gap-3">
                  <div>
                    <p className={cn("text-[12.5px]", stop.passed ? "text-cream" : "text-cream/70")}>
                      {stop.name}
                    </p>
                    <p className="text-[10px] text-muted">platform {stop.platform}</p>
                  </div>
                  <div className="text-right">
                    <p className="num text-[12.5px] text-cream">{fmtClock(stop.arr)}</p>
                    <p className={cn("num text-[10.5px]", late ? "text-ember" : "text-muted")}>
                      {fmtClock(stop.schedArr)}
                      {late ? ` · +${stop.shift}` : ""}
                    </p>
                  </div>
                </div>
              </li>
            );
          })}
        </ol>
      </div>

      <div className="rounded-xl border border-line bg-black/20 p-4">
        <Eyebrow>Controller action</Eyebrow>
        {train.hold ? (
          <p className="mt-2 flex items-center gap-2 text-[11.5px] text-ice">
            <Clock size={12} /> Held at {train.hold.station} until {fmtClock(train.hold.untilMin)}
          </p>
        ) : (
          <p className="mt-2 text-[11.5px] text-muted">
            Holding delays this train and every service queued behind it in the section.
          </p>
        )}

        <div className="mt-3 flex flex-wrap gap-2">
          {[5, 10, 15, 30].map((value) => (
            <button
              key={value}
              type="button"
              onClick={() => setMinutes(value)}
              className={cn("chip", minutes === value && "chip-on")}
            >
              {value} min
            </button>
          ))}
        </div>
        <input
          value={reason}
          onChange={(event) => setReason(event.target.value)}
          placeholder="Reason (e.g. single-line clearance)"
          className="field mt-3 text-[12px]"
        />
        <div className="mt-3 flex flex-wrap gap-2">
          <Button
            variant="wine"
            disabled={busy}
            icon={<TrainFront size={13} />}
            onClick={() => void post(`/api/trains/${train.no}/hold`, { minutes, reason: reason || "Controller hold" })}
          >
            Hold at {train.nextCode}
          </Button>
          <Button
            variant="ghost"
            disabled={busy || !train.hold}
            icon={<ArrowUpRight size={13} />}
            onClick={() => void post(`/api/trains/${train.no}/release`)}
          >
            Release
          </Button>
        </div>
      </div>
    </div>
  );
}
