import { ArrowRight, CalendarDays, KeyRound, Lock, MapPin } from "lucide-react";
import { useState, type FormEvent, type ReactNode } from "react";
import { HomeScene } from "@/components/HomeScene";
import { StationScene } from "@/components/StationScene";

const PASSWORD = "7800";

export function Home({ onUnlock }: { onUnlock: () => void }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const today = new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });

  function submit(event: FormEvent) {
    event.preventDefault();
    if (password.trim() === PASSWORD) {
      setError(null);
      onUnlock();
      return;
    }
    setError("Incorrect password. The corridor code is 7800.");
  }

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#08090c]">
      <div className="fixed inset-0 [filter:grayscale(1)_contrast(1.05)_brightness(0.92)]">
        <HomeScene />
      </div>
      <div aria-hidden className="fixed inset-y-0 left-[12%] w-[30%] bg-accent/90 mix-blend-multiply" />
      <div className="fixed inset-0 [filter:grayscale(0.85)_contrast(1.03)]">
        <StationScene />
      </div>
      <div
        aria-hidden
        className="fixed inset-0 bg-[linear-gradient(100deg,rgba(6,7,9,0.55)_0%,rgba(6,7,9,0.12)_34%,rgba(6,7,9,0.7)_70%,rgba(6,7,9,0.93)_100%)]"
      />
      <div aria-hidden className="fixed inset-x-0 bottom-0 h-40 bg-gradient-to-t from-[#08090c] to-transparent" />

      <div className="relative z-10 flex min-h-screen flex-col">
        <header className="flex items-center gap-2.5 px-6 pt-6 text-white sm:px-8 lg:px-10 lg:pt-8">
          <RailMark />
          <span className="text-[12px] font-semibold tracking-[0.02em]">RailFlow</span>
          <span className="ml-auto text-[10px] uppercase tracking-[0.16em] text-white/60">Indian Railways</span>
        </header>

        <div className="flex flex-1 flex-col justify-end gap-10 px-6 pb-8 pt-16 sm:px-8 lg:flex-row lg:items-end lg:justify-between lg:px-10 lg:pb-10">
          <div className="max-w-[42ch]">
            <p className="mb-4 text-[10px] uppercase tracking-[0.18em] text-white/60">
              South Central Railway · Secunderabad Division
            </p>
            <p className="font-display text-[64px] font-bold uppercase leading-[0.78] tracking-[-0.04em] text-white sm:text-[82px] xl:text-[104px]">
              Rail
              <br />
              Flow
            </p>
            <div className="hidden sm:block">
              {[0, 1].map((row) => (
                <p
                  key={row}
                  className="pointer-events-none select-none font-display text-[52px] font-bold uppercase leading-[0.78] tracking-[-0.02em] text-transparent xl:text-[64px]"
                  style={{
                    WebkitTextStroke: "1px rgba(255,255,255,0.4)",
                    marginTop: row === 0 ? 4 : -4,
                  }}
                >
                  RailFlow
                </p>
              ))}
            </div>
            <p className="mt-5 max-w-[34ch] text-[11.5px] leading-relaxed text-white/70">
              Section control for the 63.5 km Secunderabad — Wadiaram corridor. Simulation only — nothing here is
              connected to signalling.
            </p>
          </div>

          <section className="w-full shrink-0 rounded-md border border-white/10 bg-[#090a0d]/85 p-5 shadow-[0_30px_80px_-30px_rgba(0,0,0,0.9)] backdrop-blur-md sm:max-w-[400px] sm:p-6">
            <p className="text-[10px] uppercase tracking-[0.16em] text-muted">Corridor access</p>
            <h1 className="mt-3 font-display text-[32px] font-semibold leading-[0.95] tracking-[-0.03em] text-cream">
              Control
              <br />
              access<span className="text-accent">.</span>
            </h1>

            <form onSubmit={submit} className="mt-5 space-y-3.5">
              <div className="grid grid-cols-2 gap-3">
                <Field icon={<MapPin size={12} />} label="From" value="Secunderabad" />
                <Field icon={<MapPin size={12} />} label="To" value="Wadiaram" />
              </div>
              <Field icon={<CalendarDays size={12} />} label="Date" value={today} />

              <div>
                <label
                  htmlFor="corridor-password"
                  className="text-[10px] font-semibold uppercase tracking-[0.08em] text-cream/70"
                >
                  Password
                </label>
                <div className="relative mt-1.5">
                  <span className="pointer-events-none absolute left-3 top-1/2 z-10 -translate-y-1/2 text-muted">
                    <KeyRound size={12} />
                  </span>
                  <input
                    id="corridor-password"
                    type="password"
                    inputMode="numeric"
                    autoComplete="current-password"
                    value={password}
                    onChange={(event) => {
                      setPassword(event.target.value);
                      setError(null);
                    }}
                    placeholder="Enter corridor password"
                    className="w-full rounded border border-line bg-black/45 py-3 pl-9 pr-3 text-[13px] text-cream outline-none transition-colors placeholder:text-muted/70 focus:border-accent/70"
                  />
                </div>
                {error ? <p className="mt-2 text-[11px] text-ember">{error}</p> : null}
              </div>

              <button
                type="submit"
                className="flex w-full items-center justify-center gap-2 rounded bg-accent py-3.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-[#180b05] transition-colors duration-150 hover:bg-[#ff8347]"
              >
                <Lock size={13} />
                Enter control
                <ArrowRight size={13} />
              </button>
            </form>

            <div className="mt-4 flex items-center gap-2 border-t border-line pt-3 text-[10.5px] text-muted">
              <span>Demo access code</span>
              <span className="num ml-auto text-cream">7800</span>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}

function Field({ icon, label, value }: { icon: ReactNode; label: string; value: string }) {
  return (
    <div>
      <label className="text-[10px] font-semibold uppercase tracking-[0.08em] text-cream/70">{label}</label>
      <div className="relative mt-1.5">
        <span className="pointer-events-none absolute left-3 top-1/2 z-10 -translate-y-1/2 text-muted">{icon}</span>
        <input
          value={value}
          readOnly
          className="w-full truncate rounded border border-line bg-black/45 py-3 pl-9 pr-2 text-[12.5px] text-cream/85 outline-none focus:border-line"
        />
      </div>
    </div>
  );
}

function RailMark() {
  return (
    <span className="flex h-6 w-6 items-center justify-center rounded-[3px] bg-accent text-[#180b05]">
      <svg width="13" height="13" viewBox="0 0 16 16" aria-hidden>
        <path d="M3.5 2v12M12.5 2v12M3.5 6h9M3.5 10h9" stroke="currentColor" strokeWidth="1.6" fill="none" />
      </svg>
    </span>
  );
}
