import { AlertOctagon, ArrowUpRight, Clock3, Crosshair } from "lucide-react";
import { useMemo, useState } from "react";
import { Button, Card, EmptyState, SectionHead, Segmented, cn } from "@/components/ui";
import { fmtClock } from "@/lib/api";
import type { Snapshot, TrainClass } from "@/types";

const W = 1060;
const H = 580;
const M = { left: 162, right: 104, top: 52, bottom: 36 };

const CLASS_STYLE: Record<TrainClass, { color: string; width: number; dash?: string; label: string; note: string }> = {
  express: { color: "#f4ede2", width: 2.3, label: "Express", note: "solid · heavy" },
  suburban: { color: "#9dc0ff", width: 1.7, dash: "9 4", label: "Suburban", note: "long dash" },
  passenger: { color: "#f0be7a", width: 1.6, dash: "2 4", label: "Passenger", note: "fine dash" },
  freight: { color: "#c3b3c8", width: 1.5, dash: "1 5", label: "Freight", note: "dotted" },
};

type Filter = "all" | TrainClass;

interface Point {
  x: number;
  y: number;
  t: number;
  code: string;
}

function intersects(a: Point, b: Point, c: Point, d: Point) {
  const d1 = (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
  const d2 = (b.x - a.x) * (d.y - a.y) - (b.y - a.y) * (d.x - a.x);
  const d3 = (d.x - c.x) * (a.y - c.y) - (d.y - c.y) * (a.x - c.x);
  const d4 = (d.x - c.x) * (b.y - c.y) - (d.y - c.y) * (b.x - c.x);
  if (d1 * d2 < 0 && d3 * d4 < 0) {
    const t = d1 / (d1 - d2);
    return { x: a.x + t * (b.x - a.x), y: a.y + t * (b.y - a.y) };
  }
  return null;
}

export function RegulatorView({
  snap,
  onSelectTrain,
}: {
  snap: Snapshot;
  onSelectTrain?: (trainNo: string) => void;
}) {
  const [filter, setFilter] = useState<Filter>("all");
  const [selected, setSelected] = useState<string | null>(null);

  const stations = snap.corridor.stations;
  const stationKm = useMemo(
    () => Object.fromEntries(stations.map((station) => [station.code, station.km])),
    [stations],
  );
  const totalKm = stations[stations.length - 1].km;

  const start = Math.max(240, Math.floor((snap.now - 45) / 30) * 30);
  const end = start + 240;

  const plotW = W - M.left - M.right;
  const plotH = H - M.top - M.bottom;
  const x = (min: number) => M.left + ((min - start) / (end - start)) * plotW;
  const y = (km: number) => M.top + (km / totalKm) * plotH;

  const hourTicks: number[] = [];
  for (let tick = Math.ceil(start / 60) * 60; tick <= end; tick += 60) hourTicks.push(tick);
  const quarterTicks: number[] = [];
  for (let tick = Math.ceil(start / 15) * 15; tick <= end; tick += 15) quarterTicks.push(tick);

  const visible = useMemo(
    () =>
      snap.trains.filter((train) => {
        if (train.status === "cancelled") return false;
        return train.stops.some((stop) => stop.arr >= start - 130 && stop.arr <= end + 130);
      }),
    [snap.trains, start, end],
  );

  const shown = useMemo(
    () => visible.filter((train) => (filter === "all" ? true : train.cls === filter)),
    [visible, filter],
  );

  const paths = useMemo(
    () =>
      shown.map((train) => {
        const points: Point[] = [];
        for (const stop of train.stops) {
          if (stop.arr >= start - 130 && stop.arr <= end + 130) {
            points.push({ x: x(stop.arr), y: y(stationKm[stop.code] ?? 0), t: stop.arr, code: stop.code });
          }
          if (stop.dep > stop.arr && stop.dep >= start - 130 && stop.dep <= end + 130) {
            points.push({ x: x(stop.dep), y: y(stationKm[stop.code] ?? 0), t: stop.dep, code: stop.code });
          }
        }
        const inWindow = points.filter((point) => point.x >= M.left && point.x <= M.left + plotW);
        return {
          train,
          points,
          last: inWindow[inWindow.length - 1] ?? null,
          first: inWindow[0] ?? null,
        };
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [shown, start, end, stationKm, totalKm],
  );

  const crossings = useMemo(() => {
    const marks: { x: number; y: number; label: string }[] = [];
    const ups = paths.filter((path) => path.train.dir === "UP");
    const downs = paths.filter((path) => path.train.dir === "DOWN");
    for (const up of ups) {
      for (const down of downs) {
        for (let i = 0; i < up.points.length - 1; i += 1) {
          for (let j = 0; j < down.points.length - 1; j += 1) {
            const hit = intersects(up.points[i], up.points[i + 1], down.points[j], down.points[j + 1]);
            if (!hit) continue;
            if (hit.x < M.left || hit.x > M.left + plotW) continue;
            marks.push({
              x: hit.x,
              y: hit.y,
              label: `${up.train.no} / ${down.train.no} · ${fmtClock(up.points[i].t)}`,
            });
          }
        }
      }
    }
    return marks.slice(0, 60);
  }, [paths, plotW]);

  const selectedTrain = selected ? shown.find((train) => train.no === selected) ?? null : null;

  // Right-hand labels, nudged apart so nothing overlaps.
  const labels = useMemo(() => {
    const list = paths
      .map((path) => ({
        no: path.train.no,
        cls: path.train.cls,
        delay: path.train.delay,
        status: path.train.status,
        anchorX: path.last?.x ?? M.left,
        anchorY: path.last?.y ?? M.top,
        labelY: path.last?.y ?? M.top,
      }))
      .sort((a, b) => a.anchorY - b.anchorY);
    for (let i = 1; i < list.length; i += 1) {
      if (list[i].labelY - list[i - 1].labelY < 11.5) list[i].labelY = list[i - 1].labelY + 11.5;
    }
    const overflow = list.length ? list[list.length - 1].labelY - (M.top + plotH) : 0;
    if (overflow > 0) for (const item of list) item.labelY -= overflow;
    return list;
  }, [paths, plotH]);

  const counts = useMemo(() => {
    const byClass = { express: 0, suburban: 0, passenger: 0, freight: 0 } as Record<TrainClass, number>;
    for (const train of visible) byClass[train.cls] += 1;
    return byClass;
  }, [visible]);

  return (
    <div className="space-y-5">
      <Card>
        <SectionHead
          label="Traffic regulator · Marey diagram"
          title="Time – distance chart"
          right={
            <div className="flex flex-wrap items-center gap-2">
              <Segmented<Filter>
                size="sm"
                value={filter}
                onChange={(next) => {
                  setFilter(next);
                  setSelected(null);
                }}
                options={[
                  { id: "all", label: "All" },
                  { id: "express", label: "Express" },
                  { id: "suburban", label: "Suburban" },
                  { id: "passenger", label: "Pass." },
                  { id: "freight", label: "Freight" },
                ]}
              />
            </div>
          }
        />

        <div className="mb-4 flex flex-wrap items-center gap-x-6 gap-y-2">
          {(Object.keys(CLASS_STYLE) as TrainClass[]).map((cls) => {
            const style = CLASS_STYLE[cls];
            return (
              <div key={cls} className="flex items-center gap-2">
                <svg width="34" height="8" aria-hidden>
                  <line
                    x1="0"
                    y1="4"
                    x2="34"
                    y2="4"
                    stroke={style.color}
                    strokeWidth={style.width}
                    strokeDasharray={style.dash}
                    strokeLinecap="round"
                  />
                </svg>
                <span className="text-[11px] text-cream/80">{style.label}</span>
                <span className="num text-[10px] text-muted">{counts[cls]}</span>
              </div>
            );
          })}
          <span className="text-[10.5px] text-muted">distance ↓ · time →</span>
        </div>

        {selectedTrain ? (
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-cream/25 bg-cream/[0.05] px-4 py-3">
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
              <span className="num text-[13px] text-cream">{selectedTrain.no}</span>
              <span className="text-[12px] text-cream/80">{selectedTrain.name}</span>
              <span className="text-[11px] text-muted">{selectedTrain.cls}</span>
              <span className={cn("num text-[11.5px]", selectedTrain.delay > 5 ? "text-ember" : "text-signal")}>
                {selectedTrain.delay > 0 ? `+${selectedTrain.delay} min at destination` : "on time"}
              </span>
              <span className="text-[11px] text-muted">
                next {selectedTrain.nextName} · {fmtClock(selectedTrain.eta)}
              </span>
            </div>
            <div className="flex items-center gap-2">
              {onSelectTrain ? (
                <Button variant="ghost" icon={<ArrowUpRight size={12} />} onClick={() => onSelectTrain(selectedTrain.no)}>
                  Open train
                </Button>
              ) : null}
              <Button variant="plain" onClick={() => setSelected(null)}>
                Clear
              </Button>
            </div>
          </div>
        ) : (
          <p className="mb-4 text-[11px] text-muted">
            Click a path to isolate a train. Steep lines are standing, shallow lines are running; trains that stop
            show a horizontal segment on the station row.
          </p>
        )}

        <div className="overflow-x-auto">
          <svg
            viewBox={`0 0 ${W} ${H}`}
            className="h-[580px] w-full min-w-[880px]"
            role="img"
            aria-label="Time distance chart of trains in the section"
          >
            <defs>
              <clipPath id="plot">
                <rect x={M.left} y={M.top} width={plotW} height={plotH} />
              </clipPath>
            </defs>

            <rect x={M.left} y={M.top} width={plotW} height={plotH} fill="rgba(255,255,255,0.015)" />

            {quarterTicks.map((tick) => (
              <line
                key={`q-${tick}`}
                x1={x(tick)}
                y1={M.top}
                x2={x(tick)}
                y2={M.top + plotH}
                stroke="rgba(244,237,226,0.045)"
                strokeDasharray="2 9"
              />
            ))}

            {hourTicks.map((tick) => (
              <g key={`h-${tick}`}>
                <line x1={x(tick)} y1={M.top} x2={x(tick)} y2={M.top + plotH} stroke="rgba(244,237,226,0.13)" />
                <text x={x(tick)} y={M.top - 16} textAnchor="middle" fontSize={9.5} letterSpacing={0.6} fill="#9a9ca1">
                  {fmtClock(tick)}
                </text>
              </g>
            ))}

            {stations.map((station) => (
              <g key={station.code}>
                <line
                  x1={M.left}
                  y1={y(station.km)}
                  x2={M.left + plotW}
                  y2={y(station.km)}
                  stroke="rgba(244,237,226,0.09)"
                />
                <circle cx={M.left} cy={y(station.km)} r={2.8} fill="#08090b" stroke="#f4ede2" strokeOpacity={0.55} />
                <text
                  x={M.left - 16}
                  y={y(station.km) + 3}
                  textAnchor="end"
                  fontSize={10.5}
                  fill={station.major ? "#f4ede2" : "#a9abb0"}
                  letterSpacing={0.2}
                >
                  {station.name}
                </text>
                <text x={M.left - 16} y={y(station.km) + 15} textAnchor="end" fontSize={8} letterSpacing={1} fill="#6f7176">
                  {station.code} · {station.km} km · {station.platforms} PF
                </text>
              </g>
            ))}

            {/* scheduled baseline of the selected train */}
            {selectedTrain ? (
              <g clipPath="url(#plot)">
                <polyline
                  fill="none"
                  stroke="rgba(244,237,226,0.35)"
                  strokeWidth={1}
                  strokeDasharray="3 6"
                  points={selectedTrain.stops
                    .flatMap((stop) => [
                      { x: x(stop.schedArr), y: y(stationKm[stop.code] ?? 0) },
                      ...(stop.schedDep > stop.schedArr ? [{ x: x(stop.schedDep), y: y(stationKm[stop.code] ?? 0) }] : []),
                    ])
                    .map((point) => `${point.x},${point.y}`)
                    .join(" ")}
                />
              </g>
            ) : null}

            <g clipPath="url(#plot)">
              {paths.map(({ train, points }, pathIndex) => {
                const style = CLASS_STYLE[train.cls];
                const dim = selected && selected !== train.no;
                const active = selected === train.no;
                return (
                  <g key={train.no} opacity={dim ? 0.16 : 1}>
                    <polyline
                      className="path-in"
                      style={{ animationDelay: `${pathIndex * 26}ms` }}
                      points={points.map((point) => `${point.x},${point.y}`).join(" ")}
                      fill="none"
                      stroke={style.color}
                      strokeWidth={active ? style.width + 0.9 : style.width}
                      strokeDasharray={style.dash}
                      strokeLinejoin="round"
                      strokeLinecap="round"
                    />
                    <polyline
                      points={points.map((point) => `${point.x},${point.y}`).join(" ")}
                      fill="none"
                      stroke="transparent"
                      strokeWidth={10}
                      className="cursor-pointer"
                      onClick={(event) => {
                        event.stopPropagation();
                        setSelected(active ? null : train.no);
                      }}
                    >
                      <title>{`${train.no} ${train.name} · ${style.label} · ${train.delay > 0 ? `+${train.delay} min` : "on time"}`}</title>
                    </polyline>
                    {train.hold ? (
                      <rect
                        x={x(train.hold.untilMin) - 3}
                        y={y(stationKm[train.hold.station] ?? 0) - 3}
                        width={6}
                        height={6}
                        fill="#9dc0ff"
                        stroke="#08090b"
                      >
                        <title>{`Held at ${train.hold.station} until ${fmtClock(train.hold.untilMin)}`}</title>
                      </rect>
                    ) : null}
                  </g>
                );
              })}

              {crossings.map((mark, index) => (
                <g key={`cross-${index}`} opacity={0.85}>
                  <circle cx={mark.x} cy={mark.y} r={4.2} fill="#08090b" stroke="#f4ede2" strokeOpacity={0.45} />
                  <path
                    d={`M${mark.x - 2} ${mark.y - 2} L${mark.x + 2} ${mark.y + 2} M${mark.x + 2} ${mark.y - 2} L${mark.x - 2} ${mark.y + 2}`}
                    stroke="#f4ede2"
                    strokeOpacity={0.7}
                    strokeWidth={1}
                  >
                    <title>{`Crossing: ${mark.label}`}</title>
                  </path>
                </g>
              ))}

              {snap.conflicts.map((conflict) => {
                const block = snap.corridor.blocks.find((item) => item.id === conflict.blockId);
                if (!block) return null;
                const midKm = ((stationKm[block.from] ?? 0) + (stationKm[block.to] ?? 0)) / 2;
                const [hh, mm] = conflict.at.split(":").map(Number);
                const at = hh * 60 + mm;
                if (at < start || at > end) return null;
                return (
                  <g key={conflict.id}>
                    <path
                      d={`M${x(at)} ${y(midKm) - 5} L${x(at) + 5} ${y(midKm)} L${x(at)} ${y(midKm) + 5} L${x(at) - 5} ${y(midKm)} Z`}
                      fill="#ff9a83"
                      fillOpacity={0.9}
                      stroke="#08090b"
                      strokeWidth={0.7}
                    >
                      <title>{`${conflict.kind} · ${conflict.blockId} · ${conflict.trains.join(" / ")}`}</title>
                    </path>
                  </g>
                );
              })}
            </g>

            <line
              x1={x(snap.now)}
              y1={M.top - 8}
              x2={x(snap.now)}
              y2={M.top + plotH}
              stroke="#a3313f"
              strokeWidth={1.5}
            />
            <rect x={x(snap.now) - 19} y={M.top - 28} width={38} height={15} rx={3} fill="#7c1f2b" />
            <text x={x(snap.now)} y={M.top - 17.5} textAnchor="middle" fontSize={8} fill="#f4ede2" letterSpacing={1}>
              NOW
            </text>

            {labels.map((label) => {
              const style = CLASS_STYLE[label.cls];
              const dim = selected ? selected !== label.no : false;
              return (
                <g key={`label-${label.no}`} opacity={dim ? 0.25 : 1}>
                  <line
                    x1={label.anchorX}
                    y1={label.anchorY}
                    x2={M.left + plotW + 14}
                    y2={label.labelY}
                    stroke={style.color}
                    strokeOpacity={0.25}
                    strokeWidth={0.8}
                  />
                  <text x={M.left + plotW + 18} y={label.labelY + 3} fontSize={9.5} fill={style.color} letterSpacing={0.3}>
                    {label.no}
                    {label.delay > 0 ? (
                      <tspan fill="#ff9a83" fontSize={8.5}>
                        {` +${label.delay}`}
                      </tspan>
                    ) : null}
                  </text>
                </g>
              );
            })}

            <text x={M.left} y={H - 10} fontSize={8.5} letterSpacing={1.6} fill="#6f7176">
              DISTANCE FROM SECUNDERABAD (km)
            </text>
            <text x={M.left + plotW} y={H - 10} textAnchor="end" fontSize={8.5} letterSpacing={1.6} fill="#6f7176">
              MODEL ESTIMATE · SYNTHETIC TIMETABLE
            </text>
          </svg>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2 border-t border-line pt-3 text-[10.5px] text-muted">
          <span className="inline-flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-sm bg-ice" /> hold
          </span>
          <span className="inline-flex items-center gap-1.5">
            <Crosshair size={11} /> crossing
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rotate-45 bg-ember" /> conflict
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="h-px w-4 bg-cream/35" /> selected baseline
          </span>
          <span className="ml-auto">
            Dwell appears as a horizontal segment · slope shows speed
          </span>
        </div>
      </Card>

      <div className="grid gap-4 lg:grid-cols-[1.15fr_1fr]">
        <Card>
          <SectionHead
            label={`${snap.conflicts.length} flagged`}
            title="Block conflicts"
            right={<AlertOctagon size={16} className={snap.conflicts.length ? "text-ember" : "text-signal"} />}
          />
          {snap.conflicts.length === 0 ? (
            <EmptyState title="Headways hold" body="No projected occupancy overlap in the next five hours." />
          ) : (
            <ul className="space-y-2.5">
              {snap.conflicts.map((conflict) => (
                <li key={conflict.id} className="rounded-xl border border-ember/25 bg-ember/[0.05] px-4 py-3">
                  <div className="flex items-center justify-between gap-3">
                    <p className="text-[12.5px] text-cream">{conflict.kind}</p>
                    <span className="num text-[10.5px] text-ember">
                      {conflict.gap < 0 ? `${Math.abs(conflict.gap)} min overlap` : `${conflict.gap} min margin`}
                    </span>
                  </div>
                  <p className="mt-1 text-[11px] text-muted">
                    {conflict.blockLabel} · {conflict.track} line · {conflict.trains.join(" / ")} at {conflict.at}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <div className="space-y-4">
          <Card>
            <SectionHead label="Held in section" title="Controller holds" right={<Clock3 size={16} className="text-ice" />} />
            {snap.trains.filter((train) => train.status === "held").length === 0 ? (
              <EmptyState title="Nothing standing" body="Trains are running to the projected timetable." />
            ) : (
              <ul className="space-y-2">
                {snap.trains
                  .filter((train) => train.status === "held")
                  .map((train) => (
                    <li
                      key={train.no}
                      className="flex items-center justify-between gap-3 rounded-xl border border-ice/25 bg-ice/[0.05] px-4 py-2.5"
                    >
                      <div className="min-w-0">
                        <p className="num text-[12px] text-cream">{train.no}</p>
                        <p className="truncate text-[11px] text-muted">
                          {train.name} · {train.hold?.station ?? train.nextCode}
                        </p>
                      </div>
                      <span className="num text-[11.5px] text-ice">
                        {train.hold ? fmtClock(train.hold.untilMin) : "—"}
                      </span>
                    </li>
                  ))}
              </ul>
            )}
          </Card>

          <Card>
            <SectionHead label="Traffic mix" title="Class balance" />
            <div className="space-y-2.5">
              {(Object.keys(CLASS_STYLE) as TrainClass[]).map((cls) => {
                const style = CLASS_STYLE[cls];
                const pct = visible.length ? (counts[cls] / visible.length) * 100 : 0;
                return (
                  <div key={cls}>
                    <div className="flex items-center justify-between text-[10.5px]">
                      <span className="text-[11px] text-cream/80">{style.label}</span>
                      <span className="num text-muted">
                        {counts[cls]} · {style.note}
                      </span>
                    </div>
                    <div className="mt-1.5 h-[3px] w-full overflow-hidden rounded-full bg-white/5">
                      <div
                        className="h-full rounded-full transition-[width] duration-700"
                        style={{ width: `${pct}%`, background: style.color }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
