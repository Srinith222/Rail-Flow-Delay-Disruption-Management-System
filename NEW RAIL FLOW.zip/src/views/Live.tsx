import { ArrowUpRight, Cable, ExternalLink, KeyRound, RefreshCw, RadioTower, TriangleAlert } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { Button, Card, EmptyState, SectionHead, Segmented, StatusBadge, cn } from "@/components/ui";
import { apiGet, fmtClock } from "@/lib/api";
import type { LiveBoard, LiveStatus, Snapshot } from "@/types";

const STATIONS = ["SC", "MED", "WDR", "BMO", "MOB", "ME", "MJF"];

export function LiveView({
  snap,
  post,
  busy,
}: {
  snap: Snapshot;
  post: <T,>(path: string, body?: unknown) => Promise<T | null>;
  busy: boolean;
}) {
  const [status, setStatus] = useState<LiveStatus | null>(null);
  const [board, setBoard] = useState<LiveBoard | null>(null);
  const [station, setStation] = useState("SC");
  const [hours, setHours] = useState<"2" | "4" | "6" | "8">("4");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [keyInput, setKeyInput] = useState("");
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  const loadBoard = useCallback(
    async (code: string, window: string, refresh = false) => {
      setLoading(true);
      setError(null);
      try {
        const data = await apiGet<{ board: LiveBoard; status: LiveStatus }>(
          `/api/live/board?station=${code}&hours=${window}${refresh ? "&refresh=1" : ""}`,
        );
        setBoard(data.board);
        setStatus(data.status);
        if (refresh) {
          setNotice(
            `Board refreshed at ${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}${data.board.stale ? " — provider failed, showing the last saved response" : ""}`,
          );
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : "Live board unavailable");
      } finally {
        setLoading(false);
      }
    },
    [],
  );

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const data = await apiGet<LiveStatus>("/api/live/status");
        if (!alive) return;
        setStatus(data);
        if (data.configured) void loadBoard("SC", "4");
      } catch {
        if (alive) setStatus(null);
      }
    })();
    return () => {
      alive = false;
    };
  }, [loadBoard]);

  async function saveKey() {
    if (!keyInput.trim()) return;
    setSaving(true);
    setError(null);
    try {
      const response = await fetch("/api/live/key", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ apiKey: keyInput.trim() }),
      });
      const data = (await response.json()) as { status?: LiveStatus; error?: string };
      if (!response.ok) throw new Error(data.error ?? "Could not save the key");
      setStatus(data.status ?? null);
      setKeyInput("");
      setNotice("Key saved on the server. Loading the Secunderabad board…");
      await loadBoard("SC", "4", true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save the key");
    } finally {
      setSaving(false);
    }
  }

  async function adopt(number: string, name: string, delay: number) {
    const result = await post("/api/live/adopt", {
      trainNumber: number,
      trainName: name,
      delayMinutes: delay,
      station: board?.station.code ?? station,
    });
    if (result) setNotice(`${number} logged to the disruption desk as ${delay} min late.`);
  }

  const connected = Boolean(status?.configured);
  const delayed = board?.trains.filter((t) => t.delayMinutes >= 5) ?? [];

  return (
    <div className="space-y-5">
      <Card>
        <SectionHead
          label="External reference feed"
          title="Live train data"
          right={
            <div className="flex flex-wrap items-center gap-2">
              <span
                className={cn(
                  "inline-flex items-center gap-2 rounded border px-2.5 py-1 text-[11px]",
                  connected ? "border-signal/40 text-signal" : "border-line text-muted",
                )}
              >
                <span className={cn("h-1.5 w-1.5 rounded-full", connected ? "bg-signal live-dot" : "bg-muted")} />
                {connected ? "RailRadar connected" : "Not connected"}
              </span>
              {connected ? (
                <button
                  type="button"
                  onClick={() => {
                    setBoard(null);
                    setNotice(null);
                    void post("/api/live/key", { clear: true }).then(() => setStatus((prev) => (prev ? { ...prev, configured: false } : prev)));
                  }}
                  className="chip"
                >
                  Disconnect
                </button>
              ) : null}
            </div>
          }
        />

        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap gap-2">
            {STATIONS.map((code) => (
              <button
                key={code}
                type="button"
                disabled={!connected}
                onClick={() => {
                  setStation(code);
                  setBoard(null);
                  void loadBoard(code, hours);
                }}
                className={cn("chip disabled:opacity-40", station === code && connected && "chip-on")}
              >
                {code}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <Segmented<"2" | "4" | "6" | "8">
              size="sm"
              value={hours}
              onChange={(value) => {
                setHours(value);
                if (connected) {
                  setBoard(null);
                  void loadBoard(station, value);
                }
              }}
              options={[
                { id: "2", label: "2h" },
                { id: "4", label: "4h" },
                { id: "6", label: "6h" },
                { id: "8", label: "8h" },
              ]}
            />
            <Button
              variant="ghost"
              disabled={!connected || loading}
              icon={<RefreshCw size={13} className={loading ? "animate-spin" : undefined} />}
              onClick={() => void loadBoard(station, hours, true)}
            >
              {loading ? "Refreshing…" : "Refresh"}
            </Button>
          </div>
        </div>

        {error ? (
          <div className="mb-4 rounded-xl border border-ember/30 bg-ember/[0.07] px-4 py-3 text-[11.5px] text-ember">
            {error}
          </div>
        ) : null}
        {notice ? (
          <div className="mb-4 rounded-xl border border-signal/30 bg-signal/[0.06] px-4 py-3 text-[11.5px] text-signal">
            {notice}
          </div>
        ) : null}

        {!connected ? (
          <ConnectPanel
            keyInput={keyInput}
            onKeyInput={setKeyInput}
            onSave={saveKey}
            saving={saving}
            status={status}
          />
        ) : board ? (
          <>
            <div className="mb-3 flex flex-wrap items-center gap-x-5 gap-y-1 text-[10.5px] text-muted">
              <span className="text-cream/80">
                {board.station.name} ({board.station.code})
              </span>
              {board.window ? (
                <span>
                  window {board.window.from} – {board.window.to} IST
                </span>
              ) : null}
              <span>{board.count} services</span>
              <span className="inline-flex items-center gap-1.5">
                <Cable size={11} /> {board.cached ? "cached" : "fresh"}
                {board.stale ? " · stale" : ""}
              </span>
              {board.fetchedAt ? (
                <span className="num">updated {new Date(board.fetchedAt).toLocaleTimeString()}</span>
              ) : null}
            </div>

            {board.trains.length === 0 ? (
              <EmptyState title="No services in this window" body="Try a wider hours window or another station." />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[880px] border-collapse text-left">
                  <thead>
                    <tr className="text-[10px] font-medium uppercase tracking-[0.04em] text-muted">
                      <th className="pb-3 font-normal">Train</th>
                      <th className="pb-3 font-normal">Type</th>
                      <th className="pb-3 font-normal">From → to</th>
                      <th className="pb-3 font-normal">Schedule</th>
                      <th className="pb-3 font-normal">Expected</th>
                      <th className="pb-3 font-normal">Delay</th>
                      <th className="pb-3 font-normal">PF</th>
                      <th className="pb-3 font-normal">Status</th>
                      <th className="pb-3 text-right font-normal">Desk</th>
                    </tr>
                  </thead>
                  <tbody>
                    {board.trains.map((train) => (
                      <tr key={`${train.number}-${train.sequence}`} className="rail-row border-t border-line">
                        <td className="py-3 pr-4">
                          <p className="num text-[12.5px] text-cream">{train.number}</p>
                          <p className="text-[11px] text-muted">{train.name}</p>
                        </td>
                        <td className="pr-4 text-[10.5px] text-muted">{train.type || "—"}</td>
                        <td className="pr-4 text-[11px] text-muted">
                          {train.source} → {train.destination}
                        </td>
                        <td className="num pr-4 text-[12px] text-cream/85">
                          {train.scheduledArrival ?? train.scheduledDeparture ?? "—"}
                        </td>
                        <td className="num pr-4 text-[12px] text-cream">
                          {formatIso(train.expectedArrival ?? train.expectedDeparture) ?? "—"}
                        </td>
                        <td
                          className={cn(
                            "num pr-4 text-[12px]",
                            train.delayMinutes >= 15 ? "text-ember" : train.delayMinutes >= 5 ? "text-amber" : "text-signal",
                          )}
                        >
                          {train.delayMinutes > 0 ? `+${train.delayMinutes}` : "0"}
                        </td>
                        <td className="num pr-4 text-[11.5px] text-muted">{train.platform ?? "—"}</td>
                        <td className="pr-4">
                          <StatusBadge
                            status={train.status === "cancelled" ? "delayed" : train.status === "at-station" ? "held" : "running"}
                            label={train.status}
                          />
                        </td>
                        <td className="text-right">
                          <button
                            type="button"
                            disabled={busy || train.delayMinutes < 5}
                            onClick={() => void adopt(train.number, train.name, train.delayMinutes)}
                            className="group inline-flex items-center gap-1.5 rounded border border-line px-2.5 py-1 text-[11px] text-cream/70 transition-colors hover:border-cream/30 hover:text-cream disabled:opacity-30"
                          >
                            {train.inModel ? "In model" : "Log late"}
                            <ArrowUpRight size={11} className="arrow-slide" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            <div className="mt-4 flex flex-wrap items-center gap-x-6 gap-y-2 border-t border-line pt-3 text-[10.5px] text-muted">
              <span>{delayed.length} services running late in this window</span>
              {status?.quota?.remainingMonth !== null && status?.quota?.remainingMonth !== undefined ? (
                <span className="num">
                  quota {status.quota.remainingMonth}/{status.quota.limitMonth} requests left this month
                </span>
              ) : null}
              <span>Cached for {Math.round((status?.cacheSeconds ?? 900) / 60)} minutes to protect your quota</span>
            </div>
          </>
        ) : (
          <div className="rounded-xl border border-line px-5 py-10 text-center text-[12px] text-muted">
            {loading ? "Loading live board…" : "Pick a station to load the live board."}
          </div>
        )}
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <SectionHead label="What this is" title="Provider data, not control" />
          <ul className="space-y-2.5 text-[11.5px] leading-relaxed text-muted">
            <li>
              · RailRadar supplies scheduled and expected times, delay and status for a station window. An entry
              marked <span className="text-cream/80">scheduled</span> has no live observation behind it.
            </li>
            <li>
              · The board is a reference display. It is not block occupancy, not a signalling state, and it does
              not tell you where a train physically is.
            </li>
            <li>
              · “Log late” records the real service's delay as a simulated order on the desk, so it can drive the
              recovery workflow. It changes only the simulation.
            </li>
          </ul>
        </Card>

        <Card>
          <SectionHead label="In this window" title="Late services" />
          {delayed.length === 0 ? (
            <EmptyState
              title={connected ? "Nothing late" : "Connect RailRadar"}
              body={connected ? "No service in this window is more than five minutes late." : "Add a key to read the live board."}
            />
          ) : (
            <ul className="space-y-2">
              {delayed.slice(0, 6).map((train) => (
                <li
                  key={`${train.number}-late`}
                  className="flex items-center justify-between gap-3 rounded-xl border border-ember/25 bg-ember/[0.05] px-4 py-2.5"
                >
                  <span className="num text-[12px] text-cream">{train.number}</span>
                  <span className="min-w-0 flex-1 truncate text-[11px] text-muted">{train.name}</span>
                  <span className="num text-[11.5px] text-ember">+{train.delayMinutes} min</span>
                </li>
              ))}
            </ul>
          )}
          <p className="mt-4 flex items-center gap-2 text-[10.5px] text-muted">
            <TriangleAlert size={11} /> Simulation clock is {snap.clock}; provider window is in real IST.
          </p>
        </Card>
      </div>
    </div>
  );
}

function ConnectPanel({
  keyInput,
  onKeyInput,
  onSave,
  saving,
  status,
}: {
  keyInput: string;
  onKeyInput: (value: string) => void;
  onSave: () => void;
  saving: boolean;
  status: LiveStatus | null;
}) {
  return (
    <div className="rounded-2xl border border-line bg-black/20 p-5">
      <div className="flex items-start gap-3">
        <div className="rounded border border-line p-2.5 text-cream">
          <KeyRound size={15} />
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-[13px] text-cream">Connect your RailRadar key</p>
          <p className="mt-1.5 max-w-[62ch] text-[11.5px] leading-relaxed text-muted">
            Create a free key at railradar.in/developers, then paste it here. It is stored on the server only —
            never in the browser — and each station board is cached for 15 minutes to protect the free quota.
          </p>

          <div className="mt-4 flex flex-wrap items-center gap-2">
            <input
              type="password"
              value={keyInput}
              onChange={(event) => onKeyInput(event.target.value)}
              placeholder="rg_your_api_key"
              autoComplete="off"
              className="field max-w-[340px] flex-1 text-[12px]"
            />
            <Button variant="wine" disabled={saving || !keyInput.trim()} onClick={onSave} icon={<RadioTower size={13} />}>
              {saving ? "Saving…" : "Save & test"}
            </Button>
            <a
              href="https://railradar.in/developers"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 text-[11px] text-muted underline-offset-4 hover:text-cream hover:underline"
            >
              Get a key <ExternalLink size={11} />
            </a>
          </div>

          {status?.lastError ? (
            <p className="mt-3 text-[11px] text-ember">{status.lastError}</p>
          ) : (
            <p className="mt-3 text-[10.5px] text-muted">
              The API exposes 32 endpoints on a monthly quota; this screen only calls the station live board.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

function formatIso(value: string | null): string | null {
  if (!value) return null;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return null;
  return fmtClock(date.getHours() * 60 + date.getMinutes());
}
