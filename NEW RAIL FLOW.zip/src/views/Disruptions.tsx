import { ArrowRight, Check, Sparkles, TriangleAlert, X } from "lucide-react";
import { useState } from "react";
import { Button, Card, EmptyState, Eyebrow, SectionHead, StatusBadge, cn } from "@/components/ui";
import type { RecoveryPlan, Snapshot } from "@/types";

const KINDS = [
  { id: "block_closure", label: "Block closure" },
  { id: "loco_failure", label: "Loco failure" },
  { id: "signal_failure", label: "Signal failure" },
  { id: "speed_restriction", label: "Speed restriction" },
  { id: "platform_block", label: "Platform block" },
  { id: "late_train", label: "Late train" },
] as const;

type Kind = (typeof KINDS)[number]["id"];

export function DisruptionsView({
  snap,
  post,
  busy,
  fetchPlan,
}: {
  snap: Snapshot;
  post: <T,>(path: string, body?: unknown) => Promise<T | null>;
  busy: boolean;
  fetchPlan: (id: string) => Promise<RecoveryPlan | null>;
}) {
  const blocks = snap.corridor.blocks;
  const stations = snap.corridor.stations;
  const [kind, setKind] = useState<Kind>("block_closure");
  const [blockId, setBlockId] = useState(blocks[2]?.id ?? blocks[0].id);
  const [stationCode, setStationCode] = useState(stations[0].code);
  const [trainNo, setTrainNo] = useState(snap.trains[0]?.no ?? "");
  const [duration, setDuration] = useState(35);
  const [reason, setReason] = useState("");

  const [planFor, setPlanFor] = useState<string | null>(null);
  const [plan, setPlan] = useState<RecoveryPlan | null>(null);
  const [planLoading, setPlanLoading] = useState(false);

  const needsBlock = kind !== "late_train" && kind !== "platform_block";

  async function submit() {
    const result = await post("/api/disruptions", {
      kind,
      blockId: needsBlock ? blockId : null,
      stationCode: kind === "platform_block" ? stationCode : null,
      trainNo: kind === "late_train" ? trainNo : null,
      durationMin: duration,
      reason: reason || undefined,
      severity: duration > 45 ? "high" : duration < 15 ? "low" : "medium",
    });
    if (result) {
      setReason("");
      setPlan(null);
      setPlanFor(null);
    }
  }

  async function openPlan(id: string) {
    setPlanFor(id);
    setPlanLoading(true);
    const next = await fetchPlan(id);
    setPlan(next);
    setPlanLoading(false);
  }

  return (
    <div className="grid gap-5 xl:grid-cols-[380px_1fr]">
      <Card className="h-fit">
        <SectionHead label="Incident desk" title="Report disruption" />
        <p className="mb-5 text-[12px] leading-relaxed text-muted">
          Every report immediately reshapes the simulated timetable. Nothing here reaches real signalling.
        </p>

        <div className="space-y-4">
          <div>
            <Eyebrow className="mb-2">Failure mode</Eyebrow>
            <div className="flex flex-wrap gap-2">
              {KINDS.map((option) => (
                <button
                  key={option.id}
                  type="button"
                  onClick={() => setKind(option.id)}
                  className={cn("chip", kind === option.id && "chip-on")}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>

          {needsBlock ? (
            <div>
              <Eyebrow className="mb-2">Block</Eyebrow>
              <select value={blockId} onChange={(e) => setBlockId(e.target.value)} className="field text-[12.5px]">
                {blocks.map((block) => (
                  <option key={block.id} value={block.id} className="bg-[#12151a]">
                    {block.id} · {block.track} line · {block.km} km
                  </option>
                ))}
              </select>
            </div>
          ) : null}

          {kind === "platform_block" ? (
            <div>
              <Eyebrow className="mb-2">Station</Eyebrow>
              <select
                value={stationCode}
                onChange={(e) => setStationCode(e.target.value)}
                className="field text-[12.5px]"
              >
                {stations.map((station) => (
                  <option key={station.code} value={station.code} className="bg-[#12151a]">
                    {station.code} · {station.name}
                  </option>
                ))}
              </select>
            </div>
          ) : null}

          {kind === "late_train" ? (
            <div>
              <Eyebrow className="mb-2">Train</Eyebrow>
              <select value={trainNo} onChange={(e) => setTrainNo(e.target.value)} className="field text-[12.5px]">
                {snap.trains.map((train) => (
                  <option key={train.no} value={train.no} className="bg-[#12151a]">
                    {train.no} · {train.name}
                  </option>
                ))}
              </select>
            </div>
          ) : null}

          <div>
            <div className="mb-2 flex items-center justify-between">
              <Eyebrow>Duration</Eyebrow>
              <span className="num text-[12px] text-cream">{duration} min</span>
            </div>
            <input
              type="range"
              min={5}
              max={180}
              step={5}
              value={duration}
              onChange={(e) => setDuration(Number(e.target.value))}
              className="w-full accent-[#7c1f2b]"
            />
            <div className="num mt-1 flex justify-between text-[9.5px] text-muted">
              <span>5</span>
              <span>180</span>
            </div>
          </div>

          <div>
            <Eyebrow className="mb-2">Cause note</Eyebrow>
            <input
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. engineering block, axle counter failure"
              className="field text-[12.5px]"
            />
          </div>

          <Button
            variant="wine"
            className="w-full"
            disabled={busy}
            icon={<TriangleAlert size={14} />}
            onClick={() => void submit()}
          >
            Log disruption
          </Button>
        </div>
      </Card>

      <div className="space-y-4">
        <Card>
          <SectionHead
            label={`${snap.disruptions.length} active`}
            title="Open orders"
            right={
              <Button variant="ghost" onClick={() => void post("/api/reset")} icon={<X size={12} />}>
                Reset sim
              </Button>
            }
          />
          {snap.disruptions.length === 0 ? (
            <EmptyState
              title="No active disruption"
              body="Report a block closure or a late train on the left to model the knock-on delay."
            />
          ) : (
            <ul className="space-y-3">
              {snap.disruptions.map((item) => (
                <li key={item.id} className="rounded-xl border border-line bg-black/20 p-4">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="text-[13.5px] text-cream">{item.label}</p>
                        <StatusBadge status={item.severity === "high" ? "delayed" : "held"} label={item.severity} />
                        <span className="num text-[10px] text-muted">{item.id}</span>
                      </div>
                      <p className="mt-1.5 text-[11.5px] text-muted">
                        {item.reason} · reported {item.createdAt} · window {item.durationMin} min
                      </p>
                      <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[10.5px] text-muted">
                        <span>{item.affectedTrains.length} services affected</span>
                        <span>{item.affectedDelay} accumulated delay min</span>
                        {item.fromName ? (
                          <span>
                            {item.fromName} → {item.toName}
                          </span>
                        ) : null}
                        <span className="num">{item.minutesLeft} min remaining</span>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {item.blockId ? (
                        <Button
                          variant="cream"
                          disabled={busy}
                          icon={<Sparkles size={13} />}
                          onClick={() => void openPlan(item.id)}
                        >
                          Recovery plan
                        </Button>
                      ) : null}
                      <Button
                        variant="ghost"
                        disabled={busy}
                        icon={<Check size={13} />}
                        onClick={() => void post(`/api/disruptions/${item.id}/resolve`)}
                      >
                        Clear
                      </Button>
                    </div>
                  </div>

                  {planFor === item.id ? (
                    <div className="mt-4 rounded-xl border border-cream/20 bg-cream/[0.04] p-4">
                      {planLoading ? (
                        <p className="text-[12px] text-muted">Solving priority order…</p>
                      ) : plan ? (
                        <>
                          <div className="flex flex-wrap items-center justify-between gap-3">
                            <div>
                              <Eyebrow>Proposed sequence</Eyebrow>
                              <p className="mt-1 text-[12.5px] text-cream">
                                {plan.savings > 0
                                  ? `${plan.savings} weighted minutes saved versus first-come order`
                                  : "First-come order is already the least-cost sequence"}
                              </p>
                            </div>
                            <div className="text-right">
                              <p className="num text-[18px] font-normal text-signal">{plan.savings}</p>
                              <p className="text-[9px] uppercase tracking-[0.16em] text-muted">weighted min</p>
                            </div>
                          </div>

                          {plan.items.length === 0 ? (
                            <p className="mt-3 text-[12px] text-muted">{plan.note}</p>
                          ) : (
                                                          <ol className="mt-3 divide-y divide-line border-y border-line">
                              {plan.items.map((stop) => (
                                <li
                                  key={`${stop.trainNo}-${stop.order}`}
                                  className="flex items-center justify-between gap-3 py-2"
                                >
                                  <div className="flex min-w-0 items-center gap-2.5">
                                    <span className="num text-[10px] text-muted">{String(stop.order).padStart(2, "0")}</span>
                                    <span className="num text-[11.5px] text-cream">{stop.trainNo}</span>
                                    <span className="truncate text-[11px] text-muted">
                                      {stop.stationName} · {stop.cls}
                                    </span>
                                  </div>
                                  <div className="flex shrink-0 items-center gap-3">
                                    <span className="num text-[10.5px] text-muted">slot {stop.slot}</span>
                                    <span className={cn("num text-[11px]", stop.holdMin > 0 ? "text-amber" : "text-signal")}>
                                      {stop.holdMin > 0 ? `hold ${stop.holdMin}m` : "release"}
                                    </span>
                                  </div>
                                </li>
                              ))}
                            </ol>
                          )}

                          <p className="mt-3 text-[10.5px] leading-relaxed text-muted">{plan.note}</p>

                          <div className="mt-3 flex flex-wrap gap-2">
                            <Button
                              variant="wine"
                              disabled={busy || plan.items.length === 0}
                              icon={<ArrowRight size={13} />}
                              onClick={async () => {
                                await post(`/api/replan/${item.id}/apply`);
                                setPlan(null);
                                setPlanFor(null);
                              }}
                            >
                              Issue holds
                            </Button>
                            <Button
                              variant="ghost"
                              onClick={() => {
                                setPlan(null);
                                setPlanFor(null);
                              }}
                            >
                              Discard
                            </Button>
                          </div>
                        </>
                      ) : (
                        <p className="text-[12px] text-ember">Plan could not be generated.</p>
                      )}
                    </div>
                  ) : null}
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card>
          <SectionHead label="Model behaviour" title="Delay chain" />
          <dl className="divide-y divide-line text-[12px]">
            {[
              ["Block occupancy", "The closure window applies to every service that has not yet cleared the block."],
              ["Queue headway", "Following trains inherit the reopening time plus a four-minute single-line headway each."],
              ["Priority order", "Express paths are protected first; suburban, passenger and freight paths absorb the wait."],
            ].map(([term, description]) => (
              <div key={term} className="grid gap-0.5 py-3 sm:grid-cols-[150px_1fr] sm:gap-4">
                <dt className="font-medium text-cream">{term}</dt>
                <dd className="leading-relaxed text-muted">{description}</dd>
              </div>
            ))}
          </dl>
        </Card>
      </div>
    </div>
  );
}
