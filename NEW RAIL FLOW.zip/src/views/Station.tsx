import { BellRing, Check, MapPin } from "lucide-react";
import { useState } from "react";
import { Button, Card, EmptyState, Eyebrow, SectionHead, StatusBadge, cn } from "@/components/ui";
import { classColor, fmtClock } from "@/lib/api";
import type { Snapshot } from "@/types";

export function StationView({
  snap,
  post,
  busy,
}: {
  snap: Snapshot;
  post: <T,>(path: string, body?: unknown) => Promise<T | null>;
  busy: boolean;
}) {
  const stations = snap.corridor.stations;
  const [code, setCode] = useState(stations[0].code);
  const station = stations.find((s) => s.code === code) ?? stations[0];

  const board = snap.trains
    .map((train) => {
      const idx = train.stops.findIndex((s) => s.code === code);
      if (idx < 0) return null;
      return { train, stop: train.stops[idx], index: idx };
    })
    .filter((entry): entry is { train: Snapshot["trains"][number]; stop: Snapshot["trains"][number]["stops"][number]; index: number } => Boolean(entry))
    .filter(({ stop, train }) => stop.arr > snap.now - 40 && train.status !== "cancelled")
    .sort((a, b) => a.stop.arr - b.stop.arr)
    .slice(0, 12);

  const pending = snap.instructions.filter((i) => i.status === "PENDING");
  const acknowledged = snap.instructions.filter((i) => i.status === "ACK" && i.station === code).slice(0, 5);

  return (
    <div className="space-y-5">
      <Card>
        <SectionHead
          label={`${snap.corridor.division} · station master console`}
          title={station.name}
          right={
            <div className="flex flex-wrap gap-2">
              {stations.map((item) => (
                <button
                  key={item.code}
                  type="button"
                  onClick={() => setCode(item.code)}
                  className={cn("chip", code === item.code && "chip-on")}
                >
                  {item.code}
                </button>
              ))}
            </div>
          }
        />

        <div className="mb-5 grid gap-3 sm:grid-cols-3">
          <div className="rounded border border-line px-4 py-3">
            <Eyebrow>Platforms modelled</Eyebrow>
            <p className="num mt-1 text-[20px] text-cream">{station.platforms}</p>
          </div>
          <div className="rounded border border-line px-4 py-3">
            <Eyebrow>Chainage</Eyebrow>
            <p className="num mt-1 text-[20px] text-cream">{station.km} km</p>
          </div>
          <div className="rounded border border-line px-4 py-3">
            <Eyebrow>Pending instructions</Eyebrow>
            <p className={cn("num mt-1 text-[20px]", pending.length ? "text-amber" : "text-signal")}>
              {pending.length}
            </p>
          </div>
        </div>

        {board.length === 0 ? (
          <EmptyState title="No booked movements" body="No services call at this station in the next four hours." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] border-collapse text-left">
              <thead>
                <tr className="text-[10px] font-medium uppercase tracking-[0.04em] text-muted">
                  <th className="pb-3 font-normal">Arrival</th>
                  <th className="pb-3 font-normal">Train</th>
                  <th className="pb-3 font-normal">From → to</th>
                  <th className="pb-3 font-normal">Platform</th>
                  <th className="pb-3 font-normal">Delay</th>
                  <th className="pb-3 font-normal">Working</th>
                  <th className="pb-3 text-right font-normal">Status</th>
                </tr>
              </thead>
              <tbody>
                {board.map(({ train, stop }) => (
                  <tr key={train.no} className="rail-row border-t border-line">
                    <td className="py-3.5 pr-4">
                      <p className="num text-[13px] text-cream">{fmtClock(stop.arr)}</p>
                      <p className="num text-[10.5px] text-muted">sched {fmtClock(stop.schedArr)}</p>
                    </td>
                    <td className="pr-4">
                      <p className="num text-[12px] text-cream">{train.no}</p>
                      <p className="text-[11px] text-muted">{train.name}</p>
                    </td>
                    <td className="pr-4 text-[11.5px] text-muted">
                      {train.originName} → {train.destinationName}
                    </td>
                    <td className="num pr-4 text-[12px] text-cream">{stop.platform}</td>
                    <td className={cn("num pr-4 text-[12px]", stop.shift > 5 ? "text-ember" : "text-signal")}>
                      {stop.shift > 0 ? `+${stop.shift}` : "0"}
                    </td>
                    <td className={cn("pr-4 text-[11px]", classColor(train.cls))}>
                      {train.cls}
                    </td>
                    <td className="text-right">
                      <StatusBadge status={train.status} label={train.statusLabel} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Card>
        <SectionHead
          label="Instruction book"
          title="Awaiting acknowledgement"
          right={<BellRing size={16} className={pending.length ? "text-amber" : "text-signal"} />}
        />
        {pending.length === 0 ? (
          <EmptyState title="No open instructions" body="Holds issued by the section controller appear here." />
        ) : (
          <ul className="space-y-2.5">
            {pending.map((ins) => (
              <li
                key={ins.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-amber/25 bg-amber/[0.05] px-4 py-3"
              >
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="num text-[11px] text-cream">{ins.id}</span>
                    <span className="rounded-[3px] border border-amber/40 px-2 py-0.5 text-[10px] text-amber">
                      {ins.action}
                    </span>
                    <span className="inline-flex items-center gap-1 text-[10.5px] text-muted">
                      <MapPin size={10} /> {ins.stationName}
                    </span>
                  </div>
                  <p className="mt-1 text-[12px] text-cream">
                    Hold {ins.trainNo} · {ins.trainName} for {ins.minutes} min
                  </p>
                  <p className="text-[11px] text-muted">
                    {ins.reason} · issued {ins.createdAt} by {ins.createdBy}
                  </p>
                </div>
                <Button
                  variant="cream"
                  disabled={busy}
                  icon={<Check size={13} />}
                  onClick={() => void post(`/api/instructions/${ins.id}/ack`)}
                >
                  Acknowledge
                </Button>
              </li>
            ))}
          </ul>
        )}

        {acknowledged.length > 0 ? (
          <div className="mt-5 border-t border-line pt-4">
            <Eyebrow className="mb-2">Recently acknowledged at {station.code}</Eyebrow>
            <ul className="space-y-1.5">
              {acknowledged.map((ins) => (
                <li key={ins.id} className="flex items-center justify-between gap-3 text-[11px] text-muted">
                  <span className="num">
                    {ins.id} · {ins.trainNo} · {ins.action} {ins.minutes} min
                  </span>
                  <span className="num text-signal">{ins.ackAt}</span>
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </Card>

      <p className="px-1 text-[10.5px] leading-relaxed text-muted">
        This console records simulated instructions against the model timetable. It does not issue movement
        authorities and is not connected to any signalling or interlocking system.
      </p>
    </div>
  );
}
