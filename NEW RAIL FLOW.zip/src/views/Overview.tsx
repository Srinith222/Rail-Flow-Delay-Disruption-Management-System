import {
  ArrowRight,
  ArrowUpRight,
  BellRing,
  CircleDot,
  Clock,
  Gauge,
  TriangleAlert,
  Waypoints,
} from "lucide-react";
import { CorridorStrip } from "@/components/CorridorStrip";
import { Button, Card, EmptyState, Eyebrow, SectionHead, Stat, StatusBadge, cn } from "@/components/ui";
import { classColor, fmtClock } from "@/lib/api";
import type { Snapshot, ViewId } from "@/types";

export function Overview({
  snap,
  onNavigate,
  onSelectTrain,
}: {
  snap: Snapshot;
  onNavigate: (view: ViewId) => void;
  onSelectTrain: (trainNo: string) => void;
}) {
  const live = snap.trains.filter((t) => t.status !== "arrived" && t.status !== "cancelled");
  const hero =
    [...live].filter((t) => t.cls === "express").sort((a, b) => a.eta - b.eta)[0] ??
    [...live].sort((a, b) => a.eta - b.eta)[0];

  const nextServices = [...live]
    .sort((a, b) => a.eta - b.eta)
    .slice(0, 6);
  const pending = snap.instructions.filter((i) => i.status === "PENDING");
  const topConflict = snap.conflicts[0];

  return (
    <div className="space-y-5">
      <section className="card relative overflow-hidden">
        <div className="relative grid gap-0 lg:grid-cols-[1.35fr_1fr]">
          <div className="p-7 lg:p-9">
            <Eyebrow>{snap.corridor.division}</Eyebrow>
            <h2 className="mt-3 font-display text-[28px] font-semibold leading-tight tracking-[-0.03em] text-cream lg:text-[34px]">
              {snap.corridor.name}
            </h2>
            <p className="mt-3 max-w-[56ch] text-[13px] leading-relaxed text-muted">
              Holds, precedence and recovery for the section while a block is out of service. Figures are
              produced by the corridor model; nothing here is connected to signalling.
            </p>

            <div className="mt-7 flex flex-wrap items-center gap-3">
              <Button variant="wine" icon={<TriangleAlert size={14} />} onClick={() => onNavigate("disruptions")}>
                Report disruption
              </Button>
              <Button variant="ghost" icon={<Waypoints size={14} />} onClick={() => onNavigate("regulator")}>
                Open regulator
              </Button>
            </div>

            <div className="mt-8 grid grid-cols-3 gap-4 border-t border-line pt-5">
              <div>
                <Eyebrow>On time</Eyebrow>
                <p className="num mt-1.5 text-[18px] text-signal">{snap.stats.onTimePct}%</p>
              </div>
              <div>
                <Eyebrow>Held</Eyebrow>
                <p className="num mt-1.5 text-[18px] text-ice">{snap.stats.held}</p>
              </div>
              <div>
                <Eyebrow>Active trains</Eyebrow>
                <p className="num mt-1.5 text-[18px] text-cream">{snap.stats.active}</p>
              </div>
            </div>
          </div>

          <div className="relative border-t border-line bg-gradient-to-br from-white/[0.05] via-transparent to-transparent p-7 lg:border-l lg:border-t-0 lg:p-9">
            <div className="flex items-center justify-between">
              <Eyebrow>Next priority service</Eyebrow>
                              <span className="rounded-[3px] border border-line px-2 py-0.5 text-[10px] text-muted">
                  {hero?.cls ?? "—"}
                </span>
            </div>

            {hero ? (
              <>
                <div className="mt-6 flex items-end gap-3">
                  <div>
                    <p className="num text-[32px] font-normal leading-none tracking-tight text-cream">
                      {fmtClock(hero.stops[0].dep)}
                    </p>
                    <p className="mt-1.5 text-[11px] text-muted">{hero.originName}</p>
                  </div>
                  <ArrowRight size={20} className="mb-7 text-muted" strokeWidth={1.2} />
                  <div>
                    <p className="num text-[32px] font-normal leading-none tracking-tight text-cream">
                      {fmtClock(hero.stops[hero.stops.length - 1].arr)}
                    </p>
                    <p className="mt-1.5 text-[11px] text-muted">
                      {hero.destinationName}
                    </p>
                  </div>
                </div>

                <div className="mt-6 flex items-center gap-3 border-t border-line pt-4">
                  <span className="num text-[13px] text-cream">{hero.no}</span>
                  <span className="text-[12px] text-cream/80">{hero.name}</span>
                  <StatusBadge status={hero.status} label={hero.statusLabel} />
                </div>
                <div className="mt-4 space-y-2 text-[11.5px] text-muted">
                  <div className="flex items-center justify-between">
                    <span>Next reported at</span>
                    <span className="text-cream/80">{hero.nextName}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Platform</span>
                    <span className="num text-cream/80">{hero.platform}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Delay carried</span>
                    <span className={cn("num", hero.delay > 5 ? "text-ember" : "text-signal")}>
                      {hero.delay > 0 ? `+${hero.delay} min` : "On time"}
                    </span>
                  </div>
                </div>
              </>
            ) : (
              <EmptyState title="No services in the section" body="The simulation window is empty. Reset to 07:30." />
            )}
          </div>
        </div>

        <div className="relative border-t border-line px-4 pb-6 pt-4 sm:px-6 lg:px-7">
          <div className="mb-5 flex items-baseline justify-between gap-3">
            <p className="eyebrow">Stations · 63.5 km</p>
            <p className="hidden text-[10px] text-muted sm:block">Secunderabad → Wadiaram</p>
          </div>
          <CorridorStrip snap={snap} />
        </div>
      </section>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="On-time performance" value={snap.stats.onTimePct} suffix="%" tone="signal" hint={`${snap.stats.active} services running in section`} delay={40} />
        <Stat label="Delayed services" value={snap.stats.delayed} tone="ember" hint={`Average +${snap.stats.avgDelay} min across active trains`} delay={80} />
        <Stat label="Active disruptions" value={snap.stats.activeDisruptions} tone="amber" hint={`${snap.stats.affectedTrains} services carrying knock-on delay`} delay={120} />
        <Stat label="Weighted delay" value={snap.stats.weightedDelay} suffix="min" tone="ice" hint="Priority-weighted, model estimate" delay={160} />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.5fr_1fr]">
        <Card delay={120}>
          <SectionHead
            label="Disruption desk"
            title="Active orders"
            right={
              <Button variant="ghost" onClick={() => onNavigate("disruptions")} icon={<ArrowUpRight size={13} />}>
                Desk
              </Button>
            }
          />
          {snap.disruptions.length === 0 ? (
            <EmptyState title="Corridor clear" body="No disruptions reported. Report one to model the cascade." />
          ) : (
            <ul className="stagger space-y-3">
              {snap.disruptions.map((d) => (
                <li key={d.id} className="rounded border border-line p-4 transition-colors duration-200 hover:border-cream/25">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-ember" />
                        <p className="truncate text-[13px] text-cream">{d.label}</p>
                        <span
                          className={cn(
                            "rounded-[3px] border px-2 py-0.5 text-[10px] font-medium",
                            d.severity === "high"
                              ? "border-ember/50 text-ember"
                              : d.severity === "low"
                                ? "border-line text-muted"
                                : "border-amber/40 text-amber",
                          )}
                        >
                          {d.severity}
                        </span>
                      </div>
                      <p className="mt-1.5 line-clamp-1 text-[11.5px] text-muted">{d.reason}</p>
                    </div>
                    <div className="text-right">
                      <p className="num text-[13px] text-cream">{d.minutesLeft} min</p>
                      <p className="text-[10px] text-muted">window left</p>
                    </div>
                  </div>
                  <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-1 border-t border-line pt-3 text-[10.5px] text-muted">
                    <span className="inline-flex items-center gap-1.5">
                      <TriangleAlert size={11} /> {d.affectedTrains.length} services
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <Clock size={11} /> +{d.affectedDelay} delay min
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <CircleDot size={11} /> {d.blockTrack ?? "—"} line
                    </span>
                    <span className="ml-auto num text-muted/70">{d.id}</span>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <div className="space-y-4">
          <Card delay={180}>
            <SectionHead label="Attention" title="Needs a decision" />
            <div className="space-y-3">
              {topConflict ? (
                <button
                  type="button"
                  onClick={() => onNavigate("regulator")}
                  className="group flex w-full items-start gap-3 rounded-xl border border-ember/25 bg-ember/[0.06] p-3.5 text-left transition-colors hover:border-ember/50"
                >
                  <Gauge size={16} className="mt-0.5 shrink-0 text-ember" />
                  <span className="min-w-0 flex-1">
                    <span className="block text-[12.5px] text-cream">{topConflict.kind}</span>
                    <span className="mt-0.5 block text-[11px] text-muted">
                      {topConflict.blockLabel} · {topConflict.trains.join(" / ")} at {topConflict.at}
                    </span>
                  </span>
                  <ArrowUpRight size={14} className="arrow-slide mt-1 shrink-0 text-muted" />
                </button>
              ) : (
                <div className="flex items-start gap-3 rounded-xl border border-signal/25 bg-signal/[0.05] p-3.5">
                  <Gauge size={16} className="mt-0.5 shrink-0 text-signal" />
                  <div>
                    <p className="text-[12.5px] text-cream">No block conflicts projected</p>
                    <p className="mt-0.5 text-[11px] text-muted">Headways hold across the next five hours.</p>
                  </div>
                </div>
              )}

              <button
                type="button"
                onClick={() => onNavigate("station")}
                className="group flex w-full items-start gap-3 rounded-xl border border-line bg-black/20 p-3.5 text-left transition-colors hover:border-cream/30"
              >
                <BellRing size={16} className="mt-0.5 shrink-0 text-ice" />
                <span className="min-w-0 flex-1">
                  <span className="block text-[12.5px] text-cream">
                    {pending.length} instruction{pending.length === 1 ? "" : "s"} awaiting acknowledgement
                  </span>
                  <span className="mt-0.5 block text-[11px] text-muted">
                    {pending[0] ? `${pending[0].stationName} · ${pending[0].trainNo}` : "Station consoles are clear"}
                  </span>
                </span>
                <ArrowUpRight size={14} className="arrow-slide mt-1 shrink-0 text-muted" />
              </button>

              <div className="flex items-start gap-3 rounded-xl border border-line bg-black/20 p-3.5">
                <Clock size={16} className="mt-0.5 shrink-0 text-amber" />
                <div>
                  <p className="text-[12.5px] text-cream">
                    {snap.stats.held} train{snap.stats.held === 1 ? "" : "s"} held in section
                  </p>
                  <p className="mt-0.5 text-[11px] text-muted">Release when the block clears to recover path.</p>
                </div>
              </div>
            </div>
          </Card>

          <Card delay={220}>
            <SectionHead label="Cascade model" title="Weighted exposure" />
            <div className="space-y-2.5">
              {["express", "suburban", "passenger", "freight"].map((cls) => {
                const list = snap.trains.filter((t) => t.cls === cls && t.status !== "arrived");
                const delay = list.reduce((a, t) => a + t.delay, 0);
                const max = Math.max(1, snap.stats.weightedDelay || 1);
                const pct = Math.min(100, (delay / max) * 100);
                return (
                  <div key={cls}>
                    <div className="flex items-center justify-between text-[11px]">
                      <span className={cn("text-[11px] tracking-[0.04em]", classColor(cls))}>{cls}</span>
                      <span className="num text-muted">
                        {list.length} trains · {delay} min
                      </span>
                    </div>
                    <div className="mt-1.5 h-[3px] w-full overflow-hidden rounded-full bg-white/5">
                      <div
                        className="h-full rounded-full bg-cream/60 transition-[width] duration-700"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>
      </div>

      <Card delay={260}>
        <SectionHead
          label="Next movements"
          title="Running board"
          right={
            <Button variant="ghost" onClick={() => onNavigate("trains")} icon={<ArrowUpRight size={13} />}>
              All trains
            </Button>
          }
        />
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] border-collapse text-left">
            <thead>
              <tr className="text-[10px] font-medium uppercase tracking-[0.04em] text-muted">
                <th className="pb-3 font-normal">Train</th>
                <th className="pb-3 font-normal">Class</th>
                <th className="pb-3 font-normal">Section</th>
                <th className="pb-3 font-normal">Next</th>
                <th className="pb-3 font-normal">ETA</th>
                <th className="pb-3 font-normal">Delay</th>
                <th className="pb-3 font-normal text-right">Status</th>
              </tr>
            </thead>
            <tbody className="stagger">
              {nextServices.map((train) => (
                <tr
                  key={train.no}
                  onClick={() => onSelectTrain(train.no)}
                  className="rail-row cursor-pointer border-t border-line"
                >
                  <td className="py-3.5">
                    <p className="num text-[12.5px] text-cream">{train.no}</p>
                    <p className="text-[11px] text-muted">{train.name}</p>
                  </td>
                  <td className={cn("text-[11px]", classColor(train.cls))}>
                    {train.cls}
                  </td>
                  <td className="text-[11.5px] text-muted">
                    {train.dir === "UP" ? "UP" : "DOWN"} · {train.inBlock ?? "at platform"}
                  </td>
                  <td className="text-[11.5px] text-cream/80">{train.nextName}</td>
                  <td className="num text-[12.5px] text-cream">{fmtClock(train.eta)}</td>
                  <td className={cn("num text-[12.5px]", train.delay > 5 ? "text-ember" : "text-signal")}>
                    {train.delay > 0 ? `+${train.delay}` : "0"}
                  </td>
                  <td className="py-3.5 text-right">
                    <StatusBadge status={train.status} label={train.statusLabel} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
