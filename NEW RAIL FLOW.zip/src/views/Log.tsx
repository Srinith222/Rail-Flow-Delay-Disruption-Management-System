import { Card, EmptyState, Eyebrow, SectionHead, cn } from "@/components/ui";
import type { Snapshot } from "@/types";

const TONE: Record<string, string> = {
  disruption: "bg-ember",
  hold: "bg-ice",
  plan: "bg-amber",
  ack: "bg-signal",
  system: "bg-muted",
};

export function LogView({ snap }: { snap: Snapshot }) {
  return (
    <div className="grid gap-5 xl:grid-cols-[1fr_320px]">
      <Card>
        <SectionHead label="Corridor record" title="Activity" />
        {snap.log.length === 0 ? (
          <EmptyState title="Nothing recorded yet" body="Controller actions and station acknowledgements appear here." />
        ) : (
          <ol className="relative space-y-0 border-l border-line pl-5">
            {snap.log.map((entry) => (
              <li key={entry.id} className="relative py-3">
                <span
                  className={cn(
                    "absolute -left-[24px] top-[19px] h-[7px] w-[7px] rounded-full",
                    TONE[entry.kind] ?? "bg-muted",
                  )}
                />
                <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                  <span className="num text-[11.5px] text-cream">{entry.at}</span>
                  <span className="text-[10px] text-muted">{entry.actor}</span>
                  <span className="num text-[9px] text-muted/60">{entry.id}</span>
                </div>
                <p className="mt-1 max-w-[70ch] text-[12px] leading-relaxed text-cream/80">{entry.text}</p>
              </li>
            ))}
          </ol>
        )}
      </Card>

      <div className="space-y-4">
        <Card>
          <Eyebrow>Session</Eyebrow>
          <div className="mt-3 space-y-2.5 text-[11.5px]">
            <Row label="Corridor" value={snap.corridor.name} />
            <Row label="Sim clock" value={snap.clock} />
            <Row label="Trains in model" value={String(snap.trains.length)} />
            <Row label="Active orders" value={String(snap.disruptions.length)} />
            <Row label="Instructions" value={String(snap.instructions.length)} />
            <Row label="Clock rate" value={`${snap.speed}× sim seconds`} />
          </div>
        </Card>

        <Card>
          <Eyebrow>Disclosure</Eyebrow>
          <p className="mt-3 text-[11.5px] leading-relaxed text-muted">
            RailFlow is a decision-support simulation on a synthetic SC–WDR corridor model. Infrastructure,
            timetables and delays are assumptions for demonstrating the workflow; nothing here controls trains,
            signals or real staff.
          </p>
        </Card>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3 border-t border-line pt-2.5 first:border-t-0 first:pt-0">
      <span className="text-muted">{label}</span>
      <span className="num text-right text-cream/90">{value}</span>
    </div>
  );
}
