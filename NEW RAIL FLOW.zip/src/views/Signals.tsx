import { Button, Card, Eyebrow, SectionHead, StatusBadge, cn } from "@/components/ui";
import { SignalMap } from "@/components/SignalMap";
import { classColor, fmtClock } from "@/lib/api";
import type { Snapshot } from "@/types";

export function SignalsView({
  snap,
  busy,
  onSelectTrain,
  onReset,
}: {
  snap: Snapshot;
  busy: boolean;
  onSelectTrain: (trainNo: string) => void;
  onReset: () => void;
}) {
  const stations = snap.corridor.stations;
  const active = snap.trains
    .filter((train) => train.status !== "arrived" && train.status !== "cancelled")
    .sort((a, b) => a.eta - b.eta);

  const blockedBlocks = new Set(snap.disruptions.filter((item) => item.blockId).map((item) => item.blockId as string));
  const held = active.filter((train) => train.status === "held").length;

  const occupancy = snap.corridor.blocks.map((block) => {
    const trains = active.filter((train) => {
      const normalised = train.inBlock?.replace("–", "-");
      return normalised === block.id || train.inBlock === block.id;
    });
    return { block, trains, blocked: blockedBlocks.has(block.id) };
  });

  return (
    <div className="space-y-4">
      <Card className="overflow-hidden p-0">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line px-5 py-3.5">
          <div>
            <Eyebrow>Section diagram · absolute block</Eyebrow>
            <h2 className="mt-1 text-[17px] font-semibold tracking-[-0.01em] text-cream">
              Secunderabad — Wadiaram
            </h2>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-[10px] text-muted">Simulated clock</p>
              <p className="num text-[20px] leading-tight text-cream">{snap.clock}</p>
            </div>
            <Button variant="ghost" onClick={onReset} disabled={busy}>
              Reset
            </Button>
          </div>
        </div>

        <div className="map-grid">
          <SignalMap snap={snap} onSelectTrain={onSelectTrain} />
        </div>

        <div className="flex flex-wrap items-center gap-x-6 gap-y-2 border-t border-line px-5 py-3 text-[11px] text-muted">
          <span className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-[#4ade80]" /> signal clear
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-[#fbbf24]" /> caution
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-[#f87171]" /> signal at danger
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-px w-5 bg-[#b9c4d1]" /> double line
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-px w-5 border-t border-dashed border-[#f87171]" /> blocked section
          </span>
          <span className="ml-auto">Click a train tag to open its working</span>
        </div>
      </Card>

      <div className="grid gap-4 xl:grid-cols-[1.65fr_1fr]">
        <Card>
          <SectionHead label={`${active.length} in section`} title="Overview" />
          <div className="overflow-x-auto">
            <table className="w-full min-w-[620px] border-collapse text-left">
              <thead>
                <tr className="text-[10px] font-medium uppercase tracking-[0.04em] text-muted">
                  <th className="pb-2.5 font-medium">Train</th>
                  <th className="pb-2.5 font-medium">Class</th>
                  <th className="pb-2.5 font-medium">Direction</th>
                  <th className="pb-2.5 font-medium">Destination</th>
                  <th className="pb-2.5 font-medium">Next</th>
                  <th className="pb-2.5 font-medium">Status</th>
                  <th className="pb-2.5 text-right font-medium">Delay</th>
                </tr>
              </thead>
              <tbody className="stagger">
                {active.slice(0, 10).map((train) => (
                  <tr
                    key={train.no}
                    onClick={() => onSelectTrain(train.no)}
                    className="rail-row cursor-pointer border-t border-line"
                  >
                    <td className="num py-2.5 text-[12px] text-cream">{train.no}</td>
                    <td className={cn("text-[11px]", classColor(train.cls))}>{train.cls}</td>
                    <td className="text-[11px] text-muted">{train.dir}</td>
                    <td className="text-[11px] text-cream/80">{train.destinationName}</td>
                    <td className="text-[11px] text-muted">
                      {train.nextName} · {fmtClock(train.eta)}
                    </td>
                    <td className="py-2.5">
                      <StatusBadge status={train.status} label={train.statusLabel} />
                    </td>
                    <td className={cn("num text-right text-[11.5px]", train.delay > 5 ? "text-ember" : "text-signal")}>
                      {train.delay > 0 ? `+${train.delay}` : "0"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <div className="space-y-4">
          <Card>
            <Eyebrow>Corridor</Eyebrow>
            <p className="num mt-1 text-[30px] leading-none text-cream">{snap.clock}</p>
            <p className="mt-1 text-[11px] text-muted">
              Simulated clock · {snap.speed}× · {stations.length} stations · 63.5 km
            </p>
            <dl className="mt-4 space-y-2 border-t border-line pt-3 text-[11.5px]">
              <Row label="In section" value={`${active.length}`} />
              <Row label="Held" value={`${held}`} />
              <Row label="Blocked sections" value={`${blockedBlocks.size}`} />
              <Row label="Delayed over 6 min" value={`${snap.stats.delayed}`} />
              <Row label="Weighted delay" value={`${snap.stats.weightedDelay} min`} />
            </dl>
          </Card>

          <Card>
            <SectionHead label="Occupancy" title="Block sections" />
            <ul className="divide-y divide-line">
              {occupancy.map(({ block, trains, blocked }) => (
                <li key={block.id} className="flex items-center justify-between gap-3 py-2">
                  <div className="min-w-0">
                    <p className="num text-[11.5px] text-cream">{block.id}</p>
                    <p className="text-[10px] text-muted">
                      {block.track} · {block.km} km
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    {trains.length ? (
                      <span className="num text-[10.5px] text-cream/80">{trains.map((train) => train.no).join(" ")}</span>
                    ) : (
                      <span className="text-[10.5px] text-muted">clear</span>
                    )}
                    <span
                      className={cn(
                        "h-1.5 w-1.5 rounded-full",
                        blocked ? "bg-[#f87171]" : trains.length ? "bg-amber" : "bg-[#4ade80]",
                      )}
                    />
                  </div>
                </li>
              ))}
            </ul>
            <p className="mt-3 text-[10px] leading-relaxed text-muted">
              Occupancy is inferred from the model timetable, not track circuits. Station codes:{" "}
              {stations.map((station) => station.code).join(" · ")}
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <dt className="text-muted">{label}</dt>
      <dd className="num text-cream/90">{value}</dd>
    </div>
  );
}
