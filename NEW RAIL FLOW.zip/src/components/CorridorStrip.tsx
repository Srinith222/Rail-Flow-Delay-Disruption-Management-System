import type { Snapshot, Station, Train } from "@/types";

const DOT_COLOR: Record<string, string> = {
  running: "#7fe3b4",
  delayed: "#ff9a83",
  held: "#9dc0ff",
  upcoming: "#f4ede2",
  arrived: "#6c6f74",
  cancelled: "#6c6f74",
};

export function CorridorStrip({ snap }: { snap: Snapshot }) {
  const stations = snap.corridor.stations;
  const blocks = snap.corridor.blocks;
  const count = stations.length;
  const closed = new Set(snap.disruptions.filter((item) => item.blockId).map((item) => item.blockId as string));
  const live = snap.trains.filter((train) => train.status !== "arrived" && train.status !== "cancelled");

  const blockIndexForKm = (km: number) => {
    for (let index = 0; index < count - 1; index += 1) {
      if (km >= stations[index].km && km < stations[index + 1].km) return index;
    }
    return count - 2;
  };

  const betweenStations = (blockIndex: number): Train[] =>
    live.filter(
      (train) =>
        blockIndexForKm(train.km) === blockIndex &&
        Math.abs(train.km - stations[blockIndex].km) > 0.8 &&
        Math.abs(train.km - stations[blockIndex + 1].km) > 0.8,
    );

  const atStation = (station: Station) => live.filter((train) => Math.abs(train.km - station.km) < 0.8);

  /** Percent across the equal-width station columns, interpolated by distance run. */
  const positionPct = (km: number) => {
    for (let index = 0; index < count - 1; index += 1) {
      const from = stations[index].km;
      const to = stations[index + 1].km;
      if (km <= to || index === count - 2) {
        const progress = Math.min(1, Math.max(0, (km - from) / (to - from)));
        return ((index + 0.5 + progress) / count) * 100;
      }
    }
    return (0.5 / count) * 100;
  };

  return (
    <div className="w-full">
      {/* wide screens: the corridor as one horizontal line */}
      <div className="relative hidden md:block" style={{ height: 88 }}>
        {blocks.map((block, index) => {
          const left = ((index + 0.5) / count) * 100;
          const width = (1 / count) * 100;
          const blocked = closed.has(block.id);
          const lineClass = blocked ? "bg-ember/80" : "bg-cream/30";
          return (
            <div key={block.id} className="absolute" style={{ left: `${left}%`, width: `${width}%`, top: 0, height: 88 }}>
              {block.track === "double" ? (
                <>
                  <span className={`absolute left-2 right-2 top-[26px] h-[4px] rounded-full ${lineClass}`} />
                  <span className={`absolute left-2 right-2 top-[36px] h-[4px] rounded-full ${lineClass}`} />
                </>
              ) : (
                <span className={`absolute left-2 right-2 top-[31px] h-[5px] rounded-full ${lineClass}`} />
              )}
              <span
                className={`absolute inset-x-0 top-[58px] truncate px-1 text-center text-[9.5px] ${
                  blocked ? "text-ember" : "text-muted"
                }`}
              >
                {blocked ? "blocked" : block.track} · {block.km} km
              </span>
            </div>
          );
        })}

        {/* live train markers, positioned by distance run */}
        {live.map((train) => {
          const left = positionPct(train.km);
          const up = train.dir === "UP";
          const tone = DOT_COLOR[train.status] ?? "#f4ede2";
          const flagged = train.delay >= 6 || train.status === "held";
          return (
            <span
              key={train.no}
              title={`${train.no} ${train.name} · ${train.statusLabel}${train.delay ? ` +${train.delay} min` : ""}`}
              className="absolute z-10 flex -translate-x-1/2 items-center justify-center transition-[left] duration-[1400ms] ease-linear"
              style={{ left: `${left}%`, top: up ? 10 : 46 }}
            >
              {flagged ? (
                <span
                  className="flex h-[15px] items-center rounded-[3px] px-1.5 text-[9px] font-semibold text-[#08110c]"
                  style={{ background: tone }}
                >
                  {train.no}
                </span>
              ) : (
                <span
                  className="h-[7px] w-[7px] rounded-full ring-2 ring-canvas"
                  style={{ background: tone }}
                />
              )}
            </span>
          );
        })}

        <div className="relative flex">
          {stations.map((station) => {
            const here = atStation(station);
            const tone = here.some((train) => train.delay >= 6) ? "#ff9a83" : here.length ? "#7fe3b4" : null;
            return (
              <div key={station.code} className="flex min-w-0 flex-1 flex-col items-center">
                <div
                  className="relative z-10 flex h-16 w-16 items-center justify-center rounded-full border-2 border-cream/75 bg-canvas"
                  title={`${station.name} · ${station.km} km · ${station.platforms} platforms`}
                >
                  <span className="num text-[14px] font-semibold tracking-[-0.02em] text-cream">{station.code}</span>
                  {tone ? (
                    <span
                      className="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full border-2 border-canvas"
                      style={{ background: tone }}
                    />
                  ) : null}
                </div>
                <span className="mt-2.5 w-full truncate px-1 text-center font-display text-[13px] font-medium text-cream">
                  {station.name.replace(" Jn", "")}
                </span>
                <span className="mt-0.5 truncate text-[10px] text-muted">
                  {station.km} km · {station.platforms} PF
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* narrow screens: the same corridor as a vertical station line */}
      <div className="relative md:hidden">
        <span aria-hidden className="absolute bottom-8 left-[22px] top-8 w-px bg-line" />
        <ul className="space-y-4">
          {stations.map((station, index) => {
            const here = atStation(station);
            const block = blocks[index];
            const blocked = block ? closed.has(block.id) : false;
            const running = block ? betweenStations(index) : [];
            return (
              <li key={station.code} className="relative flex items-start gap-3">
                <span className="relative z-10 flex h-11 w-11 shrink-0 items-center justify-center rounded-full border-2 border-cream/70 bg-canvas num text-[11px] font-semibold text-cream">
                  {station.code}
                </span>
                <div className="min-w-0 flex-1 pt-0.5">
                  <p className="font-display text-[14px] font-medium leading-tight text-cream">
                    {station.name.replace(" Jn", "")}
                  </p>
                  <p className="mt-0.5 text-[10.5px] text-muted">
                    {station.km} km · {station.platforms} platforms
                    {here.length > 0 ? ` · ${here.length} here` : ""}
                  </p>
                  {block ? (
                    <p className={`mt-0.5 text-[10.5px] ${blocked ? "text-ember" : "text-muted/80"}`}>
                      to {stations[index + 1].code} · {blocked ? "blocked" : block.track} · {block.km} km
                    </p>
                  ) : null}
                  {running.length > 0 ? (
                    <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                      {running.map((train) => (
                        <span
                          key={train.no}
                          className="flex items-center gap-1 rounded-[3px] border border-line px-1.5 py-0.5 text-[9.5px] text-cream/85"
                          title={`${train.name} · ${train.statusLabel}`}
                        >
                          <span
                            className="h-1.5 w-1.5 rounded-full"
                            style={{ background: DOT_COLOR[train.status] ?? "#f4ede2" }}
                          />
                          {train.no}
                        </span>
                      ))}
                    </div>
                  ) : null}
                </div>
              </li>
            );
          })}
        </ul>
      </div>

      <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-2 border-t border-line pt-3 text-[10.5px] text-muted">
        <span className="flex items-center gap-1.5">
          <span className="h-[4px] w-6 rounded-full bg-cream/30" /> single line
        </span>
        <span className="flex items-center gap-1.5">
          <span className="flex flex-col gap-[3px]">
            <span className="h-[3px] w-6 rounded-full bg-cream/30" />
            <span className="h-[3px] w-6 rounded-full bg-cream/30" />
          </span>
          double line
        </span>
        <span className="flex items-center gap-1.5">
          <span className="h-[4px] w-6 rounded-full bg-ember/80" /> blocked
        </span>
        <span className="flex items-center gap-1.5">
          <span className="h-[7px] w-[7px] rounded-full bg-[#7fe3b4]" /> running train
        </span>
        <span className="num ml-auto">{live.length} in section</span>
      </div>
    </div>
  );
}
