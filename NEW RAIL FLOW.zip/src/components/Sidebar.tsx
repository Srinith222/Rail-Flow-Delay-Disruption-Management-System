import {
  ArrowUpRight,
  ChevronLeft,
  Gauge,
  House,
  Network,
  Radar,
  Radio,
  ScrollText,
  TrainFront,
  TriangleAlert,
  Waypoints,
  Building2,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { cn } from "@/components/ui";
import type { Role, Snapshot, ViewId } from "@/types";

interface NavItem {
  id: ViewId;
  label: string;
  caption: string;
  icon: LucideIcon;
  roles: Role[];
}

const NAV: NavItem[] = [
  { id: "home", label: "Home", caption: "Welcome screen", icon: House, roles: ["controller", "master"] },
  { id: "overview", label: "Control", caption: "Section overview", icon: Gauge, roles: ["controller", "master"] },
  { id: "signals", label: "Signals", caption: "Zone diagram", icon: Network, roles: ["controller", "master"] },
  { id: "trains", label: "Trains", caption: "Live running board", icon: TrainFront, roles: ["controller", "master"] },
  { id: "disruptions", label: "Disruptions", caption: "Report & recover", icon: TriangleAlert, roles: ["controller"] },
  { id: "regulator", label: "Regulator", caption: "Time–distance chart", icon: Waypoints, roles: ["controller"] },
  { id: "station", label: "Station", caption: "Master console", icon: Building2, roles: ["controller", "master"] },
  { id: "live", label: "Live data", caption: "RailRadar feed", icon: Radar, roles: ["controller", "master"] },
  { id: "log", label: "Log", caption: "Corridor record", icon: ScrollText, roles: ["controller", "master"] },
];

export function Sidebar({
  view,
  role,
  collapsed,
  snap,
  onNavigate,
  onToggle,
  onLock,
}: {
  view: ViewId;
  role: Role;
  collapsed: boolean;
  snap: Snapshot;
  onNavigate: (view: ViewId) => void;
  onToggle: () => void;
  onLock: () => void;
}) {
  const items = NAV.filter((item) => item.roles.includes(role));
  const activeIndex = items.findIndex((item) => item.id === view);
  const pending = snap.instructions.filter((i) => i.status === "PENDING").length;

  return (
    <aside
      className={cn(
        "sticky top-0 z-30 flex h-screen shrink-0 flex-col border-r border-line bg-[#0a0b0e]/90 backdrop-blur-xl transition-[width] duration-[520ms] ease-[cubic-bezier(0.22,1,0.36,1)]",
        collapsed ? "w-[84px]" : "w-[84px] lg:w-[268px]",
      )}
    >
      <div className="flex items-center gap-3 px-4 pb-5 pt-6">
        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded border border-cream/25 text-cream">
          <svg width="15" height="15" viewBox="0 0 16 16" aria-hidden>
            <path d="M3.5 2v12M12.5 2v12M3.5 6h9M3.5 10h9" stroke="currentColor" strokeWidth="1.2" fill="none" />
          </svg>
        </div>
        <div className={cn("min-w-0 overflow-hidden transition-all duration-300", collapsed && "lg:w-0 lg:opacity-0")}>
          <p className="hidden whitespace-nowrap text-[14px] font-semibold tracking-[-0.01em] text-cream lg:block">
            RailFlow
          </p>
          <p className="hidden whitespace-nowrap text-[10px] text-muted lg:block">Section control</p>
        </div>
      </div>

      <nav className="relative flex-1 px-3" aria-label="Main">
        <span
          aria-hidden
          className="nav-indicator pointer-events-none absolute left-3 right-3 top-0 rounded border border-cream/12 bg-cream/[0.06]"
          style={{
            height: 52,
            transform: `translateY(${activeIndex * 56}px)`,
            opacity: activeIndex < 0 ? 0 : 1,
          }}
        />
        <ul className="relative space-y-1">
          {items.map((item) => {
            const Icon = item.icon;
            const active = item.id === view;
            return (
              <li key={item.id}>
                <button
                  type="button"
                  onClick={() => (item.id === "home" ? onLock() : onNavigate(item.id))}
                  aria-current={active ? "page" : undefined}
                  className={cn(
                    "group flex h-[52px] w-full items-center gap-3 rounded px-3 text-left transition-colors duration-200",
                    active ? "text-cream" : "text-muted hover:text-cream",
                  )}
                >
                  <Icon
                    size={17}
                    strokeWidth={active ? 1.6 : 1.4}
                    className={cn(
                      "shrink-0 transition-transform duration-500 group-hover:scale-110",
                      active && "text-cream",
                    )}
                  />
                  <span
                    className={cn(
                      "hidden min-w-0 flex-1 overflow-hidden transition-all duration-500 lg:block",
                      collapsed && "lg:w-0 lg:opacity-0",
                    )}
                  >
                    <span className="block whitespace-nowrap text-[13px] font-medium">{item.label}</span>
                    <span className="block whitespace-nowrap text-[10px] text-muted">
                      {item.id === "disruptions" && snap.stats.activeDisruptions > 0
                        ? `${snap.stats.activeDisruptions} active`
                        : item.id === "station" && pending > 0
                          ? `${pending} to acknowledge`
                          : item.caption}
                    </span>
                  </span>
                  <ArrowUpRight
                    size={13}
                    className={cn(
                      "arrow-slide hidden shrink-0 opacity-0 transition-opacity duration-300 lg:block",
                      active ? "opacity-60" : "group-hover:opacity-50",
                    )}
                  />
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="px-4 pb-5">
        <div className="mb-3 hidden rounded border border-line px-3 py-2.5 lg:block">
          <div className="flex items-center gap-2">
            <span className="live-dot h-1.5 w-1.5 rounded-full bg-signal" />
            <span className="text-[10px] text-muted">Simulation live</span>
          </div>
          <p className="num mt-1 text-[17px] text-cream">{snap.clock}</p>
          <p className="text-[10px] text-muted">SC–WDR · {snap.stats.active} active</p>
        </div>
        <div className="flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={onToggle}
            aria-label="Toggle navigation width"
            className="hidden rounded border border-line p-2 text-muted transition-colors hover:border-cream/40 hover:text-cream lg:block"
          >
            <ChevronLeft size={14} className={cn("transition-transform duration-500", collapsed && "rotate-180")} />
          </button>
          <span className="hidden items-center gap-1.5 text-[10px] text-muted/70 lg:flex">
            <Radio size={11} /> v1.0
          </span>
        </div>
      </div>
    </aside>
  );
}
