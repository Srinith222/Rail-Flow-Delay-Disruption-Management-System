import { clsx, type ClassValue } from "clsx";
import { X } from "lucide-react";
import { useEffect, useRef, useState, type ButtonHTMLAttributes, type ReactNode } from "react";
import { twMerge } from "tailwind-merge";
import { statusTone } from "@/lib/api";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function Eyebrow({ children, className }: { children: ReactNode; className?: string }) {
  return <p className={cn("eyebrow", className)}>{children}</p>;
}

export function Card({
  children,
  className,
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  return (
    <section
      className={cn("card rise p-6", className)}
      style={{ animationDelay: `${delay}ms` }}
    >
      {children}
    </section>
  );
}

export function SectionHead({
  label,
  title,
  right,
}: {
  label: string;
  title?: string;
  right?: ReactNode;
}) {
  return (
    <div className="mb-5 flex items-start justify-between gap-4">
      <div>
        <Eyebrow>{label}</Eyebrow>
        {title ? (
          <h2 className="mt-1.5 font-display text-[16px] font-semibold leading-tight tracking-[-0.02em] text-cream">
            {title}
          </h2>
        ) : null}
      </div>
      {right}
    </div>
  );
}

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "wine" | "cream" | "ghost" | "plain";
  icon?: ReactNode;
}

export function Button({ variant = "wine", icon, className, children, ...rest }: ButtonProps) {
  const styles = {
    wine: "btn-wine",
    cream: "btn-cream",
    ghost: "btn-ghost",
    plain: "btn text-muted hover:text-cream",
  }[variant];
  return (
    <button type="button" className={cn("group", styles, className)} {...rest}>
      {icon ? <span className="arrow-slide">{icon}</span> : null}
      <span>{children}</span>
    </button>
  );
}

export function StatusBadge({ status, label }: { status: string; label?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-[3px] border px-2 py-0.5 text-[10px] font-medium",
        statusTone(status),
      )}
    >
      <span className="h-1 w-1 rounded-full bg-current" />
      {label ?? status}
    </span>
  );
}

export interface SegmentedOption<T extends string> {
  id: T;
  label: string;
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  className,
  size = "md",
}: {
  options: SegmentedOption<T>[];
  value: T;
  onChange: (value: T) => void;
  className?: string;
  size?: "sm" | "md";
}) {
  const index = Math.max(0, options.findIndex((o) => o.id === value));
  return (
    <div
      className={cn(
        "relative flex rounded border border-line bg-black/30 p-[3px]",
        size === "sm" ? "text-[10px]" : "text-[11px]",
        className,
      )}
      role="tablist"
      aria-label="View selector"
    >
      <span
        aria-hidden
        className="pointer-events-none absolute inset-y-[3px] left-[3px] rounded bg-cream transition-transform duration-[380ms] ease-[cubic-bezier(0.22,1,0.36,1)]"
        style={{
          width: `calc((100% - 6px) / ${options.length})`,
          transform: `translateX(${index * 100}%)`,
        }}
      />
      {options.map((option) => (
        <button
          key={option.id}
          role="tab"
          aria-selected={option.id === value}
          type="button"
          onClick={() => onChange(option.id)}
          className={cn(
            "relative z-10 whitespace-nowrap rounded px-3 py-1.5 font-medium transition-colors duration-200",
            option.id === value ? "text-[#141517]" : "text-muted hover:text-cream",
          )}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}

function useCountUp(target: number, duration = 900) {
  const [display, setDisplay] = useState(target);
  const fromRef = useRef(target);

  useEffect(() => {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced) {
      fromRef.current = target;
      setDisplay(target);
      return;
    }
    const from = fromRef.current;
    if (from === target) return;
    let frame = 0;
    const started = performance.now();
    const step = (now: number) => {
      const progress = Math.min(1, (now - started) / duration);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplay(Math.round(from + (target - from) * eased));
      if (progress < 1) frame = requestAnimationFrame(step);
      else fromRef.current = target;
    };
    frame = requestAnimationFrame(step);
    return () => cancelAnimationFrame(frame);
  }, [target, duration]);

  return display;
}

export function Stat({
  label,
  value,
  suffix,
  hint,
  tone = "cream",
  delay = 0,
}: {
  label: string;
  value: string | number;
  suffix?: string;
  hint?: string;
  tone?: "cream" | "signal" | "ember" | "ice" | "amber";
  delay?: number;
}) {
  const toneClass = {
    cream: "text-cream",
    signal: "text-signal",
    ember: "text-ember",
    ice: "text-ice",
    amber: "text-amber",
  }[tone];
  const numeric = typeof value === "number" ? value : 0;
  const counted = useCountUp(numeric);
  return (
    <div className="card rise px-5 py-5" style={{ animationDelay: `${delay}ms` }}>
      <Eyebrow>{label}</Eyebrow>
      <div className="mt-3 flex items-baseline gap-1.5">
        <span className={cn("num text-[30px] font-normal leading-none tracking-tight", toneClass)}>
          {typeof value === "number" ? counted : value}
        </span>
        {suffix ? <span className="text-[11px] text-muted">{suffix}</span> : null}
      </div>
      {hint ? <p className="mt-2 text-[11px] leading-relaxed text-muted">{hint}</p> : null}
    </div>
  );
}

export function EmptyState({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-xl border border-dashed border-line px-5 py-8 text-center">
      <p className="text-sm text-cream/80">{title}</p>
      <p className="mt-1 text-[12px] text-muted">{body}</p>
    </div>
  );
}

export function Drawer({
  open,
  onClose,
  title,
  eyebrow,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  eyebrow: string;
  children: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end" role="dialog" aria-modal="true" aria-label={title}>
      <button
        aria-label="Close panel"
        onClick={onClose}
        className="absolute inset-0 bg-black/60 backdrop-blur-[2px]"
      />
      <div className="slide-in-right relative z-10 flex h-full w-full max-w-[480px] flex-col border-l border-line bg-[#0c0e12]">
        <header className="flex items-start justify-between gap-4 border-b border-line px-6 py-5">
          <div>
            <Eyebrow>{eyebrow}</Eyebrow>
            <h2 className="mt-1.5 font-display text-[18px] font-semibold leading-tight tracking-[-0.02em] text-cream">
              {title}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded border border-line p-2 text-muted transition-colors hover:border-cream/40 hover:text-cream"
          >
            <X size={15} />
          </button>
        </header>
        <div className="flex-1 overflow-y-auto px-6 py-5">{children}</div>
      </div>
    </div>
  );
}
