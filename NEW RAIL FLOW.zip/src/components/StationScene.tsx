import { useEffect, useRef } from "react";
import * as THREE from "three";

/** One pass: run in → halt at the platform → pull out. */
const CYCLE = 15000;
const HALT_AT = 4200;
const DWELL_END = 6400;
const GONE_AT = 9800;
const START_Z = -210;
const HALT_Z = -8;

const easeOutCubic = (value: number) => 1 - Math.pow(1 - value, 2.2);
const easeInCubic = (value: number) => Math.pow(value, 2);

function trainZ(t: number) {
  if (t < HALT_AT) return START_Z + (HALT_Z - START_Z) * easeOutCubic(t / HALT_AT);
  if (t < DWELL_END) return HALT_Z;
  if (t < GONE_AT) return HALT_Z + (START_Z - HALT_Z) * easeInCubic((t - DWELL_END) / (GONE_AT - DWELL_END));
  return START_Z;
}

function plateTexture(text: string, width = 512, height = 128, font = "bold 74px sans-serif") {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (ctx) {
    ctx.fillStyle = "#d8d2c4";
    ctx.fillRect(0, 0, width, height);
    ctx.fillStyle = "#16181c";
    ctx.font = font;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(text, width / 2, height / 2);
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

/** A WAP-7 style electric locomotive, detailed enough to read at speed. */
function buildLocomotive() {
  const group = new THREE.Group();
  const wheels: THREE.Mesh[] = [];

  const shellMaterial = new THREE.MeshStandardMaterial({ color: 0xdcd6c8, roughness: 0.46, metalness: 0.22 });
  const red = new THREE.MeshStandardMaterial({ color: 0x9c3323, roughness: 0.52, metalness: 0.12 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x191b1f, roughness: 0.72, metalness: 0.3 });
  const metal = new THREE.MeshStandardMaterial({ color: 0x6f7276, roughness: 0.42, metalness: 0.75 });
  const glass = new THREE.MeshStandardMaterial({ color: 0x0f141b, roughness: 0.16, metalness: 0.65 });
  const lamp = new THREE.MeshStandardMaterial({ color: 0xfff4da, emissive: 0xfff1cf, emissiveIntensity: 6 });
  const tail = new THREE.MeshStandardMaterial({ color: 0x5a1010, emissive: 0xff3b30, emissiveIntensity: 2.6 });

  const profile = new THREE.Shape();
  profile.moveTo(-9.6, 0.9);
  profile.lineTo(9.0, 0.9);
  profile.lineTo(9.0, 3.05);
  profile.lineTo(8.05, 4.14);
  profile.lineTo(-9.6, 4.14);
  profile.lineTo(-9.6, 0.9);

  const shell = new THREE.ExtrudeGeometry(profile, {
    depth: 3,
    bevelEnabled: true,
    bevelThickness: 0.07,
    bevelSize: 0.07,
    bevelSegments: 2,
    curveSegments: 1,
  });
  shell.translate(0, 0, -1.5);
  shell.rotateY(-Math.PI / 2);
  shell.computeVertexNormals();
  group.add(new THREE.Mesh(shell, shellMaterial));

  // cab glass, framed
  const frame = new THREE.Mesh(new THREE.BoxGeometry(2.66, 1.06, 0.06), dark);
  frame.position.set(0, 3.6, 8.56);
  frame.rotation.x = -0.86;
  group.add(frame);
  const screen = new THREE.Mesh(new THREE.BoxGeometry(2.42, 0.86, 0.08), glass);
  screen.position.set(0, 3.61, 8.62);
  screen.rotation.x = -0.86;
  group.add(screen);

  // wipers
  for (const x of [-0.8, 0.6]) {
    const wiper = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.6, 0.03), dark);
    wiper.position.set(x, 3.42, 8.75);
    wiper.rotation.x = -0.86;
    wiper.rotation.z = 0.4;
    group.add(wiper);
  }

  // nose banding, grille and lamps
  const noseBand = new THREE.Mesh(new THREE.BoxGeometry(2.96, 0.56, 0.08), red);
  noseBand.position.set(0, 2.62, 9.02);
  group.add(noseBand);
  const noseStripe = new THREE.Mesh(new THREE.BoxGeometry(2.96, 0.1, 0.08), shellMaterial);
  noseStripe.position.set(0, 2.44, 9.03);
  group.add(noseStripe);
  const grille = new THREE.Mesh(new THREE.BoxGeometry(2.5, 1.05, 0.07), dark);
  grille.position.set(0, 1.85, 9.02);
  group.add(grille);

  // running number plate
  const numberPlate = new THREE.Mesh(
    new THREE.PlaneGeometry(1.15, 0.29),
    new THREE.MeshBasicMaterial({ map: plateTexture("30272"), toneMapped: false }),
  );
  numberPlate.position.set(0, 3.13, 9.06);
  group.add(numberPlate);

  for (const x of [-0.98, 0.98]) {
    const housing = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 0.12, 16), dark);
    housing.rotation.x = Math.PI / 2;
    housing.position.set(x, 2.02, 9.05);
    group.add(housing);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.18, 14, 14), lamp);
    head.position.set(x, 2.02, 9.11);
    group.add(head);
  }
  for (const x of [-1.34, 1.34]) {
    const marker = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 10), tail);
    marker.position.set(x, 2.95, 9.03);
    group.add(marker);
  }

  // side banding, louvres, cab window and handrails
  for (const side of [-1.51, 1.51]) {
    const band = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.46, 18.2), red);
    band.position.set(side, 2.3, -0.2);
    group.add(band);

    const sideGlass = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.8, 1.55), glass);
    sideGlass.position.set(side, 3.35, 6.6);
    group.add(sideGlass);

    const doorLine = new THREE.Mesh(new THREE.BoxGeometry(0.04, 2.6, 0.05), dark);
    doorLine.position.set(side, 2.4, 5.2);
    group.add(doorLine);

    for (let index = 0; index < 7; index += 1) {
      const louvre = new THREE.Mesh(new THREE.BoxGeometry(0.05, 1.1, 0.09), dark);
      louvre.position.set(side, 2.55, 2.6 - index * 0.62);
      group.add(louvre);
    }

    for (const z of [8.55, 7.6]) {
      const railPost = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 2.6, 6), metal);
      railPost.position.set(side - Math.sign(side) * 0.12, 2.5, z);
      group.add(railPost);
    }
  }

  // roof equipment
  const roof = new THREE.Mesh(new THREE.BoxGeometry(2.62, 0.16, 17.4), dark);
  roof.position.set(0, 4.22, -0.3);
  group.add(roof);
  for (let index = 0; index < 3; index += 1) {
    const insulator = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.14, 0.34, 8), metal);
    insulator.position.set(0, 4.45, 2.2 - index * 2.4);
    group.add(insulator);
  }

  // pantograph
  const base = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.08, 1.1), dark);
  base.position.set(0, 4.33, -2.6);
  group.add(base);
  for (const angle of [0.62, -0.62]) {
    const arm = new THREE.Mesh(new THREE.BoxGeometry(0.07, 1.5, 0.07), dark);
    arm.position.set(0, 5.05, -2.6 + Math.sin(angle) * 0.3);
    arm.rotation.x = angle;
    group.add(arm);
  }
  const bar = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.06, 0.1), dark);
  bar.position.set(0, 5.72, -2.6);
  group.add(bar);

  // bogies, wheels, underframe
  const wheelGeometry = new THREE.CylinderGeometry(0.56, 0.56, 0.5, 18);
  wheelGeometry.rotateZ(Math.PI / 2);
  const wheelMaterial = new THREE.MeshStandardMaterial({ color: 0x2a2b2e, roughness: 0.55, metalness: 0.7 });
  for (const bogieZ of [6.1, -6.1]) {
    const bogie = new THREE.Mesh(new THREE.BoxGeometry(2.5, 0.6, 3.7), dark);
    bogie.position.set(0, 0.8, bogieZ);
    group.add(bogie);
    const spring = new THREE.Mesh(new THREE.BoxGeometry(2.7, 0.18, 3.2), metal);
    spring.position.set(0, 1.12, bogieZ);
    group.add(spring);
    for (const wheelZ of [-1.2, 1.2]) {
      for (const x of [-1.16, 1.16]) {
        const wheel = new THREE.Mesh(wheelGeometry, wheelMaterial);
        wheel.position.set(x, 0.56, bogieZ + wheelZ);
        group.add(wheel);
        wheels.push(wheel);
      }
    }
  }
  const tank = new THREE.Mesh(new THREE.BoxGeometry(2.3, 0.7, 4.4), dark);
  tank.position.set(0, 0.72, 0);
  group.add(tank);

  const beam = new THREE.Mesh(new THREE.BoxGeometry(3.06, 0.32, 0.4), dark);
  beam.position.set(0, 0.86, 9.15);
  group.add(beam);
  for (const x of [-1.06, 1.06]) {
    const buffer = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.3, 14), dark);
    buffer.rotation.x = Math.PI / 2;
    buffer.position.set(x, 1.02, 9.12);
    group.add(buffer);
  }

  group.userData.wheels = wheels;
  return group;
}

function buildCoach(z: number) {
  const group = new THREE.Group();
  const body = new THREE.Mesh(
    new THREE.BoxGeometry(3, 2.6, 17),
    new THREE.MeshStandardMaterial({ color: 0x2b3546, roughness: 0.55, metalness: 0.25 }),
  );
  body.position.y = 2.2;
  group.add(body);

  const strip = new THREE.Mesh(
    new THREE.BoxGeometry(3.02, 0.16, 17),
    new THREE.MeshStandardMaterial({ color: 0xc2432c, roughness: 0.6 }),
  );
  strip.position.y = 1.1;
  group.add(strip);

  const roof = new THREE.Mesh(
    new THREE.BoxGeometry(2.7, 0.22, 16.6),
    new THREE.MeshStandardMaterial({ color: 0x14181f, roughness: 0.8 }),
  );
  roof.position.y = 3.6;
  group.add(roof);

  const glass = new THREE.MeshStandardMaterial({
    color: 0x1b222c,
    emissive: 0xffcf8a,
    emissiveIntensity: 1.1,
    roughness: 0.2,
  });
  for (const side of [-1.51, 1.51]) {
    for (let index = 0; index < 7; index += 1) {
      const pane = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.62, 1.35), glass);
      pane.position.set(side, 2.55, -6.4 + index * 2.15);
      group.add(pane);
    }
  }

  const dark = new THREE.MeshStandardMaterial({ color: 0x1b1d21, roughness: 0.8, metalness: 0.3 });
  for (const bogieZ of [5.4, -5.4]) {
    const bogie = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.5, 2.9), dark);
    bogie.position.set(0, 0.72, bogieZ);
    group.add(bogie);
  }

  group.position.z = z;
  return group;
}

export function StationScene() {
  const hostRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    const hostElement: HTMLDivElement = host;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
    } catch {
      return; // no WebGL — the painted backdrop stays visible on its own
    }

    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    renderer.setClearAlpha(0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.32;
    renderer.domElement.style.width = "100%";
    renderer.domElement.style.height = "100%";
    renderer.domElement.style.display = "block";
    host.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0xbc8a63, 80, 340);

    const camera = new THREE.PerspectiveCamera(46, 1, 0.1, 900);
    camera.position.set(2.2, 3.2, 20);
    camera.lookAt(0.4, 2.6, -30);

    scene.add(new THREE.AmbientLight(0xffdcc0, 1.35));
    scene.add(new THREE.HemisphereLight(0xffd7b0, 0x241a1c, 0.8));
    const sun = new THREE.DirectionalLight(0xffc79a, 3.1);
    sun.position.set(-30, 22, 30);
    scene.add(sun);
    const rim = new THREE.DirectionalLight(0x9fb4d8, 0.75);
    rim.position.set(26, 10, 28);
    scene.add(rim);

    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(700, 760),
      new THREE.MeshStandardMaterial({ color: 0x3a2b29, roughness: 1 }),
    );
    ground.rotation.x = -Math.PI / 2;
    ground.position.set(0, 0, -210);
    scene.add(ground);

    const ballastMaterial = new THREE.MeshStandardMaterial({ color: 0x5a4744, roughness: 1 });
    const railMaterial = new THREE.MeshStandardMaterial({ color: 0xcdbda7, roughness: 0.26, metalness: 0.92 });
    const sleeperMaterial = new THREE.MeshStandardMaterial({ color: 0x241a1b, roughness: 1 });

    function buildTrack(centerX: number) {
      const bed = new THREE.Mesh(new THREE.BoxGeometry(6.4, 0.2, 440), ballastMaterial);
      bed.position.set(centerX, 0.1, -170);
      scene.add(bed);

      for (const offset of [-0.74, 0.74]) {
        const rail = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.18, 440), railMaterial);
        rail.position.set(centerX + offset, 0.24, -170);
        scene.add(rail);
      }

      const sleeperGeometry = new THREE.BoxGeometry(2.7, 0.1, 0.4);
      for (let z = 26; z > -340; z -= 3.2) {
        const sleeper = new THREE.Mesh(sleeperGeometry, sleeperMaterial);
        sleeper.position.set(centerX, 0.17, z);
        scene.add(sleeper);
      }
    }

    buildTrack(0.4);
    buildTrack(-4.4);

    // platform, canopy, lamps and name board
    const platform = new THREE.Mesh(
      new THREE.BoxGeometry(9.4, 0.9, 440),
      new THREE.MeshStandardMaterial({ color: 0xbcaa92, roughness: 0.95 }),
    );
    platform.position.set(8.6, 0.45, -170);
    scene.add(platform);

    const edgeLine = new THREE.Mesh(
      new THREE.BoxGeometry(0.22, 0.03, 440),
      new THREE.MeshStandardMaterial({ color: 0xe8d8b8, roughness: 0.8, emissive: 0x2a2016, emissiveIntensity: 1 }),
    );
    edgeLine.position.set(4.3, 0.91, -170);
    scene.add(edgeLine);

    const columnMaterial = new THREE.MeshStandardMaterial({ color: 0x3a2226, roughness: 0.65, metalness: 0.25 });
    const canopyMaterial = new THREE.MeshStandardMaterial({ color: 0x281417, roughness: 0.82 });
    for (let z = 14; z > -300; z -= 18) {
      const column = new THREE.Mesh(new THREE.BoxGeometry(0.24, 3.7, 0.24), columnMaterial);
      column.position.set(5.8, 2.7, z);
      scene.add(column);
    }
    const canopy = new THREE.Mesh(new THREE.BoxGeometry(9, 0.24, 200), canopyMaterial);
    canopy.position.set(9.4, 4.65, -140);
    scene.add(canopy);

    const lampMaterial = new THREE.MeshStandardMaterial({ color: 0xffe2b4, emissive: 0xffd39a, emissiveIntensity: 3 });
    for (let z = 8; z > -260; z -= 22) {
      const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.16, 10, 10), lampMaterial);
      lamp.position.set(8.4, 4.4, z);
      scene.add(lamp);
    }

    // benches and a fence along the platform
    const benchMaterial = new THREE.MeshStandardMaterial({ color: 0x4a3430, roughness: 0.85 });
    for (let index = 0; index < 7; index += 1) {
      const bench = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.12, 2.2), benchMaterial);
      bench.position.set(7.4, 1.15, 6 - index * 16);
      scene.add(bench);
      const back = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.5, 2.2), benchMaterial);
      back.position.set(7.7, 1.4, 6 - index * 16);
      scene.add(back);
    }

    const sign = new THREE.Mesh(
      new THREE.PlaneGeometry(6.4, 1.6),
      new THREE.MeshBasicMaterial({ map: plateTexture("SECUNDERABAD", 1024, 256, "bold 118px sans-serif"), toneMapped: false }),
    );
    sign.position.set(8.8, 3.55, -10);
    sign.rotation.y = -0.42;
    sign.scale.set(0.66, 0.66, 1);
    scene.add(sign);

    // station building behind the platform
    const buildingMaterial = new THREE.MeshStandardMaterial({ color: 0x6c4a3d, roughness: 0.9 });
    const stationBuilding = new THREE.Mesh(new THREE.BoxGeometry(16, 8, 40), buildingMaterial);
    stationBuilding.position.set(24, 4, -34);
    scene.add(stationBuilding);
    const windowMaterial = new THREE.MeshStandardMaterial({ color: 0x1a1c22, emissive: 0xffc98a, emissiveIntensity: 0.7 });
    for (let index = 0; index < 8; index += 1) {
      const pane = new THREE.Mesh(new THREE.BoxGeometry(0.1, 1.5, 2.2), windowMaterial);
      pane.position.set(15.95, 4.4, -18 - index * 4.4);
      scene.add(pane);
    }

    // footbridge over the running lines
    const bridgeMaterial = new THREE.MeshStandardMaterial({ color: 0x2b2022, roughness: 0.9, metalness: 0.3 });
    const bridgeDeck = new THREE.Mesh(new THREE.BoxGeometry(42, 0.5, 3.4), bridgeMaterial);
    bridgeDeck.position.set(2, 7.4, -52);
    scene.add(bridgeDeck);
    for (const x of [-16, 16]) {
      const tower = new THREE.Mesh(new THREE.BoxGeometry(2.4, 7.4, 2.4), bridgeMaterial);
      tower.position.set(x, 3.7, -52);
      scene.add(tower);
    }
    for (const side of [-1.7, 1.7]) {
      const railing = new THREE.Mesh(new THREE.BoxGeometry(42, 0.95, 0.1), bridgeMaterial);
      railing.position.set(2, 8.1, -52 + side);
      scene.add(railing);
    }

    // catenary
    const mastMaterial = new THREE.MeshStandardMaterial({ color: 0x2c2622, roughness: 0.7, metalness: 0.45 });
    const wireMaterial = new THREE.MeshStandardMaterial({ color: 0x201c1b, roughness: 0.9 });
    for (let z = 18; z > -300; z -= 22) {
      const mast = new THREE.Mesh(new THREE.BoxGeometry(0.24, 8.6, 0.24), mastMaterial);
      mast.position.set(-6.6, 4.3, z);
      scene.add(mast);
      const arm = new THREE.Mesh(new THREE.BoxGeometry(7.4, 0.1, 0.1), mastMaterial);
      arm.position.set(-3.2, 7.8, z);
      scene.add(arm);
      const drop = new THREE.Mesh(new THREE.BoxGeometry(0.06, 1.2, 0.06), mastMaterial);
      drop.position.set(0.4, 7.1, z);
      scene.add(drop);
    }
    for (const y of [6.5, 7.5]) {
      for (const x of [0.4, -4.4]) {
        const wire = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.035, 380), wireMaterial);
        wire.position.set(x, y, -170);
        scene.add(wire);
      }
    }

    // a stabled rake on the second road for depth
    const stabled = new THREE.Group();
    stabled.add(buildCoach(0));
    stabled.add(buildCoach(-17.4));
    stabled.add(buildCoach(-34.8));
    stabled.position.set(-4.4, 0, -58);
    scene.add(stabled);

    const train = buildLocomotive();
    train.add(buildCoach(-17.6));
    train.add(buildCoach(-35.2));
    train.position.set(0.4, 0, START_Z);
    scene.add(train);

    const headlight = new THREE.PointLight(0xffe6bd, 5, 34, 2);
    headlight.position.set(0, 2.05, 11);
    train.add(headlight);

    const platformLight = new THREE.PointLight(0xffcf9c, 34, 70, 2);
    platformLight.position.set(6.6, 4.1, 0);
    scene.add(platformLight);

    const buildingMaterialDistant = new THREE.MeshStandardMaterial({ color: 0x2f1e20, roughness: 1 });
    for (let index = 0; index < 6; index += 1) {
      const height = 7 + (index % 3) * 2.4;
      const building = new THREE.Mesh(new THREE.BoxGeometry(12, height, 10), buildingMaterialDistant);
      building.position.set(-34 - index * 15, height / 2, -90 - index * 38);
      scene.add(building);
    }

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    function resize() {
      const width = hostElement.clientWidth || 1;
      const height = hostElement.clientHeight || 1;
      renderer.setSize(width, height, false);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
    }

    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(hostElement);

    let frame = 0;
    let lastZ = START_Z;
    const started = performance.now();
    const wheels = group_wheels(train);

    function render(t: number) {
      const local = t % CYCLE;
      const z = trainZ(local);
      train.position.z = z;

      const delta = z - lastZ;
      lastZ = z;
      if (wheels) {
        for (const wheel of wheels) wheel.rotation.x -= delta / 0.56;
      }

      const running = local < HALT_AT || (local > DWELL_END && local < GONE_AT);
      train.position.y = running ? Math.sin(t / 160) * 0.03 : 0;
      train.rotation.z = running ? Math.sin(t / 260) * 0.004 : 0;

      const sway = Math.sin(t / 5200) * 0.16;
      const near = Math.max(0, 1 - Math.abs(z - HALT_Z) / 30);
      camera.position.x = 2.2 + sway + Math.sin(t / 90) * 0.014 * near;
      camera.position.y = 3.2 + Math.sin(t / 7600) * 0.04;
      camera.lookAt(0.4 + sway * 0.3, 2.6, -30);

      renderer.render(scene, camera);
    }

    if (reduced) {
      render(HALT_AT - 600);
    } else {
      const animate = () => {
        render(performance.now() - started);
        frame = requestAnimationFrame(animate);
      };
      frame = requestAnimationFrame(animate);
    }

    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
      scene.traverse((child) => {
        if (child instanceof THREE.Mesh) {
          child.geometry.dispose();
          const material = child.material;
          if (Array.isArray(material)) material.forEach((item) => item.dispose());
          else material.dispose();
        }
      });
      renderer.dispose();
      if (renderer.domElement.parentNode === hostElement) hostElement.removeChild(renderer.domElement);
    };
  }, []);

  return <div ref={hostRef} className="pointer-events-none absolute inset-0" aria-hidden />;
}

function group_wheels(group: THREE.Group) {
  return group.userData.wheels as THREE.Mesh[] | undefined;
}
