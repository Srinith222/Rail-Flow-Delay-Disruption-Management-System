import type { Block, Snapshot, Station, Train } from "@/types";

const W = 1380;
const H = 396;
const PAD_L = 78;
const PAD_R = 62;
const BASE_Y = 196;
const LANE = 34;
const EXTRA_Y = BASE_Y - LANE - 20;

const PLATE: Record<string, string> = {
  SC: "#2f6fb5",
  MJF: "#2f8f86",
  BMO: "#3c8a4a",
  MED: "#b59223",
  MOB: "#7a4fa8",
  ME: "#b56b2f",
  WDR: "#a83b3b",
};

function stationX(station: Station, totalKm: number) {
  return PAD_L + (station.km / totalKm) * (W - PAD_L - PAD_R);
}

function Signal({
  x,
  y,
  dir,
  aspect,
  code,
  shape = "triangle",
}: {
  x: number;
  y: number;
  dir: "UP" | "DOWN";
  aspect: "clear" | "caution" | "danger";
  code: string;
  shape?: "triangle" | "d";
}) {
  const colour = aspect === "clear" ? "#4ade80" : aspect === "caution" ? "#fbbf24" : "#f87171";
  const up = dir === "UP";
  return (
    <g>
      <line x1={x} y1={y} x2={x} y2={y + (up ? -15 : 15)} stroke="#7f8b9c" strokeWidth={1.3} />
      {shape === "triangle" ? (
        <polygon
          points={up ? `${x - 8},${y - 6} ${x + 1},${y} ${x - 8},${y + 6}` : `${x + 8},${y - 6} ${x - 1},${y} ${x + 8},${y + 6}`}
          fill="none"
          stroke="#c7d2df"
          strokeWidth={1.6}
        />
      ) : (
        <path
          d={
            up
              ? `M${x} ${y - 6.5} L${x + 6} ${y - 6.5} A6.5 6.5 0 0 1 ${x + 6} ${y + 6.5} L${x} ${y + 6.5}`
              : `M${x} ${y - 6.5} L${x - 6} ${y - 6.5} A6.5 6.5 0 0 0 ${x - 6} ${y + 6.5} L${x} ${y + 6.5}`
          }
          fill="none"
          stroke="#c7d2df"
          strokeWidth={1.6}
        />
      )}
      <circle cx={up ? x + 7.5 : x - 7.5} cy={y} r={2.8} fill={colour} />
      <text className="map-detail" x={x} y={y + (up ? -23 : 26)} textAnchor="middle" fontSize={9} fill="#7b8899" letterSpacing={0.3}>
        {code}
      </text>
    </g>
  );
}

export function SignalMap({
  snap,
  onSelectTrain,
}: {
  snap: Snapshot;
  onSelectTrain: (trainNo: string) => void;
}) {
  const stations = snap.corridor.stations;
  const totalKm = stations[stations.length - 1].km;
  const byCode = Object.fromEntries(stations.map((station) => [station.code, station]));

  const blockedBlocks = new Set(snap.disruptions.filter((item) => item.blockId).map((item) => item.blockId as string));
  const active = snap.trains.filter((train) => train.status !== "arrived" && train.status !== "cancelled");

  const blockOf = (train: Train): Block | undefined =>
    snap.corridor.blocks.find((item) => item.id === (train.inBlock ?? "").replace("–", "-") || item.id === train.inBlock);

  const laneFor = (block: Block | undefined, train: Train) => {
    if (!block || block.track === "single") return BASE_Y + (train.dir === "UP" ? -7 : 7);
    return BASE_Y + (train.dir === "UP" ? -LANE : LANE);
  };

  const routed = active.find((train) => train.status === "running" && train.cls === "express" && train.dir === "UP");
  const routedX = routed ? stationX({ ...stations[0], km: routed.km }, totalKm) : 0;
  const routedNext = routed ? stations.find((station) => station.km > routed.km) : undefined;
  const routedY = routed ? laneFor(blockOf(routed), routed) : BASE_Y;

  return (
    <div>
      <svg
        viewBox={`0 0 ${W} ${H}`}
        className="h-auto w-full"
        role="img"
        aria-label="Signal-zone diagram, Secunderabad to Wadiaram"
      >
        <rect width={W} height={H} rx={6} fill="#070b14" />

        {stations.map((station) => (
          <line
            key={`grid-${station.code}`}
            x1={stationX(station, totalKm)}
            y1={44}
            x2={stationX(station, totalKm)}
            y2={H - 24}
            stroke="rgba(150,190,230,0.12)"
            strokeDasharray="4 6"
          />
        ))}

        {snap.corridor.blocks.map((block) => {
          const x1 = stationX(byCode[block.from], totalKm);
          const x2 = stationX(byCode[block.to], totalKm);
          const blocked = blockedBlocks.has(block.id);
          const colour = blocked ? "#f87171" : "#b9c4d1";
          const label = `${block.id} · ${block.track.toUpperCase()} · ${block.km} km`;

          if (block.track === "single") {
            return (
              <g key={block.id}>
                <line x1={x1} y1={BASE_Y} x2={x2} y2={BASE_Y} stroke={colour} strokeWidth={2.2} />
                <text className="map-detail" x={(x1 + x2) / 2} y={92} textAnchor="middle" fontSize={11} fill="#7c8b9e" letterSpacing={0.8}>
                  {label}
                </text>
                {blocked ? (
                  <text x={(x1 + x2) / 2} y={BASE_Y + 34} textAnchor="middle" fontSize={11} fill="#f87171" letterSpacing={1.2}>
                    BLOCKED
                  </text>
                ) : null}
              </g>
            );
          }

          return (
            <g key={block.id}>
              <line x1={x1} y1={BASE_Y - LANE} x2={x2} y2={BASE_Y - LANE} stroke={colour} strokeWidth={2} />
              <line x1={x1} y1={BASE_Y + LANE} x2={x2} y2={BASE_Y + LANE} stroke={colour} strokeWidth={2} />
              <text className="map-detail" x={(x1 + x2) / 2} y={92} textAnchor="middle" fontSize={11} fill="#7c8b9e" letterSpacing={0.8}>
                {label}
              </text>
              {blocked ? (
                <g>
                  <line
                    x1={x1}
                    y1={BASE_Y - LANE}
                    x2={x2}
                    y2={BASE_Y - LANE}
                    stroke="#f87171"
                    strokeWidth={3}
                    strokeDasharray="3 5"
                  />
                  <line
                    x1={x1}
                    y1={BASE_Y + LANE}
                    x2={x2}
                    y2={BASE_Y + LANE}
                    stroke="#f87171"
                    strokeWidth={3}
                    strokeDasharray="3 5"
                  />
                  <text x={(x1 + x2) / 2} y={BASE_Y + 56} textAnchor="middle" fontSize={11} fill="#f87171" letterSpacing={1.2}>
                    BLOCKED
                  </text>
                </g>
              ) : null}
            </g>
          );
        })}

        {/* running line direction arrows */}
        {[BASE_Y - LANE, BASE_Y + LANE].map((y, laneIndex) => (
          <g key={`arrows-${y}`} stroke="#5d6d82" strokeWidth={1.4} fill="none">
            {Array.from({ length: 12 }).map((_, index) => {
              const x = PAD_L + 50 + index * ((W - PAD_L - PAD_R - 80) / 12);
              return laneIndex === 0 ? (
                <path key={x} d={`M${x} ${y - 5} l7 5 l-7 5`} />
              ) : (
                <path key={x} d={`M${x} ${y - 5} l-7 5 l7 5`} />
              );
            })}
          </g>
        ))}

        {/* platform roads, crossovers and station bars */}
        {stations.map((station) => {
          const x = stationX(station, totalKm);
          const plate = PLATE[station.code] ?? "#3c4a5c";
          const plateLabel = `${station.code} · ${station.name.replace(" Jn", "")}`;
          const plateWidth = Math.max(104, plateLabel.length * 7.4 + 22);
          const extraRoad = station.platforms >= 4;

          return (
            <g key={station.code}>
              <line x1={x} y1={54} x2={x} y2={BASE_Y + 74} stroke="#8fa0b4" strokeWidth={1.8} />
              <line x1={x - 52} y1={BASE_Y} x2={x + 52} y2={BASE_Y} stroke="#a9b6c6" strokeWidth={1.6} />
              <path
                d={`M${x - 72} ${BASE_Y - LANE} L${x - 52} ${BASE_Y} M${x + 52} ${BASE_Y} L${x + 72} ${BASE_Y - LANE}`}
                stroke="#a9b6c6"
                strokeWidth={1.6}
                fill="none"
              />
              <path
                d={`M${x - 72} ${BASE_Y + LANE} L${x - 52} ${BASE_Y} M${x + 52} ${BASE_Y} L${x + 72} ${BASE_Y + LANE}`}
                stroke="#a9b6c6"
                strokeWidth={1.6}
                fill="none"
              />
              {extraRoad ? (
                <g>
                  <line x1={x - 46} y1={EXTRA_Y} x2={x + 46} y2={EXTRA_Y} stroke="#8c9aab" strokeWidth={1.6} />
                  <path
                    d={`M${x - 66} ${BASE_Y - LANE} L${x - 46} ${EXTRA_Y} M${x + 46} ${EXTRA_Y} L${x + 66} ${BASE_Y - LANE}`}
                    stroke="#8c9aab"
                    strokeWidth={1.6}
                    fill="none"
                  />
                </g>
              ) : null}
              <rect x={x - plateWidth / 2} y={26} width={plateWidth} height={25} rx={3} fill={plate} />
              <text x={x} y={43} textAnchor="middle" fontSize={13} fontWeight={600} fill="#ffffff" letterSpacing={0.4}>
                {plateLabel}
              </text>
              <text className="map-detail" x={x} y={BASE_Y + 92} textAnchor="middle" fontSize={10.5} fill="#8b99aa">
                {station.km} km · {station.platforms} PF
              </text>
            </g>
          );
        })}

        {/* yard fans at the outer ends */}
        {[0, 1].map((end) => {
          const first = stations[0];
          const last = stations[stations.length - 1];
          const x = stationX(end === 0 ? first : last, totalKm);
          const out = end === 0 ? -1 : 1;
          return (
            <g key={`fan-${end}`} stroke="#7b899c" strokeWidth={1.6}>
              <line x1={x + out * 8} y1={BASE_Y - LANE} x2={x + out * 84} y2={BASE_Y - LANE} />
              <line x1={x + out * 8} y1={BASE_Y + LANE} x2={x + out * 84} y2={BASE_Y + LANE} />
              <line x1={x + out * 8} y1={BASE_Y} x2={x + out * 84} y2={BASE_Y} />
              <path d={`M${x + out * 84} ${BASE_Y - LANE} L${x + out * 104} ${BASE_Y}`} fill="none" />
              <path d={`M${x + out * 84} ${BASE_Y + LANE} L${x + out * 104} ${BASE_Y}`} fill="none" />
            </g>
          );
        })}

        {/* signals: home signal on arrival, starter on departure */}
        {snap.corridor.blocks.map((block) => {
          const left = stationX(byCode[block.from], totalKm);
          const right = stationX(byCode[block.to], totalKm);
          const y = block.track === "single" ? BASE_Y : BASE_Y - LANE;
          const danger = blockedBlocks.has(block.id);
          return (
            <g key={`sig-${block.id}`}>
              <Signal x={left + 18} y={y} dir="UP" aspect={danger ? "danger" : "clear"} code={`${block.from} S`} />
              <Signal
                x={right - 18}
                y={BASE_Y + (block.track === "single" ? 0 : LANE)}
                dir="DOWN"
                aspect={danger ? "danger" : "clear"}
                code={`${block.to} H`}
                shape="d"
              />
            </g>
          );
        })}

        {/* route set for the leading express */}
        {routed && routedNext ? (
          <g>
            <line
              x1={routedX}
              y1={routedY}
              x2={stationX(routedNext, totalKm)}
              y2={routedY}
              stroke="#37d67a"
              strokeWidth={2.2}
              opacity={0.9}
            />
            <circle cx={stationX(routedNext, totalKm)} cy={routedY} r={2.8} fill="#37d67a" />
          </g>
        ) : null}

        {active.slice(0, 18).map((train) => {
          const block = blockOf(train);
          const x = stationX({ ...stations[0], km: train.km }, totalKm);
          const y = laneFor(block, train);
          const tone =
            train.status === "held"
              ? "#60a5fa"
              : train.delay >= 12
                ? "#f87171"
                : train.delay >= 6
                  ? "#fbbf24"
                  : "#4ade80";
          return (
            <g key={train.no} className="cursor-pointer" onClick={() => onSelectTrain(train.no)}>
              <rect x={x - 29} y={y - 27} width={58} height={17} rx={2.5} fill={tone} opacity={0.95} />
              <text x={x} y={y - 14.5} textAnchor="middle" fontSize={10} fontWeight={600} fill="#08110c">
                {train.no}
              </text>
              <circle cx={x} cy={y} r={4.2} fill={tone} stroke="#070b14" strokeWidth={1.2} />
              <title>{`${train.no} ${train.name} · ${train.statusLabel} · ${train.delay > 0 ? `+${train.delay} min` : "on time"}`}</title>
            </g>
          );
        })}

        <text x={PAD_L} y={H - 10} fontSize={11} fill="#6b7a8c" letterSpacing={1.4}>
          UP → WADIRAM
        </text>
        <text x={W - PAD_R} y={H - 10} textAnchor="end" fontSize={11} fill="#6b7a8c" letterSpacing={1.4}>
          ← DOWN SECUNDERABAD
        </text>
      </svg>
    </div>
  );
}
