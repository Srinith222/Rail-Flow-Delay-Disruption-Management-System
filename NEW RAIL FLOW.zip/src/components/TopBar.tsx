import { Check, RefreshCw, RotateCcw } from "lucide-react";
import { useEffect, useState } from "react";
import { Segmented } from "@/components/ui";
import type { Role, Snapshot, ViewId } from "@/types";

const TITLES: Record<ViewId, string> = {
  home: "RailFlow",
  overview: "Section overview",
  signals: "Signal zone diagram",
  trains: "Live running board",
  disruptions: "Disruption desk",
  regulator: "Traffic regulator",
  station: "Station console",
  live: "Live train data",
  log: "Corridor record",
};

export function TopBar({
  view,
  role,
  snap,
  busy,
  refreshing,
  lastSync,
  onRole,
  onRefresh,
  onReset,
}: {
  view: ViewId;
  role: Role;
  snap: Snapshot;
  busy: boolean;
  refreshing: boolean;
  lastSync: number | null;
  onRole: (role: Role) => void;
  onRefresh: () => void;
  onReset: () => void;
}) {
  const [justUpdated, setJustUpdated] = useState(false);

  useEffect(() => {
    if (!lastSync) return;
    setJustUpdated(true);
    const timer = window.setTimeout(() => setJustUpdated(false), 1800);
    return () => window.clearTimeout(timer);
  }, [lastSync]);

  const updatedLabel = lastSync
    ? new Date(lastSync).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })
    : null;

  return (
    <header className="sticky top-0 z-20 border-b border-line bg-canvas/80 px-5 py-4 backdrop-blur-xl lg:px-9">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="min-w-0">
          <p className="text-[10px] text-muted">{snap.corridor.division}</p>
          <h1 className="mt-0.5 truncate font-display text-[16px] font-semibold tracking-[-0.02em] text-cream">
            {TITLES[view]}
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={onRefresh}
            disabled={refreshing}
            aria-label="Refresh corridor data"
            title={updatedLabel ? `Last updated ${updatedLabel}` : "Refresh corridor data"}
            className="group inline-flex items-center gap-2 rounded border border-line px-3 py-2 text-[12px] text-cream/70 transition-colors hover:border-cream/30 hover:text-cream disabled:opacity-50"
          >
            {justUpdated && !refreshing ? (
              <Check size={13} className="text-signal" />
            ) : (
              <RefreshCw size={13} className={refreshing ? "animate-spin" : "transition-transform duration-500 group-hover:rotate-90"} />
            )}
            <span className="hidden sm:inline">{refreshing ? "Refreshing" : justUpdated ? "Updated" : "Refresh"}</span>
          </button>

          <Segmented<Role>
            size="sm"
            value={role}
            onChange={onRole}
            options={[
              { id: "controller", label: "Section controller" },
              { id: "master", label: "Station master" },
            ]}
          />

          <div className="flex items-center gap-2 rounded border border-line px-3 py-1.5">
            <span className="live-dot h-1.5 w-1.5 rounded-full bg-signal" />
            <span className="num text-[14px] text-cream">{snap.clock}</span>
            <span className="text-[10px] text-muted">sim</span>
          </div>

          <button
            type="button"
            onClick={onReset}
            disabled={busy}
            title="Reset the simulation to 07:30"
            className="group inline-flex items-center gap-2 rounded border border-line px-3 py-2 text-[12px] text-cream/70 transition-colors hover:border-ember/50 hover:text-ember disabled:opacity-40"
          >
            <RotateCcw size={13} className="transition-transform duration-500 group-hover:-rotate-180" />
            <span className="hidden sm:inline">Reset</span>
          </button>
        </div>
      </div>
    </header>
  );
}
