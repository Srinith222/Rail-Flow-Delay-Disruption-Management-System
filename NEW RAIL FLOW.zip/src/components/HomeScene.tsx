export function HomeScene() {
  return (
    <svg
      viewBox="0 0 1440 900"
      preserveAspectRatio="xMidYMid slice"
      className="h-full w-full"
      aria-hidden
    >
      <defs>
        <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#fce8c4" />
          <stop offset="30%" stopColor="#f7bf88" />
          <stop offset="52%" stopColor="#ea8b57" />
          <stop offset="72%" stopColor="#c05a45" />
          <stop offset="100%" stopColor="#7d3231" />
        </linearGradient>
        <radialGradient id="sunGlow" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0%" stopColor="#fff3d2" stopOpacity="0.95" />
          <stop offset="45%" stopColor="#ffd79a" stopOpacity="0.4" />
          <stop offset="100%" stopColor="#ffb877" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="haze" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#ffe3ba" stopOpacity="0.5" />
          <stop offset="100%" stopColor="#ffd7a0" stopOpacity="0" />
        </linearGradient>
      </defs>

      <rect width="1440" height="900" fill="url(#sky)" />

      <circle cx="430" cy="420" r="270" fill="url(#sunGlow)" />
      <circle cx="430" cy="420" r="54" fill="#ffeccd" opacity="0.9" />

      <g fill="#ffe6c0" opacity="0.16">
        <ellipse cx="300" cy="230" rx="270" ry="14" />
        <ellipse cx="790" cy="180" rx="330" ry="11" />
        <ellipse cx="1140" cy="260" rx="240" ry="9" />
      </g>

      {/* far mesas, sitting just above the three-dimensional horizon */}
      <path
        d="M0 470 L110 412 L250 452 L380 396 L520 446 L660 402 L820 458 L970 408 L1120 452 L1270 402 L1440 448 L1440 620 L0 620 Z"
        fill="#a36253"
        opacity="0.5"
      />
      <path
        d="M0 506 L180 462 L330 502 L470 452 L620 500 L760 460 L900 506 L1060 462 L1210 508 L1340 470 L1440 500 L1440 660 L0 660 Z"
        fill="#854a42"
        opacity="0.62"
      />

      <rect width="1440" height="280" fill="url(#haze)" opacity="0.55" />

      <g stroke="#3c1a1c" strokeWidth="2" fill="none" opacity="0.35">
        <path d="M250 220 q 8 -8 16 0 q 8 -8 16 0" />
        <path d="M310 190 q 6 -6 12 0 q 6 -6 12 0" />
        <path d="M196 268 q 5 -5 10 0 q 5 -5 10 0" />
      </g>
    </svg>
  );
}
