import { useEffect, useState } from "react";
import { Sidebar } from "@/components/Sidebar";
import { TopBar } from "@/components/TopBar";
import { useRailflow } from "@/lib/api";
import { DisruptionsView } from "@/views/Disruptions";
import { Home } from "@/views/Home";
import { LiveView } from "@/views/Live";
import { LogView } from "@/views/Log";
import { Overview } from "@/views/Overview";
import { RegulatorView } from "@/views/Regulator";
import { SignalsView } from "@/views/Signals";
import { StationView } from "@/views/Station";
import { TrainsView } from "@/views/Trains";
import type { Role, ViewId } from "@/types";

const ACCESS_KEY = "railflow.access";

export default function App() {
  const { snap, error, busy, lastSync, post, refresh, fetchPlan } = useRailflow();
  const [unlocked, setUnlocked] = useState(() => {
    try {
      return sessionStorage.getItem(ACCESS_KEY) === "1";
    } catch {
      return false;
    }
  });
  const [role, setRole] = useState<Role>("controller");
  const [view, setView] = useState<ViewId>("overview");
  const [collapsed, setCollapsed] = useState(false);
  const [focusTrain, setFocusTrain] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  async function handleRefresh() {
    setRefreshing(true);
    try {
      await refresh();
    } finally {
      setRefreshing(false);
    }
  }

  function unlock() {
    try {
      sessionStorage.setItem(ACCESS_KEY, "1");
    } catch {
      /* storage blocked — the session still works in memory */
    }
    setUnlocked(true);
    setView("overview");
  }

  function lock() {
    try {
      sessionStorage.removeItem(ACCESS_KEY);
    } catch {
      /* ignore */
    }
    setUnlocked(false);
    setView("overview");
  }

  useEffect(() => {
    if (!snap) return;
    const allowed: ViewId[] =
      role === "master"
        ? ["home", "overview", "signals", "trains", "station", "live", "log"]
        : ["home", "overview", "signals", "trains", "disruptions", "regulator", "station", "live", "log"];
    if (!allowed.includes(view)) setView("station");
  }, [role, view, snap]);

  function openTrain(trainNo: string) {
    setFocusTrain(trainNo);
    setView("trains");
  }

  if (!unlocked) return <Home onUnlock={unlock} />;

  if (!snap) {
    return (
      <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-canvas">
        <div className="text-center">
          <div className="mx-auto flex h-9 w-9 items-center justify-center rounded border border-cream/25 text-cream">
            <svg width="16" height="16" viewBox="0 0 16 16" aria-hidden>
              <path d="M3.5 2v12M12.5 2v12M3.5 6h9M3.5 10h9" stroke="currentColor" strokeWidth="1.2" fill="none" />
            </svg>
          </div>
          <p className="mt-4 text-[14px] font-semibold text-cream">RailFlow</p>
          <p className="mt-1 text-[12px] text-muted">{error ?? "Connecting to the section control feed…"}</p>
          {error ? (
            <button type="button" onClick={() => void refresh()} className="btn-ghost mt-5">
              Retry
            </button>
          ) : null}
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen bg-canvas">
      <div className="relative flex">
        <Sidebar
          view={view}
          role={role}
          collapsed={collapsed}
          snap={snap}
          onNavigate={setView}
          onToggle={() => setCollapsed((value) => !value)}
          onLock={lock}
        />

        <main className="min-w-0 flex-1">
          <TopBar
            view={view}
            role={role}
            snap={snap}
            busy={busy}
            refreshing={refreshing}
            lastSync={lastSync}
            onRole={setRole}
            onRefresh={() => void handleRefresh()}
            onReset={() => void post("/api/reset")}
          />

          {error ? (
            <div className="mx-5 mt-4 rounded border border-ember/30 bg-ember/[0.07] px-4 py-2.5 text-[11.5px] text-ember lg:mx-9">
              {error}
            </div>
          ) : null}

          <div key={view} className="view-enter px-4 pb-16 pt-5 lg:px-9">
            {view === "overview" ? (
              <Overview snap={snap} onNavigate={setView} onSelectTrain={openTrain} />
            ) : null}
            {view === "signals" ? (
              <SignalsView
                snap={snap}
                busy={busy}
                onSelectTrain={openTrain}
                onReset={() => void post("/api/reset")}
              />
            ) : null}
            {view === "trains" ? (
              <TrainsView
                snap={snap}
                post={post}
                busy={busy}
                initialTrain={focusTrain}
                onClearInitial={() => setFocusTrain(null)}
              />
            ) : null}
            {view === "disruptions" ? (
              <DisruptionsView snap={snap} post={post} busy={busy} fetchPlan={fetchPlan} />
            ) : null}
            {view === "regulator" ? <RegulatorView snap={snap} onSelectTrain={openTrain} /> : null}
            {view === "station" ? <StationView snap={snap} post={post} busy={busy} /> : null}
            {view === "live" ? <LiveView snap={snap} post={post} busy={busy} /> : null}
            {view === "log" ? <LogView snap={snap} /> : null}
          </div>
        </main>
      </div>
    </div>
  );
}
