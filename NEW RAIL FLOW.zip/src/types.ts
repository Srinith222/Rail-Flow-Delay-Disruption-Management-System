export type Role = "controller" | "master";

export type ViewId =
  | "home"
  | "overview"
  | "signals"
  | "trains"
  | "disruptions"
  | "regulator"
  | "station"
  | "live"
  | "log";

export type TrainStatus = "upcoming" | "arrived" | "held" | "delayed" | "running" | "cancelled";

export type TrainClass = "express" | "suburban" | "passenger" | "freight";

export interface Stop {
  code: string;
  name: string;
  schedArr: number;
  schedDep: number;
  arr: number;
  dep: number;
  platform: number;
  shift: number;
  passed: boolean;
}

export interface Train {
  no: string;
  name: string;
  cls: TrainClass;
  weight: number;
  dir: "UP" | "DOWN";
  status: TrainStatus;
  statusLabel: string;
  delay: number;
  currentDelay: number;
  primaryDelay: number;
  reasons: string[];
  disruptionIds: string[];
  origin: string;
  destination: string;
  originName: string;
  destinationName: string;
  schedDep: number;
  schedArr: number;
  eta: number;
  nextCode: string;
  nextName: string;
  km: number;
  progress: number;
  inBlock: string | null;
  platform: number;
  hold: { station: string; untilMin: number; minutes: number; reason: string } | null;
  stops: Stop[];
}

export interface Disruption {
  id: string;
  kind: string;
  label: string;
  blockId: string | null;
  stationCode: string | null;
  trainNo: string | null;
  trainName: string | null;
  durationMin: number;
  reason: string;
  severity: "low" | "medium" | "high";
  status: "active" | "resolved" | "expired";
  createdAt: string;
  startMin: number;
  endMin: number;
  createdBy: string;
  blockTrack: "single" | "double" | null;
  fromName: string | null;
  toName: string | null;
  stationName: string | null;
  affectedTrains: string[];
  affectedDelay: number;
  minutesLeft: number;
}

export interface Stats {
  active: number;
  delayed: number;
  held: number;
  upcoming: number;
  completed: number;
  avgDelay: number;
  weightedDelay: number;
  onTimePct: number;
  activeDisruptions: number;
  affectedTrains: number;
}

export interface Conflict {
  id: string;
  blockId: string;
  blockLabel: string;
  track: "single" | "double";
  trains: string[];
  gap: number;
  at: string;
  severity: "high" | "medium";
  kind: string;
}

export interface Instruction {
  id: string;
  trainNo: string;
  trainName: string;
  station: string;
  stationName: string;
  action: string;
  minutes: number;
  reason: string;
  createdAt: string;
  clock: number;
  status: "PENDING" | "ACK";
  createdBy: string;
  ackBy?: string;
  ackAt?: string;
  disruptionId?: string;
}

export interface LogEntry {
  id: string;
  at: string;
  clock: number;
  kind: string;
  actor: string;
  text: string;
}

export interface Station {
  code: string;
  name: string;
  km: number;
  platforms: number;
  major: boolean;
}

export interface Block {
  id: string;
  from: string;
  to: string;
  track: "single" | "double";
  km: number;
}

export interface Corridor {
  name: string;
  division: string;
  stations: Station[];
  blocks: Block[];
  classes: Record<string, { label: string; speed: number; weight: number; dwell: number }>;
}

export interface Snapshot {
  now: number;
  clock: string;
  trains: Train[];
  disruptions: Disruption[];
  stats: Stats;
  conflicts: Conflict[];
  corridor: Corridor;
  instructions: Instruction[];
  log: LogEntry[];
  speed: number;
}

export interface PlanItem {
  trainNo: string;
  name: string;
  cls: TrainClass;
  weight: number;
  station: string;
  stationName: string;
  holdMin: number;
  slot: string;
  order: number;
}

export interface LiveTrain {
  number: string;
  name: string;
  type: string;
  source: string;
  destination: string;
  sequence: number | null;
  scheduledArrival: string | null;
  scheduledDeparture: string | null;
  platform: string | null;
  status: string;
  delayMinutes: number;
  expectedArrival: string | null;
  expectedDeparture: string | null;
  isHalt: boolean;
  inModel?: boolean;
}

export interface LiveBoard {
  station: { code: string; name: string; city: string | null };
  window: { from: string; to: string; hoursBack: number; hoursAhead: number } | null;
  count: number;
  trains: LiveTrain[];
  meta?: { timestamp: string | null; source: string | null; traceId: string | null };
  cached?: boolean;
  stale?: boolean;
  fetchedAt?: string;
  error?: string;
}

export interface LiveStatus {
  configured: boolean;
  keySource: string | null;
  baseUrl: string;
  quota: {
    limitMonth: number | null;
    remainingMonth: number | null;
    limitMinute: number | null;
    remainingMinute: number | null;
  };
  lastSync: string | null;
  lastError: string | null;
  cacheSeconds: number;
}

export interface RecoveryPlan {
  disruptionId: string;
  blockId: string;
  headway: number;
  baselineCost: number;
  planCost: number;
  savings: number;
  items: PlanItem[];
  note: string;
}
