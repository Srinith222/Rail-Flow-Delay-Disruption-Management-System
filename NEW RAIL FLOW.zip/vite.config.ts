import { fileURLToPath } from "node:url";
import path from "node:path";
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const extraHosts: string[] = [
  process.env.PREVIEW_HOST,
  ...(process.env.__VITE_ADDITIONAL_SERVER_ALLOWED_HOSTS ?? "").split(","),
]
  .map((host) => (host ?? "").trim())
  .filter((host) => host.length > 0);

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: [{ find: "@", replacement: path.resolve(__dirname, "src") }],
  },
  server: {
    host: "0.0.0.0",
    port: 3000,
    strictPort: true,
    allowedHosts: extraHosts,
    proxy: {
      "/api": {
        target: "http://127.0.0.1:8787",
        changeOrigin: true,
      },
    },
  },
});
