# TrainVision AI - Technical Documentation

> **New here?** Read [README.md](./README.md) first for a plain-language overview of what the website does and how to run it locally.

## Table of Contents
1. [What the application does](#what-the-application-does)
2. [Code map (read this to navigate the repo)](#code-map-read-this-to-navigate-the-repo)
3. [System Overview](#system-overview)
4. [Architecture](#architecture)
5. [Core Algorithms](#core-algorithms)
6. [Data Models](#data-models)
7. [API Endpoints](#api-endpoints)
8. [Frontend Components](#frontend-components)
9. [AI Integration](#ai-integration)
10. [Deployment](#deployment)
11. [Use Cases](#use-cases)
12. [Development Guide](#development-guide)

## What the application does

TrainVision AI simulates a **railway operations control center** for three connected stations:

| Station | Role |
|---------|------|
| **HYB** (Hyderabad) | Origin/terminus, 4 platforms |
| **SC** (Secunderabad) | Junction, 6 platforms |
| **KCG** (Kacheguda) | Origin/terminus, 3 platforms |

The backend **assigns each train to platforms and times** using a greedy or ILP optimizer. When two trains want the same platform at the same time, the system either delays one train or moves it to another platform, then **records why** in the schedule `reason` field and audit log.

The frontend has **three screens**:

1. **Operations** — day-to-day monitoring: map, schedule table, timeline graph, overrides.
2. **Simulation** — “what if” scenarios without changing live state until you promote a recommendation.
3. **Analytics** — KPIs, charts, and 5-minute trend history.

Controllers interact through **selection** (click train → drawer), **overrides** (`POST /override`), and **recommendations** (`POST /apply-recommendation`).

## Code map (read this to navigate the repo)

### Request lifecycle (happy path)

```
Browser loads AppWithDashboards
  → OperationsFeedProvider polls GET /schedule, /conflicts, /track-status (5s)
  → WebSocket /ws for train positions
  → User clicks Override
  → POST /override → schedule_service.recompute_schedule()
  → greedy_optimizer() or ilp_optimizer() rebuilds all legs
  → detect_conflicts() → UI updates on next poll
```

### Backend files

| File | Responsibility |
|------|----------------|
| `main.py` | FastAPI routes, global schedule state, WebSocket, simulation endpoints |
| `schedule_service.py` | `ensure_schedule_state()`, `recompute_schedule()`, read-only schedule JSON |
| `optimizer.py` | Greedy scheduler; multi-leg loop; force-assign at `MAX_DELAY` |
| `train_legs.py` | Which stations each train visits (from JSON `train_legs` or origin→destination) |
| `conflict_detector.py` | Returns `Conflict` list + impact metrics |
| `analytics_trends.py` | Ring buffer of KPI snapshots (5-minute bucket dedupe) |
| `data/prototype_trains.json` | 15 trains, station metadata, leg definitions |

### Frontend files

| File | Responsibility |
|------|----------------|
| `AppWithDashboards.tsx` | Shell: nav tabs, recommendations panel, routes to 3 dashboards |
| `App.tsx` | Operations layout: map, rail, schedule/timeline/activity tabs |
| `context/OperationsFeedContext.tsx` | Single source of truth for live API data |
| `context/SelectionContext.tsx` | `selectedTrainId` / `selectedEntry` for drawer + override target |
| `components/operations/TrainGraph.tsx` | Time × platform bars, NOW line, live WS head markers |
| `components/operations/NetworkMap.tsx` | SVG corridor map; track occupancy colors; train click |
| `components/operations/ScheduleTable.tsx` | Sortable/filterable schedule; conflict badges |
| `components/SimulationDashboard.tsx` | Scenarios; compare mode; promote-to-live |
| `components/AnalyticsDashboard.tsx` | KPIs, trends, heatmap (hooks must run before any early `return`) |
| `lib/scheduleUtils.ts` | `getTrainStatus()`, delay helpers, KPI computation |

### Tests & CI

| Path | What it checks |
|------|----------------|
| `backend/tests/test_optimizer.py` | All trains/legs scheduled; no dropped legs |
| `backend/tests/test_override.py` | Override API + schedule stability |
| `backend/tests/test_feasibility.py` | Feasibility scores returned |
| `backend/tests/test_simulation.py` | Delay simulation payload |
| `rail-frontend/src/**/*.test.tsx` | Component smoke tests |
| `.github/workflows/ci.yml` | pytest + vitest + build on push/PR |

## System Overview

TrainVision AI is a comprehensive railway traffic management and optimization system that provides real-time train scheduling, conflict detection, and AI-powered decision support. The system is designed to handle complex railway operations with multiple stations, platforms, and train types while ensuring safety and efficiency.

### Key Features
- **Real-time Train Scheduling**: Dynamic optimization using Greedy and ILP algorithms
- **Conflict Detection**: Advanced conflict detection with severity assessment
- **AI-Powered Recommendations**: Intelligent suggestions using Google Gemini AI
- **Interactive Dashboards**: Multi-dashboard architecture for operations, simulation, and analytics
- **Manual Override System**: Controller override capabilities with feasibility analysis
- **Scenario Simulation**: What-if analysis for delays, breakdowns, and weather impacts
- **Real-time Visualization**: Live train movement tracking with WebSocket updates

## Architecture

### System Architecture
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Frontend      │    │    Backend      │    │   AI Services   │
│   (React/TS)    │◄──►│   (FastAPI)     │◄──►│  (Gemini AI)    │
│                 │    │                 │    │                 │
│ • Main Dashboard│    │ • REST API      │    │ • Schedule      │
│ • Simulation    │    │ • WebSocket     │    │   Analysis      │
│ • Analytics     │    │ • Optimization  │    │ • ChatBot       │
│ • ChatBot       │    │ • Conflict Det. │    │ • Recommendations│
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

### Technology Stack

#### Backend
- **Framework**: FastAPI (Python 3.11+)
- **Optimization**: PuLP, OR-Tools for ILP
- **AI Integration**: Google Generative AI (Gemini 2.5 Flash)
- **Real-time**: WebSocket for live updates
- **Data Models**: Pydantic for type safety
- **Environment**: python-dotenv for configuration

#### Frontend
- **Framework**: React 19+ with TypeScript
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Animation**: Framer Motion
- **Build Tool**: Vite
- **Routing**: React Router DOM

#### Deployment
- **Frontend**: Vercel (https://trainvision.vercel.app/)
- **Backend**: Render (https://trainvision-ai.onrender.com/)
- **Containerization**: Docker with multi-stage builds
- **CI/CD**: GitHub Actions (`.github/workflows/ci.yml` — pytest + vitest + build)

## Core Algorithms

### 1. Greedy Optimization Algorithm

**Location**: `backend/optimizer.py`

The greedy algorithm is the primary real-time optimization engine, designed for immediate scheduling decisions with conflict resolution:

```python
def greedy_optimizer(trains, stations, fixed_platforms):
    # Phase 1: Priority-based sorting
    def sort_key(train):
        is_fixed = fixed_platforms and train.id in fixed_platforms
        if is_fixed:
            return (0, train.scheduled_arrival)  # Fixed overrides first
        else:
            return (1, -train.priority, train.scheduled_arrival)  # Priority order
    
    # Phase 2: Platform assignment with conflict resolution
    for train in sorted_trains:
        platform = find_optimal_platform(train, station, platform_usage)
        if conflict_detected:
            resolve_conflict(train, conflicting_trains, delay_strategy)
        
    # Phase 3: Schedule optimization
    return optimized_schedule
```

**Algorithm Complexity**:
- **Time Complexity**: O(n log n + n×p×t) where n=trains, p=platforms, t=time_slots
- **Space Complexity**: O(n×p) for platform usage tracking
- **Performance**: <100ms for 100+ trains

**Key Features**:
- **Multi-phase optimization**: Sorting → Assignment → Conflict Resolution
- **Priority-based sorting**: Fixed overrides → Priority → Arrival time
- **Dynamic conflict resolution**: Real-time platform reassignment and delay injection
- **Adaptive delay strategy**: Minimal delay injection with cascading impact analysis
- **Override integration**: Seamless handling of manual controller interventions

**Optimization Strategies**:
1. **Platform Selection**: Prefers train's preferred platform, falls back to available platforms
2. **Conflict Avoidance**: Proactive conflict detection during assignment
3. **Delay Minimization**: 2-minute incremental delays with priority boosting
4. **Throughput Maximization**: Efficient platform utilization across all stations

### 2. Integer Linear Programming (ILP) Optimizer

**Location**: `backend/ilp_optimizer.py`

Advanced mathematical optimization engine for optimal railway throughput and resource utilization:

```python
class ILPOptimizer:
    def optimize(self, fixed_platforms, active_delays):
        # Phase 1: Problem formulation
        prob = pulp.LpProblem("TrainScheduling", pulp.LpMinimize)
        
        # Phase 2: Decision variables
        # x[t,s,p,slot] = 1 if train t assigned to platform p at station s in time slot
        x = {}  # Binary assignment variables
        delay_vars = {}  # Continuous delay variables
        
        # Phase 3: Objective function
        objective = Σ(delay_weight × delay_i) + Σ(conflict_weight × conflicts)
        
        # Phase 4: Constraint system
        add_capacity_constraints()
        add_headway_constraints()
        add_assignment_constraints()
        add_override_constraints()
        
        # Phase 5: Solve with CBC
        solver = pulp.PULP_CBC_CMD(timeLimit=settings.time_limit_seconds)
        return extract_optimal_solution()
```

**Mathematical Formulation**:

**Decision Variables**:
- `x[t,s,p,τ] ∈ {0,1}`: Binary assignment of train t to platform p at station s in time slot τ
- `d[t] ∈ ℝ⁺`: Continuous delay variable for train t

**Objective Function**:
```
minimize: α·Σ(d[t]) + β·Σ(conflict_penalties) + γ·Σ(throughput_penalties)

where:
α = delay_weight (default: 1.0)
β = conflict_weight (default: 10.0) 
γ = throughput_weight (default: 5.0)
```

**Constraint System**:
1. **Assignment Uniqueness**: `Σ(x[t,s,p,τ]) = 1 ∀t` (each train assigned exactly once)
2. **Platform Capacity**: `Σ(x[t,s,p,τ]) ≤ 1 ∀s,p,τ` (no platform conflicts)
3. **Minimum Headway**: `x[t1,s,p,τ] + x[t2,s,p,τ+1] ≤ 1` (5-minute safety buffer)
4. **Fixed Assignments**: `x[t,s,p,τ] = 0` if p ≠ fixed_platform[t] (controller overrides)
5. **Delay Calculation**: `d[t] ≥ (τ - scheduled_slot[t]) × slot_duration × x[t,s,p,τ]`

**Algorithm Performance**:
- **Solver**: CBC (Coin-or Branch and Cut)
- **Time Complexity**: NP-hard, bounded by time limit (default: 30s)
- **Optimality**: Guaranteed optimal solution within time limit
- **Scalability**: Handles 50+ trains with 10+ platforms efficiently

**Throughput Optimization Features**:
- **Multi-objective optimization**: Balances delays, conflicts, and throughput
- **Resource utilization**: Maximizes platform and track usage efficiency
- **Temporal optimization**: Optimal time slot allocation for maximum capacity
- **Constraint satisfaction**: Ensures all safety and operational requirements

### 3. Advanced Conflict Detection & Resolution Engine

**Location**: `backend/conflict_detector.py`

Multi-algorithm conflict detection system with predictive analysis and automated resolution:

```python
class ConflictDetector:
    def detect_conflicts(self, schedule):
        # Phase 1: Temporal conflict analysis
        platform_conflicts = self._detect_platform_overlaps(entries)
        
        # Phase 2: Safety constraint validation
        headway_conflicts = self._detect_headway_violations(entries)
        
        # Phase 3: Priority optimization analysis
        priority_conflicts = self._detect_priority_conflicts(entries)
        
        # Phase 4: Severity assessment and impact analysis
        return self._assess_and_rank_conflicts(all_conflicts)
```

**Conflict Detection Algorithms**:

#### 3.1 Platform Overlap Detection
**Algorithm**: Interval overlap detection with O(n log n) complexity
```python
def detect_platform_overlaps(station_entries):
    # Sort by arrival time: O(n log n)
    # Sweep line algorithm for overlap detection: O(n)
    for current, next_train in consecutive_pairs:
        if current.departure > next_train.arrival:
            overlap_minutes = calculate_overlap(current, next_train)
            severity = assess_overlap_severity(overlap_minutes, train_priorities)
            conflicts.append(create_conflict(overlap_minutes, severity))
```

#### 3.2 Headway Violation Detection
**Algorithm**: Safety margin validation with configurable thresholds
```python
def detect_headway_violations(platform_entries):
    MIN_HEADWAY = 5  # minutes safety buffer
    for consecutive_trains in platform_entries:
        headway = next_arrival - current_departure
        if headway < MIN_HEADWAY:
            risk_level = calculate_safety_risk(headway, train_types)
            conflicts.append(create_headway_conflict(risk_level))
```

#### 3.3 Priority Conflict Detection
**Algorithm**: Priority inversion analysis with temporal proximity
```python
def detect_priority_conflicts(station_entries):
    for current, next_train in time_ordered_pairs:
        if (current.priority < next_train.priority and 
            time_difference < PRIORITY_WINDOW):
            efficiency_loss = calculate_throughput_impact(priority_inversion)
            conflicts.append(create_priority_conflict(efficiency_loss))
```

**Conflict Severity Assessment**:
- **Critical**: Platform overlap >10 min OR headway <2 min
- **High**: Platform overlap 5-10 min OR headway 2-3 min OR high-priority inversion
- **Medium**: Platform overlap 2-5 min OR headway 3-5 min OR medium-priority inversion
- **Low**: Minor timing issues with minimal operational impact

**Throughput Impact Analysis**:
```python
def analyze_conflict_impact(conflicts, schedule):
    return {
        "throughput_reduction": calculate_capacity_loss(conflicts),
        "delay_propagation": estimate_cascading_delays(conflicts),
        "resource_utilization": assess_platform_efficiency_loss(conflicts),
        "safety_score": calculate_safety_impact(conflicts),
        "resolution_complexity": estimate_resolution_effort(conflicts)
    }
```

### 4. AI-Powered Recommendations Engine

**Location**: `backend/recommendations.py`

Intelligent optimization system combining machine learning with operational research for throughput maximization:

```python
class RecommendationsEngine:
    def generate_recommendations(self, schedule, conflicts):
        # Phase 1: Conflict-driven recommendations
        conflict_recs = self._generate_conflict_resolutions(conflicts)
        
        # Phase 2: Throughput optimization recommendations  
        optimization_recs = self._generate_throughput_optimizations(schedule)
        
        # Phase 3: Proactive efficiency recommendations
        proactive_recs = self._generate_proactive_recommendations(schedule)
        
        # Phase 4: Multi-criteria scoring and ranking
        return self._score_and_rank_recommendations(all_recommendations)
```

**Recommendation Algorithms**:

#### 4.1 Conflict Resolution Recommendations
**Algorithm**: Multi-strategy conflict resolution with cost-benefit analysis
```python
def generate_conflict_resolutions(conflicts):
    for conflict in conflicts:
        strategies = []
        
        # Strategy 1: Platform reassignment
        alternative_platforms = find_available_platforms(conflict.time_window)
        for platform in alternative_platforms:
            cost = calculate_reassignment_cost(platform)
            benefit = calculate_conflict_resolution_benefit(platform)
            strategies.append(PlatformReassignment(platform, cost, benefit))
        
        # Strategy 2: Temporal adjustment
        delay_options = calculate_optimal_delays(conflict.trains)
        for delay in delay_options:
            cost = calculate_delay_cost(delay)
            benefit = calculate_throughput_preservation(delay)
            strategies.append(TemporalAdjustment(delay, cost, benefit))
        
        # Strategy 3: Priority reordering
        reorder_options = analyze_priority_swaps(conflict.trains)
        strategies.extend(reorder_options)
        
        return rank_strategies_by_efficiency(strategies)
```

#### 4.2 Throughput Optimization Recommendations
**Algorithm**: System-wide efficiency analysis with predictive modeling
```python
def generate_throughput_optimizations(schedule):
    # Analyze current throughput metrics
    current_metrics = {
        "trains_per_hour": calculate_throughput_rate(schedule),
        "platform_utilization": analyze_platform_efficiency(schedule),
        "average_dwell_time": calculate_dwell_times(schedule),
        "conflict_frequency": analyze_conflict_patterns(schedule)
    }
    
    # Identify optimization opportunities
    opportunities = []
    
    # Opportunity 1: Platform load balancing
    if detect_platform_imbalance(current_metrics):
        rebalancing = optimize_platform_distribution(schedule)
        opportunities.append(rebalancing)
    
    # Opportunity 2: Schedule compression
    if detect_schedule_gaps(current_metrics):
        compression = optimize_temporal_distribution(schedule)
        opportunities.append(compression)
    
    # Opportunity 3: Priority optimization
    if detect_priority_inefficiencies(current_metrics):
        priority_opts = optimize_priority_sequences(schedule)
        opportunities.extend(priority_opts)
    
    return rank_by_throughput_impact(opportunities)
```

### 5. Section Dispatch Optimization Engine (Google OR-Tools CP-SAT)

**Location**: `backend/cpsat_solver.py`

Railway Brain solves the section scheduling and disruption recovery problem by formulating it as a Constraint Programming with Satisfiability (CP-SAT) optimization problem. For the full mathematical specification, see [FORMULATION.md](./FORMULATION.md).

#### Core Optimization Objectives:
1. **Total Weighted Delay Minimization**: Minimizes priority-weighted arrival delays across all trains and stations:
   $$\min \sum_{i \in \mathcal{T}} w_i \cdot \max(0, \text{actual\_arrival}_i - \text{scheduled\_arrival}_i)$$
   where Express ($w=3.0$), Suburban ($w=2.0$), Passenger ($w=1.5$), and Freight ($w=1.0$).
2. **Hard Safety Non-Overlap**: Prevents opposing train deadlocks on single-track sections using native `NoOverlap` interval constraints.
3. **Kavach Headway Separation**: Enforces minimum safety headway buffers (180s standard / 300s Kavach) between same-direction trains on double track.
4. **Maintenance Interval Exclusion**: Enforces maintenance blocks as hard, non-relaxable intervals.

#### 5.1 Counterfactual Explanation Engine
**Location**: `backend/counterfactual.py`

Every recommendation is paired with an exact arithmetic counterfactual calculation comparing the solver's proposed plan against the baseline continuation:
- **Downstream Benefit**: Explicitly lists trains benefiting from the hold/precedence decision and the exact weighted minutes saved.
- **Rejection Impact**: Quantifies the additional cascade delay if the controller rejects the recommendation.
- **Zero Hallucination**: No generative LLM is used in the decision path; all numbers are calculated directly from simulation state.

## Data Models

### Core Models (`backend/models.py`)

#### Train Model
```python
class Train(BaseModel):
    id: str                    # Unique identifier (T101, T102, etc.)
    type: str                  # Express, Local, Intercity, Freight
    priority: int              # 1-10 (higher = more priority)
    origin: str                # Origin station (HYB, SC, KCG)
    destination: str           # Destination station
    scheduled_arrival: datetime
    scheduled_departure: datetime
    platform_pref: Optional[int] = None
```

#### Station Model
```python
class Station(BaseModel):
    id: str                    # Station code (HYB, SC, KCG)
    platforms: int             # Number of available platforms
```

#### ScheduleEntry Model
```python
class ScheduleEntry(BaseModel):
    train_id: str
    station_id: str
    assigned_platform: int
    actual_arrival: datetime
    actual_departure: datetime
    reason: str                # Explanation for assignment
```

#### Conflict Model
```python
class Conflict(BaseModel):
    id: str
    type: Literal["platform_overlap", "headway_violation", "priority_conflict"]
    station_id: str
    platform: Optional[int]
    trains_involved: List[str]
    root_cause: str
    severity: Literal["low", "medium", "high", "critical"]
    suggested_actions: List[str]
```

### Dataset Structure

**Location**: `backend/data/prototype_trains.json`

The system uses a realistic Hyderabad railway network dataset:

**Stations**:
- **HYB** (Hyderabad Deccan): 3 platforms
- **SC** (Secunderabad Junction): 4 platforms  
- **KCG** (Kacheguda): 2 platforms

**Train Types**:
- **Express**: High priority (8-9), long-distance
- **Local**: Medium priority (5-6), short-distance
- **Passenger**: Medium priority (4-6), regular service
- **Freight**: Low priority (2-3), cargo transport

## API Endpoints

### Core Operations
```
GET  /health                    # In-memory single-process service health
GET  /stations                  # Get corridor stations & topologies
GET  /trains                    # Get all monitored trains
GET  /schedule                  # Get current conflict-free schedule
POST /schedule/recompute        # Trigger CP-SAT re-plan with rolling horizon
POST /override                  # Apply controller manual platform/time override
POST /feasibility              # Verify proposed action against safety rules
GET  /conflicts                # Get active safety and headway conflicts
GET  /recommendations          # Get counterfactual numeric recommendations
POST /apply-recommendation     # Accept and commit specific recommendation
POST /recommendations/reject   # Reject recommendation and record controller reason
GET  /log                       # Get append-only audit trail
```

### Disruption & Maintenance Operations
```
POST /disruptions/inject       # Unified disruption injector (late train, loco, signal, TSR)
POST /disruptions/clear        # Clear active disruption orders
POST /maintenance/plan         # Evaluate maintenance placement slot & cost curve
POST /whatif/evaluate          # Evaluate hypothetical scenario in sandbox
POST /whatif/commit            # Promote sandbox scenario to live schedule
```

### Benchmarks & Stretch Deliverables
```
GET  /benchmark/results        # 24-hr comparative benchmark: FCFS vs Priority vs CP-SAT
GET  /stretch/forecast         # Arrival-time forecasting model MAE & predictions
GET  /stretch/override-learning# Controller override history & learned class weights
```

### Real-time Telemetry
```
WebSocket /ws                  # Real-time WebSocket event & position push stream
GET  /train-positions         # Current train corridor mileposts & track circuits
GET  /track-status           # Track circuit occupancy telemetry
```

## Frontend Components

### Frontend Architecture (Phase 3A)

**Layout primitives** (`rail-frontend/src/components/layout/`):
- `PageHeader`, `SectionCard`, `EmptyState`, `Tabs`, `ContextStrip`, `SkipLink`, `LiveRegion`
- Shared copy in `lib/productCopy.ts`; audit formatting in `lib/auditFormat.ts`

**Operations command center** (`rail-frontend/src/components/operations/`):
- **Zone A**: `NetworkMap` (8 cols) + `StatusBoard`, `AlertsPanel`, `OperationsPanel` (4 cols)
- **Zone B**: Tabbed `ScheduleTable` | `ScheduleTimelinePanel` (Gantt) | `ActivityPanel`
- **Command Center**: `CommandCenterView` fullscreen overlay (`F` / toolbar); `useCommandCenter` hook
- Modals: `OverrideModal`, `DelayWarningModal`; diagnostics moved to `SimulationDiagnostics`

**Accessibility**: See `rail-frontend/ACCESSIBILITY.md` (keyboard shortcuts, `aria-live`, reduced motion).

### Phase 3B / 3C — Unified feed & OCC polish

**Shared data layer** (`rail-frontend/src/context/`):
- `OperationsFeedContext` — single 5s poll + WebSocket for trains, schedule, conflicts, track status, positions
- `SelectionContext` — selected train/entry for drawer and map click-through

**Operations upgrades (Phase 3B–3C)**:
- `TrainGraph` — occupation / corridor / compare modes; live WS head markers on active legs (Phase 3C)
- `PlatformBoard`, `AlertQueue`, `TrackOccupancyPanel` — operations rail widgets
- `ScheduleTable` — conflict badge via `conflictTrainIds` from feed; row click opens drawer (Phase 3C)
- `NetworkMap` — track link coloring from `/track-status`; train dot click → selection drawer (Phase 3C)
- `GET /schedule` read-only; `POST /schedule/recompute` for mutations

**Simulation dashboard (Phase 3B–3C)**:
- Consumes `useOperationsFeed()` for live baseline schedule (no duplicate fetch)
- Side-by-side scenario KPI compare + dual `TrainGraph` when a compare scenario is selected
- Schedule diff table highlights rows where platform/time differs from live baseline
- Promote-to-live via `/apply-recommendation` with confirmation dialog

**Analytics dashboard (Phase 3B–3C)**:
- Live ops feed hints (conflicts, active delays) from unified feed
- KPI trends line chart from `GET /analytics/trends` (5-minute buckets, deduped server-side)
- Station delay heatmap across recent trend buckets
- Empty state when no trend data: “Refresh analytics to start recording trends”

**Backend reliability (Phase 3C)**:
- Greedy optimizer force-assigns legs at `MAX_DELAY` instead of dropping trains
- `analytics_trends.py` buckets snapshots to 5-minute intervals
- Expanded pytest: override, feasibility, simulation; CI uses `requirements-dev.txt` (no optional Gemini dep)

### Real-Time Dispatch State & WebSocket Streaming

Railway Brain runs a single-process FastAPI application with an in-memory schedule state. Schedule mutations trigger broadcast notifications via native WebSocket connections, updating all connected controller screens with sub-second latency without the overhead of external message brokers.

### 1. Multi-Dashboard Architecture

**Location**: `rail-frontend/src/AppWithDashboards.tsx`

Main wrapper component providing navigation between dashboards:

```typescript
type DashboardView = 'main' | 'simulation' | 'analytics';

const AppWithDashboards: React.FC = () => {
  const [currentView, setCurrentView] = useState<DashboardView>('main');
  // Navigation, conflict indicators, recommendations panel
};
```

### 2. Operations Dashboard (Command Center)

**Location**: `rail-frontend/src/App.tsx`

Railway operations console:
- **Context strip** — product explanation (dismissible)
- **Map + status rail** — network map, KPI status board, alerts, override/clear delays
- **Workspace tabs** — Schedule, Timeline, Activity audit log
- **Command Center mode** — wall-display fullscreen via `CommandCenterView`

### 3. Simulation Dashboard

**Location**: `rail-frontend/src/components/SimulationDashboard.tsx`

Scenario testing interface (Phase 3C depth):
- **Unified feed baseline** — live schedule from `OperationsFeedContext`
- **Delay / breakdown / weather / priority** simulations via `POST /simulate/*`
- **Side-by-side compare** — KPI cards and dual `TrainGraph` for two stored scenarios
- **Diff-highlighted schedule table** — changed platform/time rows vs live baseline
- **Promote to live** — applies top recommendation with confirm dialog

### 4. Analytics Dashboard

**Location**: `rail-frontend/src/components/AnalyticsDashboard.tsx`

Performance monitoring and insights (Phase 3C depth):
- **System KPIs** with live conflict/delay hints from operations feed
- **KPI trends** — 5-minute bucketed snapshots from `/analytics/trends`
- **Station delay heatmap** — per-station delay intensity over recent buckets
- **Delay analysis** by station and train type; platform utilization; conflict breakdown

### 5. AI ChatBot

**Location**: `rail-frontend/src/components/ChatBot.tsx`

Conversational AI interface:
- **Real-time Assistance**: Context-aware responses
- **Auto-explanations**: Automatic explanations for system actions
- **Schedule Analysis**: AI-powered insights and recommendations

## AI Integration

### Google Gemini AI Integration

**Model**: Gemini 2.5 Flash
**Configuration**: Environment variable `GEMINI_API_KEY`

#### Backend AI Endpoints

```python
@app.post("/ai/analyze-schedule")
async def analyze_schedule_with_ai(query: str):
    # Prepare schedule data for AI analysis
    # Generate contextual prompt
    # Call Gemini API
    # Return AI insights
```

#### Frontend ChatBot Integration

```typescript
const handleSend = async () => {
  // Fetch current system data
  // Prepare contextual prompt with live data
  // Call Gemini API with system context
  // Display AI response
};
```

#### AI Use Cases

1. **Schedule Analysis**: "Analyze current conflicts and suggest optimizations"
2. **Operational Insights**: "Explain why train T101 was delayed"
3. **Predictive Analysis**: "What will happen if we delay train T102?"
4. **Decision Support**: "Should I approve this platform override?"

## Deployment

### Production Deployment

#### Frontend (Vercel)
- **URL**: https://trainvision.vercel.app/
- **Build**: Vite + React + TypeScript
- **CDN**: Global edge network
- **Auto-deployment**: On git push to main

#### Backend (Render)
- **URL**: https://trainvision-ai.onrender.com/
- **Runtime**: Python 3.11 + FastAPI + Gunicorn
- **Container**: Docker with optimized build
- **Health checks**: `/health` and `/ai/status` endpoints

### Environment Configuration

#### Backend Environment Variables
```bash
GEMINI_API_KEY=your_gemini_api_key
GEMINI_MODEL=gemini-2.5-flash
FRONTEND_URL=https://trainvision.vercel.app
BACKEND_URL=https://trainvision-ai.onrender.com
```

#### Frontend Environment Variables
```bash
VITE_API_BASE_URL=https://trainvision-ai.onrender.com
VITE_APP_TITLE=TrainVision AI
VITE_APP_VERSION=1.0.0
```

### Docker Configuration

#### Backend Dockerfile
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 8000
CMD ["python", "main_lite.py"]
```

#### Frontend Dockerfile
```dockerfile
FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=builder /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/nginx.conf
EXPOSE 80
```

## Use Cases

### 1. Real-time Operations Management

**Scenario**: Railway control center managing daily operations

**Workflow**:
1. Monitor live train positions on network map
2. Detect conflicts automatically via conflict detection engine
3. Receive AI recommendations for resolution
4. Apply manual overrides when necessary
5. Track performance via analytics dashboard

### 2. Delay Management

**Scenario**: Train T101 experiences 15-minute delay

**System Response**:
1. Delay injection via `/inject-delay` endpoint
2. Automatic re-optimization of affected trains
3. Conflict detection for cascading impacts
4. AI recommendations for mitigation
5. Real-time updates to all connected clients

### 3. Scenario Planning

**Scenario**: Testing impact of weather delays

**Workflow**:
1. Access Simulation Dashboard
2. Configure weather scenario parameters
3. Run simulation to predict impacts
4. Review KPI changes and recommendations
5. Apply preventive measures if needed

### 4. Performance Analysis

**Scenario**: Monthly performance review

**Process**:
1. Access Analytics Dashboard
2. Review on-time performance metrics
3. Analyze delay patterns by station/train type
4. Identify optimization opportunities
5. Adjust operational parameters

## Development Guide

### Local Development Setup

#### Prerequisites
- Python 3.11+
- Node.js 18+
- Docker (optional)

#### Backend Setup
```bash
cd backend
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your Gemini API key
python main.py
```

#### Frontend Setup
```bash
cd rail-frontend
npm install
npm run dev
```

### Project Structure
```
TrainVision-AI/
├── backend/
│   ├── main.py                 # Main FastAPI application
│   ├── main_lite.py           # Lightweight deployment version
│   ├── models.py              # Pydantic data models
│   ├── optimizer.py           # Greedy optimization algorithm
│   ├── ilp_optimizer.py       # ILP optimization engine
│   ├── conflict_detector.py   # Conflict detection system
│   ├── recommendations.py     # AI recommendations engine
│   ├── data/
│   │   └── prototype_trains.json  # Dataset
│   └── requirements.txt       # Python dependencies
├── rail-frontend/
│   ├── src/
│   │   ├── AppWithDashboards.tsx  # Multi-dashboard wrapper
│   │   ├── App.tsx               # Main dashboard
│   │   ├── config.ts             # Configuration
│   │   └── components/
│   │       ├── SimulationDashboard.tsx
│   │       ├── AnalyticsDashboard.tsx
│   │       └── ChatBot.tsx
│   └── package.json           # Node.js dependencies
├── docker-compose.yml         # Docker development setup
├── render.yaml               # Render deployment config
└── README.md                 # Project documentation
```

### Key Development Patterns

#### Adding New Optimization Algorithms
1. Create new optimizer in `backend/` directory
2. Implement interface matching `greedy_optimizer` signature
3. Add algorithm selection in `OptimizerSettings`
4. Update `/settings/optimizer` endpoint

#### Adding New Conflict Types
1. Extend `Conflict` model in `models.py`
2. Add detection logic in `conflict_detector.py`
3. Update severity assessment rules
4. Add resolution recommendations

#### Adding New AI Features
1. Create new endpoint in `main.py`
2. Implement Gemini API integration
3. Add frontend interface components
4. Update ChatBot context handling

### Testing Strategy

#### Backend Testing
```bash
# Unit tests for algorithms
pytest backend/tests/

# API endpoint testing
curl http://localhost:8000/trains
curl http://localhost:8000/schedule
```

#### Frontend Testing
```bash
# Component testing
npm run test

# E2E testing
npm run e2e
```

### Performance Optimization

#### Backend Architecture
- **In-Memory State**: Single-worker FastAPI process maintaining a synchronized schedule state without distributed race conditions.
- **OR-Tools CP-SAT**: High-performance mathematical optimization core solving within 3.5s.
- **WebSocket Streaming**: Instant push delivery of solver re-plans and train positions directly to OCC clients.

#### Frontend Architecture
- **Code Splitting**: Route-based lazy loading for heavy dashboards.
- **Memoization**: React.memo and useMemo for real-time Marey stringline calculations.
- **Pure CSS Layout**: Ergonomic dark palette reducing ocular fatigue during extended shifts.

---

**Railway Brain (PS-09)** — Disruption-Resilient Train Control Decision Support
**Version**: 1.0.0
**Last Updated**: October 2025