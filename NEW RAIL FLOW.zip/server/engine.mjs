// RailFlow simulation engine — delay propagation, status, conflicts and recovery plans.
// All outputs are advisory simulation estimates for a synthetic corridor model.

import { BLOCKS, CORRIDOR, blockById, stationName } from "./seed.mjs";

export const SIM_SPEED = 20; // simulated seconds per real second

const STATION_KM = Object.fromEntries(CORRIDOR.stations.map((s) => [s.code, s.km]));

export function clockMinutes(state) {
  const elapsedSec = (Date.now() - state.startedAt) / 1000;
  const advanced = (elapsedSec * state.speed) / 60;
  return Math.min(1439, state.clockStartMin + advanced);
}

export function fmtClock(min) {
  const total = Math.round(min);
  const h = Math.floor(((total % 1440) + 1440) % 1440 / 60);
  const m = Math.floor(((total % 60) + 60) % 60);
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

function blockIndex(train, block) {
  for (let i = 0; i < train.stops.length - 1; i += 1) {
    const a = train.stops[i].code;
    const b = train.stops[i + 1].code;
    if ((a === block.from && b === block.to) || (a === block.to && b === block.from)) return i;
  }
  return -1;
}

function blockRuntime(train, block) {
  const i = blockIndex(train, block);
  if (i < 0) return 0;
  return train.stops[i + 1].arr - train.stops[i].dep;
}

function addEffect(map, trainNo, minutes, fromIndex, reason, disruptionId) {
  if (minutes <= 0) return;
  const list = map.get(trainNo) ?? [];
  list.push({ minutes: Math.round(minutes), fromIndex, reason, disruptionId });
  map.set(trainNo, list);
}

/** Waits caused by active disruptions, per train, expressed as extra minutes from a stop index. */
function buildEffects(disruptions, trains, now, holds = {}) {
  const map = new Map();

  for (const d of disruptions) {
    if (d.kind === "late_train") {
      addEffect(
        map,
        d.trainNo,
        d.durationMin,
        0,
        `${d.reason} — entering late at ${stationName(trains.find((t) => t.no === d.trainNo)?.origin ?? "SC")}`,
        d.id,
      );
      continue;
    }

    if (d.kind === "platform_block") {
      for (const t of trains) {
        const idx = t.stops.findIndex((s) => s.code === d.stationCode);
        if (idx < 0) continue;
        const arrive = t.stops[idx].arr;
        if (arrive < now - 5 || arrive > d.endMin) continue;
        addEffect(
          map,
          t.no,
          Math.min(d.durationMin, 18),
          idx,
          `${d.reason} at ${stationName(d.stationCode)} — platform occupancy`,
          d.id,
        );
      }
      continue;
    }

    const block = blockById(d.blockId);
    if (!block) continue;
    const headway = block.track === "single" ? 4 : 2;
    const queue = [];

    // A train already given a planned hold carries that hold instead of the automatic queue
    // delay, so applying a recovery plan never adds two delays for the same disruption.
    const planned = new Set(
      Object.entries(holds)
        .filter(([, list]) => list.some((h) => h.disruptionId === d.id && !h.cleared))
        .map(([no]) => no),
    );

    for (const t of trains) {
      const i = blockIndex(t, block);
      if (i < 0) continue;
      if (planned.has(t.no)) continue;
      const pass = t.stops[i].dep;
      const run = blockRuntime(t, block);
      if (pass + run < now - 1) continue; // already cleared the block
      if (pass > d.endMin + 45) continue; // far behind, not yet queued
      let wait;
      if (d.kind === "speed_restriction" || d.kind === "signal_failure") {
        if (pass > d.endMin && pass - run > d.endMin) continue;
        wait = Math.ceil(run * 0.6);
      } else {
        wait = Math.max(0, d.endMin - Math.max(pass, now));
      }
      queue.push({ train: t, index: i, pass, wait });
    }

    queue.sort((a, b) => a.pass - b.pass);
    const ahead = { UP: 0, DOWN: 0 };
    for (const item of queue) {
      const penalty = ahead[item.train.dir] * headway;
      ahead[item.train.dir] += 1;
      const minutes = Math.ceil(item.wait + penalty);
      const label =
        d.kind === "block_closure"
          ? `${block.id} blocked until ${fmtClock(d.endMin)}`
          : d.kind === "loco_failure"
            ? `${d.trainNo} stalled at ${block.id}`
            : d.kind === "speed_restriction"
              ? `${block.id} speed restriction`
              : `Signal failure at ${block.id}`;
      addEffect(map, item.train.no, minutes, item.index, label, d.id);
    }
  }
  return map;
}

function statusFor({ train, now, actual, delay, activeHold }) {
  if (train.cancelled) return "cancelled";
  const firstDep = actual[0].dep;
  const lastArr = actual[actual.length - 1].arr;
  if (now < firstDep) return "upcoming";
  if (now >= lastArr) return "arrived";
  if (activeHold) return "held";
  if (delay >= 6) return "delayed";
  return "running";
}

export const STATUS_LABEL = {
  upcoming: "Scheduled",
  arrived: "Completed",
  held: "Held",
  delayed: "Delayed",
  running: "On time",
  cancelled: "Cancelled",
};

export function buildSnapshot(state) {
  const now = clockMinutes(state);
  const disruptions = state.disruptions.filter((d) => d.status === "active");
  const effects = buildEffects(disruptions, state.trains, now, state.holds);

  const trains = state.trains.map((train) => {
    const trainEffects = effects.get(train.no) ?? [];
    const holds = (state.holds[train.no] ?? []).filter((h) => !h.cleared);
    const stopIndex = (code) => train.stops.findIndex((s) => s.code === code);

    const delayAt = (i) => {
      let minutes = 0;
      for (const e of trainEffects) if (e.fromIndex <= i) minutes += e.minutes;
      for (const h of holds) {
        const hi = stopIndex(h.station);
        if (hi >= 0 && hi <= i) minutes += h.minutes;
      }
      return Math.round(minutes);
    };

    const actual = train.stops.map((s, i) => {
      const shift = delayAt(i);
      return {
        code: s.code,
        name: stationName(s.code),
        schedArr: s.arr,
        schedDep: s.dep,
        arr: s.arr + shift,
        dep: s.dep + shift,
        platform: s.platform,
        shift,
      };
    });

    let inBlock = -1;
    let atStation = 0;
    let progress = 0;
    if (now < actual[0].dep) {
      atStation = 0;
      progress = 0;
    } else if (now >= actual[actual.length - 1].arr) {
      atStation = actual.length - 1;
      progress = 0;
    } else {
      for (let i = 0; i < actual.length - 1; i += 1) {
        if (now >= actual[i].dep && now < actual[i + 1].arr) {
          inBlock = i;
          progress = (now - actual[i].dep) / Math.max(1, actual[i + 1].arr - actual[i].dep);
          break;
        }
        if (now >= actual[i + 1].arr && now <= actual[i + 1].dep) {
          atStation = i + 1;
          progress = 0;
          break;
        }
      }
    }

    let km;
    if (inBlock >= 0) {
      const a = STATION_KM[actual[inBlock].code];
      const b = STATION_KM[actual[inBlock + 1].code];
      km = a + (b - a) * progress;
    } else {
      km = STATION_KM[actual[atStation].code] ?? 0;
    }

    const activeHold = holds.find((h) => h.untilMin > now && stopIndex(h.station) === atStation && now >= (actual[atStation]?.arr ?? 0));
    const currentIndex = inBlock >= 0 ? inBlock : atStation;
    const currentDelay = delayAt(currentIndex);
    // The board reports the delay the service will carry out of the section.
    const delay = delayAt(actual.length - 1);
    const status = statusFor({ train, now, actual, delay: Math.max(currentDelay, delay), activeHold });
    const nextStop = actual.find((s) => s.dep >= now) ?? actual[actual.length - 1];

    return {
      no: train.no,
      name: train.name,
      cls: train.cls,
      weight: train.weight,
      dir: train.dir,
      status,
      statusLabel: STATUS_LABEL[status],
      delay,
      currentDelay,
      primaryDelay: trainEffects.length ? trainEffects.reduce((a, e) => a + e.minutes, 0) : 0,
      reasons: [...new Set(trainEffects.map((e) => e.reason))],
      disruptionIds: [...new Set(trainEffects.map((e) => e.disruptionId))],
      origin: train.origin,
      destination: train.destination,
      originName: stationName(train.origin),
      destinationName: stationName(train.destination),
      schedDep: train.schedDep,
      schedArr: train.schedArr,
      eta: nextStop.arr,
      nextCode: nextStop.code,
      nextName: stationName(nextStop.code),
      km,
      progress: Number(progress.toFixed(3)),
      inBlock: inBlock >= 0 ? `${actual[inBlock].code}–${actual[inBlock + 1].code}` : null,
      platform: actual[Math.min(atStation, actual.length - 1)].platform,
      hold: activeHold
        ? { station: activeHold.station, untilMin: activeHold.untilMin, minutes: activeHold.minutes, reason: activeHold.reason }
        : null,
      stops: actual.map((s) => ({ ...s, passed: now >= s.dep })),
    };
  });

  const disruptionsView = disruptions.map((d) => {
    const affected = trains.filter((t) => t.disruptionIds.includes(d.id));
    const block = d.blockId ? blockById(d.blockId) : null;
    return {
      ...d,
      blockTrack: block?.track ?? null,
      fromName: block ? stationName(block.from) : null,
      toName: block ? stationName(block.to) : null,
      stationName: d.stationCode ? stationName(d.stationCode) : null,
      affectedTrains: affected.map((t) => t.no),
      affectedDelay: affected.reduce((a, t) => a + t.delay, 0),
      minutesLeft: Math.max(0, Math.round(d.endMin - now)),
    };
  });

  const active = trains.filter((t) => t.status !== "arrived" && t.status !== "cancelled");
  const delayed = active.filter((t) => t.delay >= 6);
  const held = active.filter((t) => t.status === "held");
  const weighted = active.reduce((a, t) => a + t.delay * t.weight, 0);
  const avgDelay = active.length ? active.reduce((a, t) => a + t.delay, 0) / active.length : 0;
  const onTimePct = active.length ? ((active.length - delayed.length - held.length) / active.length) * 100 : 100;

  return {
    now,
    clock: fmtClock(now),
    trains,
    disruptions: disruptionsView,
    stats: {
      active: active.length,
      delayed: delayed.length,
      held: held.length,
      upcoming: trains.filter((t) => t.status === "upcoming").length,
      completed: trains.filter((t) => t.status === "arrived").length,
      avgDelay: Number(avgDelay.toFixed(1)),
      weightedDelay: Math.round(weighted),
      onTimePct: Number(Math.max(0, Math.min(100, onTimePct)).toFixed(0)),
      activeDisruptions: disruptionsView.length,
      affectedTrains: new Set(disruptionsView.flatMap((d) => d.affectedTrains)).size,
    },
    conflicts: detectConflicts(trains, now),
  };
}

function detectConflicts(trains, now) {
  const conflicts = [];
  for (const block of BLOCKS) {
    const occupancy = [];
    for (const t of trains) {
      if (t.status === "arrived" || t.status === "cancelled") continue;
      const i = blockIndex(t, block);
      if (i < 0) continue;
      const entry = t.stops[i].dep;
      const exit = t.stops[i + 1].arr;
      if (exit < now || entry > now + 300) continue;
      occupancy.push({ no: t.no, name: t.name, entry, exit, weight: t.weight, dir: t.dir });
    }
    // Double track carries one direction per line, so only same-direction paths compete.
    const groups =
      block.track === "single" ? [occupancy] : [occupancy.filter((o) => o.dir === "UP"), occupancy.filter((o) => o.dir === "DOWN")];
    for (const group of groups) {
      group.sort((a, b) => a.entry - b.entry);
      for (let k = 1; k < group.length; k += 1) {
        const prev = group[k - 1];
        const cur = group[k];
        const gap = cur.entry - prev.exit;
        const minimum = 0;
        if (gap >= minimum) continue;
        conflicts.push({
          id: `${block.id}-${prev.no}-${cur.no}`,
          blockId: block.id,
          blockLabel: `${stationName(block.from)} – ${stationName(block.to)}`,
          track: block.track,
          trains: [prev.no, cur.no],
          gap: Math.round(gap),
          at: fmtClock(cur.entry),
          severity: gap < 0 ? "high" : "medium",
          kind: gap < 0 ? "Occupancy overlap" : "Headway margin",
        });
      }
    }
  }
  return conflicts.slice(0, 12);
}

/** Priority-ordered recovery plan for a block disruption. */
export function buildRecoveryPlan(state, snapshot, disruptionId) {
  const d = snapshot.disruptions.find((x) => x.id === disruptionId);
  if (!d || !d.blockId) return null;
  const block = blockById(d.blockId);
  if (!block) return null;
  const headway = block.track === "single" ? 4 : 2;
  const startSlot = Math.max(d.endMin, snapshot.now);

  const pool = snapshot.trains
    .filter((t) => t.status !== "arrived" && t.status !== "cancelled")
    .map((t) => {
      const i = blockIndex(t, block);
      if (i < 0) return null;
      const pass = t.stops[i].schedDep;
      if (pass < snapshot.now - 2) return null;
      if (pass > d.endMin + 60) return null;
      return {
        trainNo: t.no,
        name: t.name,
        cls: t.cls,
        weight: t.weight,
        station: t.stops[i].code,
        stationName: t.stops[i].name,
        pass,
      };
    })
    .filter(Boolean);

  if (!pool.length) {
    return {
      disruptionId,
      blockId: d.blockId,
      headway,
      items: [],
      savings: 0,
      baselineCost: 0,
      planCost: 0,
      note: "No trains are queued for this block in the planning window.",
    };
  }

  const cost = (order) =>
    order.reduce((acc, item, k) => {
      const slot = startSlot + k * headway;
      return acc + item.weight * Math.max(0, slot - item.pass);
    }, 0);

  const baseline = [...pool].sort((a, b) => a.pass - b.pass);
  const planned = [...pool].sort((a, b) => b.weight - a.weight || a.pass - b.pass);

  const baselineCost = Math.round(cost(baseline));
  const planCost = Math.round(cost(planned));
  // Only reorder when priority-first is genuinely cheaper; otherwise keep first-come order.
  const chosen = planCost <= baselineCost ? planned : baseline;

  return {
    disruptionId,
    blockId: d.blockId,
    headway,
    baselineCost,
    planCost,
    savings: Math.max(0, baselineCost - Math.min(baselineCost, planCost)),
    items: chosen.map((item, k) => ({
      trainNo: item.trainNo,
      name: item.name,
      cls: item.cls,
      weight: item.weight,
      station: item.station,
      stationName: item.stationName,
      holdMin: Math.max(0, Math.round(startSlot + k * headway - item.pass)),
      slot: fmtClock(startSlot + k * headway),
      order: k + 1,
    })),
    note: `${headway}-minute ${block.track}-line headway applied after the block reopens at ${fmtClock(d.endMin)}. Weighted-delay figures are model estimates.`,
  };
}
