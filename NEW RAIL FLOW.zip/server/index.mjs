// RailFlow API — zero-dependency Node HTTP service for the section-control simulation.

import { createServer } from "node:http";
import { readFile, writeFile, mkdir, stat } from "node:fs/promises";
import { existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import { BLOCKS, CLASSES, CORRIDOR, buildTrains, stationName } from "./seed.mjs";
import { SIM_SPEED, buildRecoveryPlan, buildSnapshot, clockMinutes, fmtClock } from "./engine.mjs";
import {
  clearKey,
  setKey,
  stationBoard,
  status as railradarStatus,
  wiring as railradarWiring,
} from "./railradar.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const DATA_DIR = path.join(ROOT, "data");
const STATE_FILE = path.join(DATA_DIR, "railflow-state.json");
const DIST_DIR = path.join(ROOT, "dist");
const PORT = Number(process.env.API_PORT ?? 8787);
const STATE_VERSION = 4;

const DEFAULT_CLOCK = 450; // 07:30

// The section opens mid-incident: an engineering block is already running on the single
// line between Bolarum and Medchal, and the queue behind it is visible on the board.
function freshState() {
  const base = DEFAULT_CLOCK;
  return {
    version: STATE_VERSION,
    clockStartMin: base,
    startedAt: Date.now(),
    speed: SIM_SPEED,
    disruptions: [
      {
        id: "DSP-001",
        kind: "block_closure",
        label: "Block closure · BMO-MED",
        blockId: "BMO-MED",
        stationCode: null,
        trainNo: null,
        trainName: null,
        durationMin: 55,
        reason: "Engineering block — track renewal in progress between Bolarum and Medchal",
        severity: "high",
        status: "active",
        createdAt: fmtClock(base - 18),
        startMin: base - 18,
        endMin: base + 37,
        createdBy: "Section Controller",
      },
    ],
    holds: {
      "47202": [
        {
          id: "HLD-001",
          station: "MED",
          minutes: 16,
          startMin: base - 4,
          untilMin: base + 26,
          reason: "Queue behind BMO-MED engineering block",
          disruptionId: "DSP-001",
          createdBy: "Section Controller",
        },
      ],
    },
    instructions: [
      {
        id: "INS-001",
        trainNo: "47202",
        trainName: "MMTS Local",
        station: "MED",
        stationName: stationName("MED"),
        action: "HOLD",
        minutes: 16,
        reason: "Queue behind BMO-MED engineering block",
        createdAt: fmtClock(base - 4),
        clock: base - 4,
        status: "PENDING",
        createdBy: "Section Controller",
        disruptionId: "DSP-001",
      },
    ],
    log: [
      {
        id: "LOG-004",
        at: fmtClock(base - 4),
        clock: base - 4,
        kind: "hold",
        actor: "Section Controller",
        text: "47202 MMTS Local held at Medchal for 16 min behind the BMO-MED engineering block.",
      },
      {
        id: "LOG-003",
        at: fmtClock(base - 8),
        clock: base - 8,
        kind: "plan",
        actor: "Section Controller",
        text: "Recovery plan accepted for BMO-MED: single-line queue ordered by priority, instruction INS-001 issued to Medchal.",
      },
      {
        id: "LOG-002",
        at: fmtClock(base - 18),
        clock: base - 18,
        kind: "disruption",
        actor: "Section Controller",
        text: "Block closure · BMO-MED reported for 55 min — track renewal in progress between Bolarum and Medchal.",
      },
      {
        id: "LOG-001",
        at: fmtClock(base - 30),
        clock: base - 30,
        kind: "system",
        actor: "System",
        text: "Control session opened. Corridor SC–WDR loaded from the synthetic timetable model.",
      },
    ],
    seq: 12,
  };
}

let state = freshState();
let trains = buildTrains();

async function loadState() {
  try {
    const raw = JSON.parse(await readFile(STATE_FILE, "utf8"));
    if (raw?.version === STATE_VERSION) {
      state = { ...freshState(), ...raw };
    }
  } catch {
    /* first run — keep the fresh state */
  }
  trains = buildTrains();
}

async function saveState() {
  await mkdir(DATA_DIR, { recursive: true });
  await writeFile(STATE_FILE, JSON.stringify(state, null, 2), "utf8");
}

function nextId(prefix) {
  state.seq += 1;
  return `${prefix}-${String(state.seq).padStart(3, "0")}`;
}

function addLog(kind, actor, text, clockMin) {
  const at = clockMin ?? clockMinutes(state);
  state.log.unshift({ id: nextId("LOG"), at: fmtClock(at), clock: at, kind, actor, text });
  state.log = state.log.slice(0, 200);
}

function prune() {
  const now = clockMinutes(state);
  for (const d of state.disruptions) {
    if (d.status === "active" && d.endMin + 60 < now) {
      d.status = "expired";
      addLog("disruption", "System", `${d.label} auto-closed after its window elapsed.`);
    }
  }
}

function snapshotPayload() {
  prune();
  const snap = buildSnapshot({ ...state, trains });
  return {
    ...snap,
    corridor: {
      ...CORRIDOR,
      blocks: BLOCKS,
      classes: CLASSES,
    },
    instructions: state.instructions.slice(0, 60),
    log: state.log.slice(0, 60),
    holds: state.holds,
    speed: state.speed,
  };
}

const KINDS = {
  block_closure: "Block closure",
  loco_failure: "Locomotive failure",
  signal_failure: "Signal failure",
  speed_restriction: "Speed restriction",
  platform_block: "Platform blockage",
  late_train: "Late running train",
};

function disruptionLabel(body) {
  if (body.kind === "late_train") {
    return `Late running ${body.trainNo}`;
  }
  if (body.kind === "platform_block") {
    return `${KINDS[body.kind]} · ${stationName(body.stationCode)}`;
  }
  return `${KINDS[body.kind]} · ${body.blockId}`;
}

function json(res, code, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(code, {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
  });
  res.end(body);
}

async function readBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  if (!chunks.length) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    return {};
  }
}

async function handleApi(req, res, url) {
  const parts = url.pathname.replace(/^\/api\/?/, "").split("/").filter(Boolean);
  const method = req.method ?? "GET";
  const now = clockMinutes(state);

  if (parts[0] === "health") return json(res, 200, { ok: true, clock: fmtClock(now) });

  if (parts[0] === "state" && method === "GET") return json(res, 200, snapshotPayload());

  if (parts[0] === "corridor" && method === "GET") {
    return json(res, 200, { corridor: CORRIDOR, blocks: BLOCKS, classes: CLASSES });
  }

  if (parts[0] === "disruptions" && method === "POST" && parts.length === 1) {
    const body = await readBody(req);
    if (!KINDS[body.kind]) return json(res, 400, { error: "Unknown disruption type" });
    const durationMin = Math.max(5, Math.min(240, Number(body.durationMin) || 30));
    const relevant = trains.find((t) => t.no === body.trainNo);
    const item = {
      id: nextId("DSP"),
      kind: body.kind,
      label: disruptionLabel(body),
      blockId: body.kind === "late_train" || body.kind === "platform_block" ? null : body.blockId,
      stationCode: body.kind === "platform_block" ? body.stationCode : null,
      trainNo: body.kind === "late_train" ? body.trainNo : null,
      trainName: relevant?.name ?? null,
      durationMin,
      reason: String(body.reason || KINDS[body.kind]).slice(0, 140),
      severity: body.severity === "low" || body.severity === "high" ? body.severity : "medium",
      status: "active",
      createdAt: fmtClock(now),
      startMin: now,
      endMin: now + durationMin,
      createdBy: "Section Controller",
    };
    state.disruptions.unshift(item);
    addLog("disruption", "Section Controller", `${item.label} reported for ${durationMin} min — ${item.reason}.`, now);
    await saveState();
    return json(res, 201, { state: snapshotPayload(), created: item });
  }

  if (parts[0] === "disruptions" && parts[2] === "resolve" && method === "POST") {
    const d = state.disruptions.find((x) => x.id === parts[1]);
    if (!d) return json(res, 404, { error: "Disruption not found" });
    d.status = "resolved";
    d.resolvedAt = fmtClock(now);
    addLog("disruption", "Section Controller", `${d.label} cleared. Corridor released.`, now);
    await saveState();
    return json(res, 200, { state: snapshotPayload() });
  }

  if (parts[0] === "replan" && parts[2] === "apply" && method === "POST") {
    const snap = buildSnapshot({ ...state, trains });
    const plan = buildRecoveryPlan(state, snap, parts[1]);
    if (!plan) return json(res, 404, { error: "No recovery plan available" });
    // Replace any earlier holds issued for this disruption.
    for (const [no, list] of Object.entries(state.holds)) {
      state.holds[no] = list.filter((h) => h.disruptionId !== plan.disruptionId);
    }
    for (const item of plan.items) {
      if (item.holdMin <= 0) continue;
      const list = state.holds[item.trainNo] ?? (state.holds[item.trainNo] = []);
      const already = list.some((h) => h.disruptionId === plan.disruptionId && h.station === item.station);
      if (already) continue;
      const holdId = nextId("HLD");
      list.push({
        id: holdId,
        station: item.station,
        minutes: item.holdMin,
        startMin: now,
        untilMin: now + item.holdMin,
        reason: `Recovery plan for ${plan.blockId}`,
        disruptionId: plan.disruptionId,
        createdBy: "Section Controller",
      });
      state.instructions.unshift({
        id: nextId("INS"),
        trainNo: item.trainNo,
        trainName: item.name,
        station: item.station,
        stationName: item.stationName,
        action: "HOLD",
        minutes: item.holdMin,
        reason: `Recovery plan ${plan.blockId} — priority slot ${item.slot}`,
        createdAt: fmtClock(now),
        clock: now,
        status: "PENDING",
        createdBy: "Section Controller",
        disruptionId: plan.disruptionId,
      });
    }
    addLog(
      "plan",
      "Section Controller",
      `Recovery plan accepted for ${plan.blockId}: ${plan.items.filter((i) => i.holdMin > 0).length} holds issued, ${plan.savings} weighted minutes saved (model estimate).`,
      now,
    );
    await saveState();
    return json(res, 200, { state: snapshotPayload(), plan });
  }

  if (parts[0] === "replan" && parts.length === 2 && method === "GET") {
    const snap = buildSnapshot({ ...state, trains });
    const plan = buildRecoveryPlan(state, snap, parts[1]);
    if (!plan) return json(res, 404, { error: "No recovery plan available" });
    return json(res, 200, { plan, now: fmtClock(snap.now) });
  }

  if (parts[0] === "trains" && parts[2] === "hold" && method === "POST") {
    const body = await readBody(req);
    const train = trains.find((t) => t.no === parts[1]);
    if (!train) return json(res, 404, { error: "Train not found" });
    const snap = buildSnapshot({ ...state, trains });
    const view = snap.trains.find((t) => t.no === train.no);
    const minutes = Math.max(1, Math.min(90, Number(body.minutes) || 10));
    const station = body.station || view.nextCode;
    const list = state.holds[train.no] ?? (state.holds[train.no] = []);
    list.push({
      id: nextId("HLD"),
      station,
      minutes,
      startMin: now,
      untilMin: now + minutes,
      reason: String(body.reason || "Controller hold").slice(0, 140),
      createdBy: "Section Controller",
    });
    state.instructions.unshift({
      id: nextId("INS"),
      trainNo: train.no,
      trainName: train.name,
      station,
      stationName: stationName(station),
      action: "HOLD",
      minutes,
      reason: String(body.reason || "Controller hold").slice(0, 140),
      createdAt: fmtClock(now),
      clock: now,
      status: "PENDING",
      createdBy: "Section Controller",
    });
    addLog("hold", "Section Controller", `${train.no} ${train.name} held at ${stationName(station)} for ${minutes} min.`, now);
    await saveState();
    return json(res, 200, { state: snapshotPayload() });
  }

  if (parts[0] === "trains" && parts[2] === "release" && method === "POST") {
    const train = trains.find((t) => t.no === parts[1]);
    if (!train) return json(res, 404, { error: "Train not found" });
    const list = state.holds[train.no] ?? [];
    const active = [...list].reverse().find((h) => h.untilMin > now);
    if (active) {
      active.minutes = Math.max(0, Math.round(now - active.startMin));
      active.untilMin = now;
      active.released = true;
      addLog("hold", "Section Controller", `${train.no} released from ${stationName(active.station)} after ${active.minutes} min.`, now);
      await saveState();
    }
    return json(res, 200, { state: snapshotPayload() });
  }

  if (parts[0] === "instructions" && parts[2] === "ack" && method === "POST") {
    const ins = state.instructions.find((i) => i.id === parts[1]);
    if (!ins) return json(res, 404, { error: "Instruction not found" });
    ins.status = "ACK";
    ins.ackBy = "Station Master";
    ins.ackAt = fmtClock(now);
    addLog("ack", "Station Master", `${ins.id} acknowledged at ${ins.stationName} — ${ins.action} ${ins.trainNo} for ${ins.minutes} min.`, now);
    await saveState();
    return json(res, 200, { state: snapshotPayload() });
  }

  if (parts[0] === "live" && parts[1] === "status" && method === "GET") {
    return json(res, 200, { ...(await railradarStatus()), stations: CORRIDOR.stations, wiring: railradarWiring() });
  }

  if (parts[0] === "live" && parts[1] === "key" && method === "POST") {
    const body = await readBody(req);
    try {
      if (body.clear) {
        const cleared = await clearKey();
        return json(res, 200, { status: cleared });
      }
      const saved = await setKey(body.apiKey);
      addLog("system", "Section Controller", "RailRadar key saved on the server. Live corridor data is available.", now);
      await saveState();
      return json(res, 200, { status: saved });
    } catch (error) {
      return json(res, 400, { error: error instanceof Error ? error.message : "Could not save the key" });
    }
  }

  if (parts[0] === "live" && parts[1] === "board" && method === "GET") {
    const code = url.searchParams.get("station") ?? "SC";
    const hours = url.searchParams.get("hours") ?? "4";
    const refresh = url.searchParams.get("refresh") === "1";
    try {
      const board = await stationBoard(code, { hours, refresh });
      const modelled = new Set(trains.map((t) => t.no));
      board.trains = board.trains.map((t) => ({ ...t, inModel: modelled.has(t.number) }));
      return json(res, 200, { board, status: await railradarStatus() });
    } catch (error) {
      const code2 = error?.code === "NOT_CONFIGURED" ? 409 : 502;
      return json(res, code2, {
        error: error instanceof Error ? error.message : "Live board unavailable",
        status: await railradarStatus(),
        code: error?.code ?? null,
      });
    }
  }

  if (parts[0] === "live" && parts[1] === "adopt" && method === "POST") {
    const body = await readBody(req);
    const number = String(body.trainNumber ?? "").trim();
    if (!number) return json(res, 400, { error: "A train number is required" });
    const delay = Math.max(5, Math.min(120, Number(body.delayMinutes) || 10));
    const item = {
      id: nextId("DSP"),
      kind: "late_train",
      label: `Late running ${number}`,
      blockId: null,
      stationCode: null,
      trainNo: number,
      trainName: body.trainName ? String(body.trainName) : null,
      durationMin: delay,
      reason: `Live running status from RailRadar${body.station ? ` at ${body.station}` : ""} — ${delay} min late`,
      severity: delay > 25 ? "high" : "medium",
      status: "active",
      createdAt: fmtClock(now),
      startMin: now,
      endMin: now + delay,
      createdBy: "Section Controller",
      source: "railradar",
    };
    state.disruptions.unshift(item);
    addLog(
      "disruption",
      "Section Controller",
      `${number} logged from the live RailRadar board as running ${delay} min late.`,
      now,
    );
    await saveState();
    return json(res, 201, { state: snapshotPayload(), created: item });
  }

  if (parts[0] === "reset" && method === "POST") {
    state = freshState();
    trains = buildTrains();
    addLog("system", "System", "Simulation reset to 07:30. BMO-MED engineering block restored and the queue re-formed.");
    await saveState();
    return json(res, 200, { state: snapshotPayload() });
  }

  return json(res, 404, { error: "Not found" });
}

async function serveStatic(req, res, url) {
  if (!existsSync(DIST_DIR)) {
    res.writeHead(404, { "content-type": "text/plain" });
    res.end("RailFlow API is running. Start the frontend with `npm run dev` (Vite proxies /api here).");
    return;
  }
  const filePath = path.join(DIST_DIR, url.pathname === "/" ? "index.html" : url.pathname);
  try {
    const info = await stat(filePath);
    if (!info.isFile()) throw new Error("not a file");
    const ext = path.extname(filePath);
    const types = {
      ".html": "text/html; charset=utf-8",
      ".js": "text/javascript; charset=utf-8",
      ".css": "text/css; charset=utf-8",
      ".svg": "image/svg+xml",
      ".png": "image/png",
      ".json": "application/json",
      ".woff2": "font/woff2",
    };
    const data = await readFile(filePath);
    res.writeHead(200, { "content-type": types[ext] ?? "application/octet-stream" });
    res.end(data);
  } catch {
    const data = await readFile(path.join(DIST_DIR, "index.html"));
    res.writeHead(200, { "content-type": "text/html; charset=utf-8" });
    res.end(data);
  }
}

const server = createServer(async (req, res) => {
  const url = new URL(req.url ?? "/", `http://${req.headers.host ?? "localhost"}`);
  try {
    if (url.pathname.startsWith("/api")) {
      await handleApi(req, res, url);
      return;
    }
    await serveStatic(req, res, url);
  } catch (error) {
    console.error("[railflow] request failed", error);
    if (!res.headersSent) json(res, 500, { error: "Internal error" });
  }
});

await loadState();
server.listen(PORT, "0.0.0.0", () => {
  console.log(`[railflow] API listening on http://0.0.0.0:${PORT}`);
});
