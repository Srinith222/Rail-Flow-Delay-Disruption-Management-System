// RailFlow — synthetic SC–WDR corridor model.
// Every value here is a simulation assumption, not verified railway infrastructure.

export const CORRIDOR = {
  name: "Secunderabad — Wadiaram",
  division: "South Central Railway · Secunderabad Division",
  stations: [
    { code: "SC", name: "Secunderabad Jn", km: 0, platforms: 6, major: true },
    { code: "MJF", name: "Moula Ali", km: 6.2, platforms: 4, major: false },
    { code: "BMO", name: "Bolarum", km: 14.8, platforms: 3, major: false },
    { code: "MED", name: "Medchal", km: 26.4, platforms: 3, major: true },
    { code: "MOB", name: "Manoharabad", km: 38.9, platforms: 2, major: false },
    { code: "ME", name: "Masaipet", km: 50.1, platforms: 2, major: false },
    { code: "WDR", name: "Wadiaram", km: 63.5, platforms: 3, major: true },
  ],
};

export const BLOCKS = [
  { id: "SC-MJF", from: "SC", to: "MJF", track: "double", km: 6.2 },
  { id: "MJF-BMO", from: "MJF", to: "BMO", track: "double", km: 8.6 },
  { id: "BMO-MED", from: "BMO", to: "MED", track: "single", km: 11.6 },
  { id: "MED-MOB", from: "MED", to: "MOB", track: "single", km: 12.5 },
  { id: "MOB-ME", from: "MOB", to: "ME", track: "double", km: 11.2 },
  { id: "ME-WDR", from: "ME", to: "WDR", track: "single", km: 13.4 },
];

export const CLASSES = {
  express: { label: "Express", speed: 100, weight: 3, dwell: 2, accent: "cream" },
  suburban: { label: "Suburban", speed: 80, weight: 2, dwell: 1, accent: "ice" },
  passenger: { label: "Passenger", speed: 75, weight: 1.5, dwell: 2, accent: "amber" },
  freight: { label: "Freight", speed: 60, weight: 1, dwell: 0, accent: "muted" },
};

export const HALT_PATTERN = {
  express: ["SC", "BMO", "MED", "WDR"],
  suburban: ["SC", "MJF", "BMO", "MED", "MOB", "ME", "WDR"],
  passenger: ["SC", "MJF", "BMO", "MED", "MOB", "ME", "WDR"],
  freight: ["SC", "WDR"],
};

const CODES = CORRIDOR.stations.map((s) => s.code);
const STATION_BY_CODE = Object.fromEntries(CORRIDOR.stations.map((s) => [s.code, s]));
const BLOCK_BETWEEN = {};
for (const b of BLOCKS) {
  BLOCK_BETWEEN[`${b.from}>${b.to}`] = b;
  BLOCK_BETWEEN[`${b.to}>${b.from}`] = b;
}

function hash(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i += 1) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

function jitter(seed) {
  return (hash(seed) % 3) - 1; // -1..1 minute
}

// [number, name, class, direction, departure minutes after 00:00]
const TIMETABLE = [
  ["12737", "Godavari Express", "express", "UP", 380],
  ["17031", "Hyderabad Express", "express", "DOWN", 425],
  ["12763", "Padmavathi Express", "express", "UP", 490],
  ["12773", "Shalimar Express", "express", "DOWN", 580],
  ["17063", "Ajanta Express", "express", "UP", 675],
  ["12787", "Nagavali Express", "express", "DOWN", 860],
  ["12733", "Narayanadri Express", "express", "UP", 1025],

  ["47101", "MMTS Local", "suburban", "UP", 405],
  ["47202", "MMTS Local", "suburban", "DOWN", 435],
  ["47103", "MMTS Local", "suburban", "UP", 465],
  ["47204", "MMTS Local", "suburban", "DOWN", 500],
  ["47105", "MMTS Local", "suburban", "UP", 545],
  ["47206", "MMTS Local", "suburban", "DOWN", 585],
  ["47107", "MMTS Local", "suburban", "UP", 1000],
  ["47208", "MMTS Local", "suburban", "DOWN", 1085],

  ["57101", "Manoharabad Passenger", "passenger", "UP", 475],
  ["57202", "Secunderabad Passenger", "passenger", "DOWN", 630],
  ["57103", "Medchal Passenger", "passenger", "UP", 780],
  ["57204", "Wadiaram Passenger", "passenger", "DOWN", 945],
  ["57105", "Bolarum Passenger", "passenger", "UP", 1150],

  ["90001", "Container Rake", "freight", "UP", 365],
  ["90002", "Coal Rake", "freight", "DOWN", 530],
  ["90003", "Cement Rake", "freight", "UP", 700],
  ["90004", "Container Rake", "freight", "DOWN", 900],
  ["90005", "Oil Tanker Rake", "freight", "UP", 1110],
  ["90006", "Steel Rake", "freight", "DOWN", 1260],
];

function runtimeMinutes(block, cls, seed) {
  const speed = CLASSES[cls].speed;
  return Math.max(4, Math.round((block.km / speed) * 60) + jitter(seed));
}

export function buildTrains() {
  return TIMETABLE.map(([no, name, cls, dir, dep]) => {
    const path = dir === "UP" ? [...CODES] : [...CODES].reverse();
    const halts = HALT_PATTERN[cls];
    const stops = [];
    let t = dep;
    stops.push({
      code: path[0],
      arr: t,
      dep: t,
      platform: (hash(no + path[0]) % STATION_BY_CODE[path[0]].platforms) + 1,
    });
    for (let i = 1; i < path.length; i += 1) {
      const block = BLOCK_BETWEEN[`${path[i - 1]}>${path[i]}`];
      t += runtimeMinutes(block, cls, `${no}-${block.id}`);
      const isLast = i === path.length - 1;
      const haltsHere = halts.includes(path[i]);
      const dwell = isLast || !haltsHere ? 0 : CLASSES[cls].dwell;
      stops.push({
        code: path[i],
        arr: t,
        dep: t + dwell,
        platform: (hash(no + path[i] + i) % STATION_BY_CODE[path[i]].platforms) + 1,
      });
      t += dwell;
    }
    return {
      no,
      name,
      cls,
      weight: CLASSES[cls].weight,
      dir,
      stops,
      origin: path[0],
      destination: path[path.length - 1],
      schedDep: stops[0].dep,
      schedArr: stops[stops.length - 1].arr,
    };
  });
}

export function stationName(code) {
  return STATION_BY_CODE[code]?.name ?? code;
}

export function blockById(id) {
  return BLOCKS.find((b) => b.id === id) ?? null;
}
