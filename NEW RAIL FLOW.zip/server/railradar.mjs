// RailRadar live-data adapter.
// The API key is held server-side only (data/railradar.json or RAILRADAR_API_KEY)
// and is never sent to the browser.

import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const CONFIG_DIR = path.join(ROOT, "data");
const CONFIG_FILE = path.join(CONFIG_DIR, "railradar.json");

const BASE_URL = (process.env.RAILRADAR_BASE_URL ?? "https://api.railradar.in").replace(/\/$/, "");
const TTL_MS = 15 * 60 * 1000;

const cache = new Map();
let quota = { limitMonth: null, remainingMonth: null, limitMinute: null, remainingMinute: null };
let lastSync = null;
let lastError = null;

async function readConfig() {
  try {
    return JSON.parse(await readFile(CONFIG_FILE, "utf8"));
  } catch {
    return {};
  }
}

async function getKey() {
  if (process.env.RAILRADAR_API_KEY) return { key: process.env.RAILRADAR_API_KEY, source: "environment" };
  const config = await readConfig();
  if (config.apiKey) return { key: config.apiKey, source: "saved" };
  return { key: null, source: null };
}

export async function setKey(apiKey) {
  const trimmed = String(apiKey ?? "").trim();
  if (!/^rg_[A-Za-z0-9_-]{8,}$/.test(trimmed)) {
    throw new Error("That does not look like a RailRadar key. Keys start with rg_.");
  }
  await mkdir(CONFIG_DIR, { recursive: true });
  await writeFile(CONFIG_FILE, JSON.stringify({ apiKey: trimmed, savedAt: new Date().toISOString() }, null, 2), "utf8");
  cache.clear();
  lastError = null;
  return status();
}

export async function clearKey() {
  await mkdir(CONFIG_DIR, { recursive: true });
  await writeFile(CONFIG_FILE, JSON.stringify({}, null, 2), "utf8");
  cache.clear();
  lastError = null;
  return status();
}

export async function status() {
  const { key, source } = await getKey();
  return {
    configured: Boolean(key),
    keySource: source,
    baseUrl: BASE_URL,
    quota,
    lastSync,
    lastError,
    cacheSeconds: Math.round(TTL_MS / 1000),
  };
}

function noteQuota(headers) {
  const pick = (name) => {
    const value = headers.get(name);
    return value === null ? null : Number(value);
  };
  quota = {
    limitMonth: pick("x-ratelimit-limit-month"),
    remainingMonth: pick("x-ratelimit-remaining-month"),
    limitMinute: pick("x-ratelimit-limit-min"),
    remainingMinute: pick("x-ratelimit-remaining-min"),
  };
}

async function call(pathname, { key }) {
  let response;
  try {
    response = await fetch(`${BASE_URL}${pathname}`, {
      headers: { authorization: `Bearer ${key}`, accept: "application/json" },
      signal: AbortSignal.timeout(15000),
    });
  } catch (error) {
    throw new Error(`RailRadar could not be reached (${error instanceof Error ? error.message : "network error"}).`);
  }
  noteQuota(response.headers);
  const body = await response.json().catch(() => null);
  if (!response.ok) {
    const detail = body?.error?.message ?? body?.message ?? body?.error ?? "";
    if (response.status === 401) throw new Error("RailRadar rejected the key (401). Check it was copied whole.");
    if (response.status === 403) throw new Error("This key is not allowed to use that endpoint (403).");
    if (response.status === 404) throw new Error(detail || "RailRadar has no data for that station (404).");
    if (response.status === 429) throw new Error("RailRadar quota reached (429). Wait for the monthly reset or upgrade the plan.");
    throw new Error(detail ? `${detail} (${response.status})` : `RailRadar request failed (${response.status}).`);
  }
  if (!body?.success) throw new Error(body?.error?.message ?? "RailRadar returned an unexpected response.");
  return body;
}

function normaliseBoard(body, stationCode) {
  const data = body.data ?? {};
  const trains = Array.isArray(data.trains) ? data.trains : [];
  return {
    station: {
      code: data.station?.code ?? stationCode,
      name: data.station?.name ?? stationCode,
      city: data.station?.city ?? null,
    },
    window: data.window ?? null,
    count: trains.length,
    trains: trains.map((entry) => {
      const train = entry.train ?? {};
      const stop = entry.stop ?? {};
      const live = entry.live ?? {};
      return {
        number: String(train.number ?? ""),
        name: train.name ?? "",
        type: train.type ?? "",
        source: train.source ?? "",
        destination: train.destination ?? "",
        runDays: train.runDays ?? [],
        sequence: stop.sequence ?? null,
        scheduledArrival: stop.arrival ?? null,
        scheduledDeparture: stop.departure ?? null,
        day: stop.day ?? null,
        platform: stop.platform ?? null,
        isHalt: stop.isHalt !== false,
        status: live.type ?? "scheduled",
        delayMinutes: Number(live.delayMinutes ?? 0),
        expectedArrival: live.expectedArrivalTime ?? null,
        expectedDeparture: live.expectedDepartureTime ?? null,
        departedAt: live.departedAt ?? null,
        startDate: live.startDate ?? null,
      };
    }),
    meta: {
      timestamp: body.meta?.timestamp ?? null,
      source: body.meta?.source ?? null,
      traceId: body.meta?.traceId ?? null,
    },
  };
}

export async function stationBoard(stationCode, { hours = 4, refresh = false } = {}) {
  const { key } = await getKey();
  if (!key) {
    const error = new Error("No RailRadar key saved. Add one to load live trains.");
    error.code = "NOT_CONFIGURED";
    throw error;
  }
  const code = String(stationCode || "").toUpperCase();
  if (!/^[A-Z0-9]{1,10}$/.test(code)) throw new Error("Station code should be 1–10 letters or digits.");
  const allowed = [2, 4, 6, 8];
  const window = allowed.includes(Number(hours)) ? Number(hours) : 4;
  const cacheKey = `${code}:${window}`;
  const hit = cache.get(cacheKey);

  if (!refresh && hit && hit.expires > Date.now()) {
    return { ...hit.board, cached: true, fetchedAt: hit.fetchedAt };
  }

  try {
    const body = await call(`/v1/stations/${code}/live?hours=${window}`, { key });
    const board = normaliseBoard(body, code);
    const fetchedAt = new Date().toISOString();
    cache.set(cacheKey, { board, fetchedAt, expires: Date.now() + TTL_MS });
    lastSync = fetchedAt;
    lastError = null;
    return { ...board, cached: false, fetchedAt };
  } catch (error) {
    lastError = error instanceof Error ? error.message : "RailRadar request failed.";
    if (hit) return { ...hit.board, cached: true, stale: true, fetchedAt: hit.fetchedAt, error: lastError };
    throw error;
  }
}

export function wiring() {
  return { baseUrl: BASE_URL, cachedStations: [...cache.keys()] };
}
